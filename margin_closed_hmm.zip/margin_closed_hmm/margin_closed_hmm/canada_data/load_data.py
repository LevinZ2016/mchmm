# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 17:03:02 2020

@author: Levin
"""

#%%

import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
import platform

#%%

if platform.system() == 'Windows':
    path = Path('E:/Project/BoC/data/imported data')
else:
    path = Path('/Users/levin/Documents/Study Files/Project/BoC/data/imported data')

class MktDataSet():
    
    def __init__(self, path=Path.joinpath(path, 'mkt_data')):
        self.root_path = path
    
    @classmethod
    def series_plot(cls, s1, s2):
        ind = s1.index.intersection(s2.index).tolist()
        plt.scatter(s1.loc[ind],s2.loc[ind])
        plt.grid()
        plt.xlabel(s1.name)
        plt.ylabel(s2.name)
        plt.show()
        
    @classmethod
    def df_corr(cls, df1, df2, method='spearman'):
# =============================================================================
#         return pd.concat([df1, df2], axis=1, \
#                 keys=['df1', 'df2']).corr(method='spearman').loc['df1', 'df2']
# =============================================================================
        cols = df2.columns
        ts_list = []
        for name in cols:
            tem_ts = df1.corrwith(df2[name], method=method)
            tem_ts = tem_ts.rename(name)
            ts_list.append(tem_ts)
        return pd.concat(ts_list, axis=1)
            
    @classmethod
    def diag_corr(cls, df1, df2, name='Corr', method='spearman'):
        if df1.shape[1] != df2.shape[1]:
            print('Two dataframes must have the same numbers of columns!!!!!')
        else:
            index = df1.columns
            values = []
            for i in index:
                values.append(df1[i].corr(df2[i], method=method))
            return pd.DataFrame({name:values}, index=index)
            
    @classmethod
    def month_max(cls, df):
        month = [d//100 for d in df.index]
        df.insert(0, 'Month', month)
        return df.groupby('Month').max()
    
    @classmethod
    def trans_index(cls, df, index_date):
        if index_date:
            df.index = pd.to_datetime(df.index.astype(str), format='%Y%m%d')
        return df
    
    @classmethod
    def month_mean(cls, df):
        month = [d//100 for d in df.index]
        df.insert(0, 'Month', month)
        return df.groupby('Month').mean()
            
    def sector_num(self, sector=0, remove_zero_size=True):
        df = self.get_sector(sector=sector).loc[self.get_all_useful_tickers(),:]
        df.insert(0, 'Num_of_stk', [1]*df.shape[0])
        return df.groupby('Level 1').count()
        
    def sector_mean(self, df, sector=0, remove_zero_size=True):
        df = df.join(self.get_sector(sector=sector), how='left')
        if remove_zero_size:
            return df.loc[self.get_all_useful_tickers(),:].groupby('Level 1')\
                .mean().join(self.sector_num(), how='left')
        else:
            return df.groupby('Level 1').mean() \
                .join(self.sector_num(), how='left')    
    
    def sector_abs_mean(self, df, sector=0, remove_zero_size=True):
        df = df.join(self.get_sector(sector=sector), how='left')
        if remove_zero_size:
            df = df.loc[self.get_all_useful_tickers(),:].groupby('Level 1')\
                    .apply(lambda c: c.abs().mean()) \
                    .join(self.sector_num(), how='left') 
        else:
            df = df.groupby('Level 1').apply(lambda c: c.abs().mean()) \
                    .join(self.sector_num(), how='left') 
        return df.drop('Level 1', axis=1)
    
    def load_df(self):
        # load stock technical and financial data
        self.df_stk_r = self.read_time_df('market/price change.csv')
        self.df_ann_r = self.df_stk_r.rolling(260).mean()*260
        self.df_stk_vol20 = self.read_time_df('market/vol20.csv')
        self.df_stk_vol60 = self.read_time_df('market/vol60.csv')
        self.df_stk_vol260 = self.read_time_df('market/vol260.csv')
        self.df_lastp = self.read_time_df('market/last px.csv')
        self.df_debt2mkt = self.read_time_df('BS/debt2mkt.csv')
        self.df_debt = self.read_time_df('BS/debt.csv')
        self.df_mktc = self.read_time_df('BS/mkt.csv')
        self.df_share = self.read_time_df('BS/share out.csv')
        
        con_list = [self.df_stk_r, self.df_ann_r, self.df_stk_vol20, 
                    self.df_stk_vol60, self.df_stk_vol260, self.df_lastp,
                    self.df_debt2mkt, self.df_debt, self.df_mktc, self.df_share]
        con_name = ['DRe', 'ARe', 'Vol20', 
                    'Vol60', 'Vol260', 'LPr', 
                    'D2M', 'Debt', 'MktC', 'Share']
        self.stock_df = pd.concat(con_list, axis=1, keys=con_name)
        self.stock_df.columns.set_names(['Var', 'Ticker'], inplace=True)
        
        # load stock PDs data
        self.df_3m_pd = self.read_time_df('PD/3m_PD.csv')
        self.df_6m_pd = self.read_time_df('PD/6m_PD.csv')
        self.df_9m_pd = self.read_time_df('PD/9m_PD.csv')
        self.df_1y_pd = self.read_time_df('PD/1y_PD.csv')
        self.df_2y_pd = self.read_time_df('PD/2y_PD.csv')
        self.df_3y_pd = self.read_time_df('PD/3y_PD.csv')
        self.df_4y_pd = self.read_time_df('PD/4y_PD.csv')
        self.df_5y_pd = self.read_time_df('PD/5y_PD.csv')
        self.df_1y_dd = self.read_time_df('PD/1y_DD.csv')
        self.df_cds = self.read_time_df('PD/CDS.csv')
        con_list = [self.df_3m_pd, self.df_6m_pd, self.df_9m_pd, self.df_1y_pd, 
                    self.df_2y_pd, self.df_3y_pd, self.df_4y_pd, self.df_5y_pd,
                    self.df_1y_dd, self.df_cds]
        con_name = ['PD3m', 'PD6m', 'PD9m', \
                    'PD1y', 'PD2y', 'PD3y', \
                    'PD4y', 'PD5y', 'DD1y', 'CDS']
        self.PD_df = pd.concat(con_list, axis=1, keys=con_name)
        self.PD_df.columns.set_names(['Var', 'Ticker'], inplace=True)
        
        # load stock sector data
        self.df_sector = pd.read_csv(self.root_path.joinpath('market/sectors.csv'),
                                       index_col=0)
        
        # load indices and comdty
        self.index_df = self.read_time_df('market/indices.csv', 
                                          trade_days=False, mul_col=True)
        self.comdty_df = self.read_time_df('comdty/comdty.csv', 
                                          trade_days=False, mul_col=True)
        
        # load hist memebers
        self.hist_m_df = pd.read_csv(self.root_path.joinpath('market/hist_member.csv'), 
                                          index_col=0, low_memory=False)
        self.hist_m_df.columns = self.hist_m_df.columns.astype(int)
        
        # get delisted info
        self.df_delist = self.delisted_info()
    
    def trading_days(self):
        tra_days = pd.read_csv(self.root_path.joinpath('trading_days.csv'), index_col=0)
        return tra_days.index
        
    def read_time_df(self, file_path, trade_days=True, mul_col=False):
        if mul_col:
            df = pd.read_csv(self.root_path.joinpath(file_path), 
                               header=[0, 1], index_col=0)
        else:
            df = pd.read_csv(self.root_path.joinpath(file_path), index_col=0)
        df.index = pd.to_datetime(df.index).strftime('%Y%m%d').astype(int)
        if trade_days:
            return df[df.index.isin(self.trading_days())]
        else:
            return df
    
    def delisted_info(self):
        tickers = self.df_stk_r.columns
        mask_df = dict()
        for tk in tickers:
            tem_ts = self.df_stk_r[tk]
            cp_ts = tem_ts.copy()
            last_r = tem_ts.iloc[-1]
            i=-1
            while cp_ts.iloc[i-1] == last_r:
                cp_ts.iloc[i] = np.nan
                i -= 1
            mask_df[tk] = (tem_ts==cp_ts).to_list()
        return pd.DataFrame(mask_df, index=self.df_stk_r.index)
            
    def mask_multi_stk(self, df):
        stk_list = df.columns.to_list()
        mask = self.df_delist[stk_list]
        return df[mask]
    
    def mask_single_stk(self, df, tk):
        ts_delist = self.df_delist[tk]
        rem_time = ts_delist[ts_delist].index
        return df.loc[df.index.intersection(rem_time)]
    
    def get_all_tickers(self):
        tem_l = self.stock_df.columns.get_level_values('Ticker').to_numpy()
        return np.unique(tem_l)
    
    def get_all_useful_tickers(self, sym='PD1y'):
        sample_size = self.get_sample_size(sym)
        return sample_size[sample_size>400].index.to_list()
    
    def get_sample_size(self, sym='PD1y'):
        d_pd = self.get_pd(sym)
        return (~d_pd.isna()).sum()
        
    def get_all_var_names(self):
        tem_l = self.stock_df.columns.get_level_values('Var').to_numpy()
        return np.unique(tem_l)
    
    def get_all_comdty_names(self):
        tem_l = self.comdty_df.columns.get_level_values('Comdty').to_numpy()
        return np.unique(tem_l)
    
    def get_all_index_names(self):
        tem_l = self.index_df.columns.get_level_values('Index').to_numpy()
        return np.unique(tem_l)
    
    def get_all_pd_names(self):
        tem_l = self.PD_df.columns.get_level_values('Var').to_numpy()
        return np.unique(tem_l)
    
    def get_pd(self, sym, smooth=None, index_date=False):
        if sym in self.get_all_tickers():
            df = self.PD_df.xs(sym, level='Ticker', axis=1)
            return MktDataSet.trans_index(self.mask_single_stk(df, sym), index_date)
        elif sym in self.get_all_pd_names():
            df = self.PD_df.xs(sym, level='Var', axis=1)
            if smooth == 'mean':
                return MktDataSet.trans_index(MktDataSet.month_mean(self.mask_multi_stk(df)),
                                              index_date)
            elif smooth == 'max':
                return MktDataSet.trans_index(MktDataSet.month_max(self.mask_multi_stk(df)),
                                              index_date)
            else:
                return MktDataSet.trans_index(self.mask_multi_stk(df), index_date)
        else:
            print('Wrong input symbol!!!!!')
        
    def get_stk(self, sym, index_date=False):
        if sym in self.get_all_tickers():
            df = self.stock_df.xs(sym, level='Ticker', axis=1)
            return MktDataSet.trans_index(self.mask_single_stk(df, sym), index_date)
        elif sym in self.get_all_var_names():
            df = self.stock_df.xs(sym, level='Var', axis=1)
            return MktDataSet.trans_index(self.mask_multi_stk(df), index_date)
        else:
            print('Wrong input symbol!!!!!')
    
    def get_index(self, sym, index_date=False):
        if sym in self.get_all_index_names():
            return MktDataSet.trans_index(self.index_df.xs(sym, level='Index', axis=1),
                                          index_date)
        elif sym in self.get_all_var_names():
            return MktDataSet.trans_index(self.index_df.xs(sym, level='Var', axis=1),
                                          index_date)
        else:
            print('Wrong input symbol!!!!!')
        
    def get_comdty(self, sym, index_date=False):
        if sym in self.get_all_comdty_names():
            return MktDataSet.trans_index(self.comdty_df.xs(sym, level='Comdty', axis=1),
                                          index_date)
        elif sym in self.get_all_var_names():
            return MktDataSet.trans_index(self.comdty_df.xs(sym, level='Var', axis=1),
                                          index_date)
        else:
            print('Wrong input symbol!!!!!')
        
    def get_sector(self, sector=0):
        if sector == 0:
            return self.df_sector[['Level 1']]
        elif sector == 1:
            df = self.df_sector[['GICS Sector']]
            return df.rename(columns={'GICS Sector':'Level 1'})
        else:
            print('Wrong input level!!!!!')
            
    def get_hist_m(self, date, sector=0):
        if isinstance(date, str):
            date = int(date)
        if isinstance(date, int):
            ts = self.hist_m_df[date]
            return self.get_sector(sector=sector).loc[ts[~ts.isna()]]
        else:
            print('Wrong input date!!!!!')
            
    def get_acc_hist_m(self, date, sector=0, exc_delist=True):
        if isinstance(date, str):
            date = int(date)
        if isinstance(date, int):
            ts = self.hist_m_df.loc[:,:date].unstack()
            df = self.get_sector(sector=sector).loc[ts[~ts.isna()].unique()]
            if exc_delist:
                mask_ts = self.df_delist.loc[date]
                df = df.join(mask_ts, how='left')
                df = df[df[date]]
                return df.iloc[:,:-1]
            else:
                return df
        else:
            print('Wrong input date!!!!!')

class MacroDataSet():
    
    @classmethod
    def trans_index(cls, df, index_date):
        if index_date:
            df.index = pd.to_datetime(df.index.astype(str), format='%Y%m')
        return df
    
    def __init__(self, path=Path.joinpath(path, 'macro_data')):
        self.root_path = path
        
    def load_df(self, lag=12):
        self.df_GDP = self.read_time_df(r'adjusted_chained_GDP.csv')
        self.df_CPI = self.read_time_df(r'adjusted_CPI.csv')
        self.df_Crd = self.read_time_df(r'adjusted_credits.csv')
        self.df_Emp = 100 - self.read_time_df(r'adjusted_unemp.csv')[['VALUE']]
        self.df_GvD = self.read_time_df(r'gov_debt.csv')
        self.df_MRt = self.read_time_df(r'mkt_rate.csv')
        self.df_HPI = self.read_time_df(r'house_ind.csv')
        if lag == 12:
            self.df_GDP_r = self.df_GDP / self.df_GDP.shift(lag) - 1
            self.df_CPI_r = self.df_CPI / self.df_CPI.shift(lag) - 1
            self.df_Crd_r = self.df_Crd / self.df_Crd.shift(lag) - 1
            self.df_GvD_r = self.df_GvD / self.df_GvD.shift(lag) - 1
            self.df_HPI_r = self.df_HPI / self.df_HPI.shift(lag) - 1
            self.df_Emp_r = self.df_Emp / self.df_Emp.shift(lag) - 1
        elif lag == 1:
            self.df_GDP_r = np.log(self.df_GDP / self.df_GDP.shift(lag))
            self.df_CPI_r = np.log(self.df_CPI / self.df_CPI.shift(lag))
            self.df_Crd_r = np.log(self.df_Crd / self.df_Crd.shift(lag))
            self.df_GvD_r = np.log(self.df_GvD / self.df_GvD.shift(lag))
            self.df_HPI_r = np.log(self.df_HPI / self.df_HPI.shift(lag))
            self.df_Emp_r = np.log(self.df_Emp / self.df_Emp.shift(lag))
        else:
            raise ValueError('lag can only be 1 or 12!')
        
        self.df_G2G = self.df_GvD.copy()
        df_all_GDP = self.df_GDP.iloc[:,0][self.df_GDP.index.isin(self.df_G2G.index)]
        for i in self.df_G2G.columns:
            self.df_G2G[i] = self.df_G2G[i] / df_all_GDP
            
        self.df_MRt_m = MktDataSet.month_mean(self.df_MRt)
        
        con_list = [self.df_GDP_r, self.df_CPI_r, self.df_Crd_r, self.df_Emp_r, 
                    self.df_GvD_r, self.df_MRt_m, self.df_G2G, self.df_HPI_r]
        self.con_name = ['GDP', 'CPI', 'Crd', 'Emp', 'GvD', 'MRt', 'G2G', 'HPI']
        self.Macro_df = pd.concat(con_list, axis=1, keys=self.con_name)
        self.Macro_df.columns.set_names(['Indicator', 'Details'], inplace=True)
        
    def read_time_df(self, file_path):
        df = pd.read_csv(self.root_path.joinpath(file_path), index_col=0)
        df.index = df.index.astype(int)
        df = df[df.index>199501]
        return df
    
    def get_data(self, sym, index_date=False):
        if sym in self.con_name:
            return MacroDataSet.trans_index(self.Macro_df.xs(sym, level='Indicator', axis=1),
                                          index_date)
        else:
            print('Wrong input level!!!!!. Input one of ' +  
                  '[\'GDP\', \'CPI\', \'Crd\', \'Uem\', \'GvD\', \'MRt\', \'G2G\', \'HPI\']')
    
# idx = pd.IndexSlice, ds.Macro_df.loc[:,idx[['GDP', 'CPI'], :]]
# ds.Macro_df.loc[:,(['GDP', 'CPI'], slice(None))]


       
        
        
# %%
