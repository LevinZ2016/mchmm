
#%%
import numpy as np
import pandas as pd
import scipy.stats as st

from .load_data import (MktDataSet, MacroDataSet)

mkt, mac = MktDataSet(), MacroDataSet()
mkt.load_df()
mac.load_df()

#%%

def get_dd_mask():
    mktc1 = mkt.get_stk('LPr', index_date=True) * mkt.get_stk('Share', index_date=True)
    isclose = np.isclose(mktc1, mkt.get_stk('MktC', index_date=True), rtol=0.2)
    mask = pd.DataFrame(data=isclose, index=mktc1.index, columns=mktc1.columns)
    return mask

def get_bg_dd_data(start_date='19980101', end_date='20200229', fillinf=False, freq='M'):
    pd_df = mkt.get_pd('PD1y', index_date=True).sort_index()
    pd_df = pd_df.query(f"(Dates >= '{start_date}') and (Dates <= '{end_date}')")

    #change_point = np.where(pd_df.index.dayofweek.to_series().diff().to_numpy()<0)[0]
    #week_label = np.array([np.nan] * len(pd_df))
    #week_label[change_point] = change_point
    #week_df = pd.Series(week_label)
    #week_label = week_df.fillna(method='ffill').fillna(value=0).to_numpy().astype(int)

    mean_pd_df = pd_df.resample(freq).mean()
    mean_pd_df.index.rename('Dates', inplace=True)
    mean_dd_df = pd.DataFrame(-st.norm.ppf(mean_pd_df),
                              index=mean_pd_df.index,
                              columns=mean_pd_df.columns)
    if fillinf: 
        mean_dd_df.replace(np.inf, 6.5, inplace=True)
    else:
        mean_dd_df.replace(np.inf, np.nan, inplace=True)

    sec_df = mkt.get_sector()
    sec_df = sec_df.loc[mean_dd_df.columns,:]
    return mean_dd_df, sec_df

def get_sector_bg_dd(start_date='19980101', end_date='20200229', freq='M'):
    bg_dd_df, sec_df = get_bg_dd_data(fillinf=False, freq=freq)
    dd_df = bg_dd_df

    mkc_df = mkt.get_stk('MktC', index_date=True).sort_index()
    mkc_df = mkc_df.query(f"(Dates >= '{start_date}') and (Dates <= '{end_date}')")
    mkc_df = mkc_df.resample(freq).mean()

    all_data = []
    for m in dd_df.index:
        df1 = dd_df.loc[m, :].dropna()
        df2 = mkc_df.loc[m, :].dropna()
        union_stocks = list(set(df1.index).intersection(df2.index))
        temp_sec_df = sec_df.loc[union_stocks, :]
        row_values = []
        for i in np.unique(sec_df):
            stocks = temp_sec_df.loc[temp_sec_df['Level 1']==i,:].index
            if (demo := df2.loc[stocks].sum()) == 0:
                row_values.append(np.nan)
            else:
                row_values.append((df1.loc[stocks] * df2.loc[stocks]).sum() / demo)
        all_data.append(row_values)
    sector_dd_df = pd.DataFrame(all_data, index=dd_df.index, columns=np.unique(sec_df))
    return sector_dd_df

def get_dd_data(start_date='19980101', end_date='20200229'):
    dd_df = mkt.get_pd('DD1y', index_date=True).sort_index()
    dd_df.replace(np.inf, np.nan, inplace=True)
    mask = get_dd_mask()
    dd_df = dd_df[mask]
    dd_df = dd_df.query(f"(Dates >= '{start_date}') and (Dates <= '{end_date}')")

    #change_point = np.where(dd_df.index.dayofweek.to_series().diff().to_numpy()<0)[0]
    #week_label = np.array([np.nan] * len(dd_df))
    #week_label[change_point] = change_point
    #week_df = pd.Series(week_label)
    #week_label = week_df.fillna(method='ffill').fillna(value=0).to_numpy().astype(int)

    mean_dd_df = dd_df.resample('1m').mean()
    mean_dd_df.index.rename('Dates', inplace=True)

    sec_df = mkt.get_sector()
    sec_df = sec_df.loc[mean_dd_df.columns,:]
    return mean_dd_df, sec_df

def get_macro_data(name_list=['GDP', 'CPI', 'Emp'], 
                   start_date='19980101', 
                   end_date='20200201'):
    data_list = []
    for name in name_list:
        var = mac.get_data(name, index_date=True).iloc[:,0] * 100
        data_list.append(var)
    macro_df = pd.concat(data_list, axis=1, keys=name_list)
    macro_df.index.rename('Dates', inplace=True)
    macro_df = macro_df[~macro_df.isna().any(axis=1)]
    macro_df = macro_df.query(f"(Dates >= '{start_date}') and (Dates <= '{end_date}')")
    macro_df.index = macro_df.index.to_period('M')
    return macro_df

def combine_regs(mean_dd_df, reg_df):
    df = pd.merge(mean_dd_df, reg_df, on='Dates', how='left')
    #df_with_reg = df.sort_index().fillna(method='ffill')
    #select_df = ~df.iloc[:,:-1].isna().all(axis=1)
    #select_date = select_df[select_df].index
    #df_with_reg = df_with_reg.loc[select_date]
    return df

def get_dd_pairs(df1, df2, target_reg):
    temp_df1 = df1.query(f"Regs == {target_reg}")
    temp_df2 = df2.query(f"Regs == {target_reg}")

    dates = temp_df1.index
    tickers = temp_df1.columns[:-1]
    pairs = []
    for d in dates:
        for tk in tickers:
            pairs.append([
                temp_df1.at[d, tk],
                temp_df2.at[d, tk]
            ])
    pairs = np.array(pairs)
    return pairs[~np.any(np.isnan(pairs), axis=1),:]

# %%
macro_df = get_macro_data()
regs = np.array([2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2])
reg_df = pd.DataFrame(index=macro_df.index, data={'Regs':regs})
