#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 18 15:08:15 2020

@author: levin
"""

import numpy as np
import pandas as pd
import random

def check_mktc(dd_df):
    mktc1 = mkt.get_stk('LPr') * mkt.get_stk('Share')
    isclose = np.isclose(mktc1, mkt.get_stk('MktC'), rtol=0.2)
    isclose = pd.DataFrame(data=isclose, index=dd_df.index, columns=dd_df.columns)
    return dd_df[isclose]
    
date_list = mkt.get_pd('DD1y').index.to_numpy()
date_list = date_list[(date_list >= 20010402) & (date_list < 20200401)]

gdp = mac.get_data('GDP').iloc[:,0] * 100
gdp.name = 'GDP'
uem = mac.get_data('Uem').iloc[:,0] * 100
uem.name = 'Uem'
cpi = mac.get_data('CPI').iloc[:,0] * 100
cpi.name = 'CPI'
mrt = mac.get_data('MRt').iloc[:,0]
mrt.name = 'MRt'

macro_df = pd.concat([gdp, uem, cpi, mrt], axis=1).iloc[:-3,:]
PD_df = mkt.get_pd('PD1y')
DD_df = check_mktc(mkt.get_pd('DD1y'))
CDS_df = mkt.get_pd('CDS')
ARe_df = mkt.get_stk('DRe')
MktC_df = mkt.get_stk('MktC')

sector = 21
records = []
for date in date_list:
    day_m = mkt.get_hist_m(str(date)).iloc[:,0]
    day_m = day_m[day_m==sector].index.to_numpy()
    
    #day_m = day_m[random.sample(range(len(day_m)), 5)]
    
    new_record = [[date] * len(day_m), day_m]
    new_record.append(st.norm.ppf(PD_df.loc[date, day_m]))
    new_record.append(DD_df.loc[date, day_m].to_numpy())
    new_record.append(CDS_df.loc[date, day_m].to_numpy() / 100)
    new_record.append(ARe_df.loc[date, day_m].to_numpy())
    new_record.append(MktC_df.loc[date, day_m].to_numpy())
    
    new_record = np.vstack(new_record).T
    
    new_macro = np.tile(macro_df.loc[date//100,:].to_list(), [len(day_m), 1])
    
    new_record = np.hstack([new_record, new_macro])
    
    records.append(new_record)

data_df = pd.DataFrame.from_records(np.vstack(records), 
                                    columns=['Date', 'Stk', 'PD', 'DD', 'CDS', 'ARe', 'MktC'] 
                                            + macro_df.columns.to_list())
data_df['Mon'] = data_df.Date//100



mre_df = data_df[['ARe', 'Mon', 'Stk']]
mre_df.ARe = 1 + mre_df.ARe/100
mre_df = mre_df.groupby(['Mon', 'Stk']).prod()

mktc_df = data_df[['MktC', 'Mon', 'Stk']]
mktc_df = mktc_df.groupby(['Mon', 'Stk']).mean()

tot_df = mre_df.join(mktc_df)
tot_df['MRe'] = tot_df.ARe * tot_df.MktC
tot_df = tot_df.groupby('Mon').mean()
tot_df.MRe = (tot_df.MRe / tot_df.MktC - 1) * 100

end_date = data_df[data_df.Mon.diff(-1) != 0].Date
vol_df = mkt.get_stk('Vol20')
m_vol = []
for m, d in zip(data_df.Mon.unique(), end_date):
    stks = data_df[data_df.Mon == m].Stk.unique()
    vols = vol_df.loc[d, stks]
    mkt_weights = mktc_df.loc[(m, slice(None))].MktC
    m_vol.append((vols * mkt_weights).sum() / mkt_weights.sum())
m_vol_df = pd.DataFrame(data={'MVol': m_vol, 'Mon': data_df.Mon.unique()})
m_vol_df.set_index('Mon', inplace=True)



data_df = data_df.join(tot_df.MRe, on='Mon')
data_df = data_df.join(m_vol_df.MVol, on='Mon')
data_df.replace([np.inf, -np.inf], np.nan, inplace=True)
data_df = data_df[~data_df.isna().any(axis=1)]

# =============================================================================
# stk = 'YRI CT Equity'
# s_data = data_df[data_df.Stk == stk]
# =============================================================================


features = ['DD', 'PD']
macros = ['GDP', 'Uem', 'CPI', 'MVol', 'MRe']

mean_data_df = data_df.groupby(['Mon', 'Stk']).mean()
day_data = pd.DataFrame(data=mean_data_df[macros+features].values)
day_data.columns = macros + features
day_data.index = mean_data_df.index.get_level_values(0) * 100

mon_data = day_data[macros].groupby('Mon').mean()
mon_data.index = mon_data.index // 100

#%%

regs = np.array([2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1,
                 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
                 2, 2])
reg_df = pd.DataFrame(index=macro_df.index, data={'Regs':regs})

df = pd.merge(mean_dd_df, reg_df, on='Dates', how='outer')
df_with_sector = df.sort_index().fillna(method='ffill')
select_df = ~df.iloc[:,:-1].isna().any(axis=1)
select_date = select_df[select_df].index
df_with_sector = df_with_sector.loc[select_date]