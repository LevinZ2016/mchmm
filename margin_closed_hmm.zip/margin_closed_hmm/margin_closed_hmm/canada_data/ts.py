# -*- coding: utf-8 -*-
"""
Created on Tue Jul 21 21:53:54 2020

@author: Levin
"""

import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator


def cond_cov(A1, A2, A12):
    if (A12.shape[0]==A2.shape[0]) & (A12.shape[1]==A1.shape[0]):
        return A1 - np.dot(A12.T, np.linalg.solve(A2, A12))
    else:
        raise ValueError('The dimension of the input is wrong')
        
def acf2pacf(rho, n):
    if n == 1:
        return rho[n]
    else:
        A1 = np.array([[rho[0], rho[n]],[rho[n], rho[0]]])
        A2 = np.zeros([n-1, n-1])
        A12 = np.zeros([n-1, 2])
        for i in range(n-1):
            A2[i, i:] = rho[:(n-1-i)]
            A12[i] = [rho[i+1], rho[n-1-i]]
        A2 = A2 + A2.T - np.eye(n-1)
        cov = cond_cov(A1, A2, A12)
    return cov[0,1] / cov[0,0]

def acf(ts, n, plot=False):
    ts = np.array(ts)
    mu = np.mean(ts)
    ts = ts - mu
    l = len(ts)
    rho = [1.]
    p_rho = []
    level = st.norm.ppf((1 + 0.95)/2)/np.sqrt(len(ts))
    for i in range(1, n+1):
        rho.append(np.sum(ts[:-i] * ts[i:]) / ((l-1) * np.cov(ts)))
        p_rho.append(acf2pacf(rho, i))
    
    if plot:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15,4))
        ax1.stem(range(1,n+1), rho[1:], use_line_collection=True)
        ax1.axhline(y=level, linewidth=0.5, color='r', linestyle='--')
        ax1.axhline(y=-level, linewidth=0.5, color='r', linestyle='--')
        ax1.set_title('Autocorrelations')
        ax1.xaxis.set_major_locator(MaxNLocator(integer=True))
        ax1.grid()
        
        ax2.stem(range(1,n+1), p_rho, use_line_collection=True)
        ax2.axhline(y=level, linewidth=0.5, color='r', linestyle='--')
        ax2.axhline(y=-level, linewidth=0.5, color='r', linestyle='--')
        ax2.set_title('Partial Autocorrelations')
        ax2.xaxis.set_major_locator(MaxNLocator(integer=True))
        ax2.grid()
        plt.show()
    
    return rho, p_rho, level

def ccf(ts1, ts2, n):
    ts1 = np.array(ts1)
    ts2 = np.array(ts2)
    ts1 = ts1 - np.mean(ts1)
    ts2 = ts2 - np.mean(ts2)
    std1 = np.sqrt(np.cov(ts1))
    std2 = np.sqrt(np.cov(ts2))
    l = len(ts1)
    rho1 = [np.sum(ts1 * ts2) / ((l-1) * std1 * std2)]
    rho2 = []
    level = st.norm.ppf((1 + 0.95)/2)/np.sqrt(l)
    for i in range(1, n+1):
        rho1.append(np.sum(ts1[:l-i] * ts2[i:]) / ((l-1) * std1 * std2))
        rho2.append(np.sum(ts2[:l-i] * ts1[i:]) / ((l-1) * std1 * std2))
    return np.array(rho2[::-1] + rho1), level

def break_acf(ts_list, n):
    num = len(ts_list)
    all_ts = np.hstack(ts_list)
    mu = np.mean(all_ts)
    adj_ts_list = [ts-mu for ts in ts_list]
    rho = [1]
    p_rho = []
    
    
    for i in range(1, n):
        enum, l = 0, len(all_ts)
        for ts in adj_ts_list:
            enum += np.sum(ts[:-i] * ts[i:])
            
        rho.append(enum / ((l-num) * np.cov(all_ts)))
        p_rho.append(acf2pacf(rho, i))
    
    return rho, p_rho
    
    


        