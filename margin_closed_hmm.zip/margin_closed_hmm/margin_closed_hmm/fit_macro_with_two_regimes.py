
#%% Import data
with open("load_macro_data.py") as f:
    exec(f.read())

#%% 

import matplotlib.pyplot as plt

from mchmm.latent_update_fitter import \
    (fit_model_with_external, get_initial_model, fit_model_without_external, plot_single)

#%% 

initial_model2 = get_initial_model(data, 3, 2)
all_seq_info2 = {}
all_model_info2 = {}
for j in np.linspace(0.6, 0.8, 3):
    update_seq_info, update_model_info = fit_model_without_external(
            data, 3, initial_model2, cp=j
    )
    all_seq_info2[str(j)] = update_seq_info
    all_model_info2[str(j)] = update_model_info

#%%
import matplotlib.lines as mlines
color_dict = {
    'red': "#d62728",
    'blue': "#1f77b4",
    'orange': "#ff7f0e"
}
dash_list = ['-', '--', ':']
legend_lines = [
    mlines.Line2D([], [], color="#d62728", 
                  linestyle='-', label='Recession', linewidth=3)
]


y_labels = []
fig, ax = plt.subplots(figsize=(14, 4))
count = 0
for param, seq_info in all_seq_info2.items():
    y_labels.append(r'$\nu$={1}, $\xi$={2}'.format(*param.split(' ')))
    plot_single(date_index, np.array(seq_info[-1]), 0, show_value=count, color='red', linestyle='-', ax=ax)
    count += 1

ax.set(ylim=(-0.5, count-0.5),
        yticks=np.arange(count),
        yticklabels=y_labels)
ax.grid()
ax.set_xlabel('Year')
ax.set_xlim([-3800, 18400])
ax.legend(handles=legend_lines)
ax.fill_between(date_index, -0.5, count-0.5, where=(latent_seq==0), color='green', alpha=0.5)
fig.tight_layout()
fig.savefig('simulation_plots//two_inferred_regimes.pdf')
# %%
