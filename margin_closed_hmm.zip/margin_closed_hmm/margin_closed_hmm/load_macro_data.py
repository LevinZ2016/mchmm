import pathlib
import numpy as np
import scipy.stats as st
import pandas as pd


var_names = {
    'W875RX1': 'Income',
    'CMRMTSPLx': 'Sales',
    'INDPRO': 'IP',
    'CE16OV': 'Employ'
}
file_path = pathlib.Path().cwd()
fred_data = pd.read_csv(
    file_path.parent.joinpath('fred_data', 'fred_data.csv'), 
    index_col=0)
mdata = fred_data[var_names.keys()]
mdata = mdata.rename(columns=var_names).dropna()
mdata = mdata.query('date <= \'2020-02-01\'') * 100
reg_df = pd.read_csv(
    file_path.parent.joinpath('fred_data', 'NBER.csv'),
    index_col=0)
reg_df = reg_df.query('DATE <= \'2020-02-01\'')
reg_df = reg_df.iloc[:,0]
total_df = mdata.join(reg_df).dropna()

date_index = pd.to_datetime(reg_df.index, format='%Y-%m-%d')
latent_seq = 1 - reg_df.values
data = total_df.values[:,:4]