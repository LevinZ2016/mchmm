#%%

import numpy as np
import scipy.stats as st

import sys
if sys.platform == 'darwin':
    sys.path.append('/Users/levin/Library/CloudStorage/OneDrive-Personal/UBC/code/py_pack')
else:
    sys.path.append('E:/OneDrive/UBC/code/py_pack')
from statcorr import (StationCorr, BlockToeplitz)
from mc_corr import FullClosedCorr
from margins.uni_margins import skew_t_ab

def get_switch_point(v):
    v_arr = np.array(v)
    return np.where(np.diff(v_arr))[0]+1

def get_current_info(v_arr, corr_arr, max_k, dim, P):
    lag = min(len(v_arr)-1, max_k+1)
    v_cur = v_arr[:(max_k+2)]
    l = get_switch_point(v_cur)
    
    if not l.size:
        new_R = corr_arr[v_cur[0]].extend_corr(lag).R[:(lag*dim + dim), :(lag*dim + dim)]
    else:
        new_R = np.eye(lag*dim + dim)
        j = len(v_cur)
        for i in np.append(l[::-1], 0):
            new_R[(i*dim) : (j*dim), (i*dim) : (j*dim)] \
                = corr_arr[v_cur[i]].extend_corr(j-i).R[:((j-i)*dim), :((j-i)*dim)]
            if i > 0:
                new_R[(i-1)*dim : i*dim, i*dim:] \
                    = np.dot(P, new_R[i*dim : (i+1)*dim, i*dim:])
                new_R[i*dim:, (i-1)*dim : i*dim] \
                    = np.dot(new_R[i*dim:, i*dim : (i+1)*dim], P)
            j = i
    return lag, new_R

def get_new_obs(R, x, dim):
    z = st.norm.ppf(x.ravel())
    R11 = R[:dim, :dim]
    R22 = R[dim:, dim:]
    R12 = R[:dim, dim:]
    R21 = R[dim:, :dim]
    R1_2 = R11 - np.matmul(R12, np.linalg.solve(R22, R21))
    mu1_2 = np.matmul(R12, np.linalg.solve(R22, z))
    new_x = st.multivariate_normal.rvs(mean=mu1_2, cov=R1_2)
    return st.norm.cdf(new_x)

def get_mc_corrs(serial_correlations, cross_sectional_correlations):
    num_states = len(cross_sectional_correlations.keys())
    dim = len(serial_correlations.keys())
    k = len(list(serial_correlations.values())[0][0])
    mc_corrs = []
    for i in range(num_states):
        corrs = []
        for d in serial_correlations.values():
            uni_btm = BlockToeplitz(1, k)
            R = uni_btm.get_btm_fr_par(d[i])
            stat_corr = StationCorr(1, k, R)
            corrs.append(stat_corr)
        mcc = FullClosedCorr(corrs, dim, k)
        mcc.par = list(cross_sectional_correlations.values())[i]
        mc_corrs.append(mcc.get_stat_corr())
    return mc_corrs

def get_simulation(params_dict):
    start_prob = params_dict['start_probability']
    trans_mat = params_dict['transition_matrix']
    serial_correlations = params_dict['serial_correlations']
    cross_sectional_correlations = params_dict['cross_sectional_correlations']
    margin_parameters = params_dict['margin_parameters']

    corr_arr = get_mc_corrs(
        serial_correlations, cross_sectional_correlations
    )
    dim = len(serial_correlations.keys())
    k = len(list(serial_correlations.values())[0][0])
    P = np.diag(params_dict['regime_switching_correlations'])
    mgs = [[skew_t_ab(par=x) for x in y] 
            for y in list(margin_parameters.values())]

    Z, zobs, obs = [], [], []
    for i in range(params_dict['size']):
        # get new regime
        if not Z:
            Z.append(np.argmax(np.random.multinomial(1, start_prob)))
        else:
            new_Z = np.argmax(np.random.multinomial(1, trans_mat[Z[-1]]))
            Z.append(new_Z)
        # get new observation
        new_lag, new_R = get_current_info(Z[::-1], corr_arr, k, dim, P)
        old_zobs = np.array(zobs[-new_lag:][::-1])
        new_zobs = get_new_obs(new_R, old_zobs, dim)
        zobs.append(new_zobs)
        
        new_obs = [mgs[d][Z[-1]].ppf(x).item() 
                    for d, x in enumerate(new_zobs)]
        obs.append(new_obs)

    Z = np.array(Z)
    zobs = np.array(zobs)
    obs = np.array(obs)
    return Z, zobs, obs
# %%
