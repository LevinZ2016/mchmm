
#%%

import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt

import sys
if sys.platform == 'darwin':
    sys.path.append('/Users/levin/Library/CloudStorage/OneDrive-Personal/UBC/code/py_pack')
else:
    sys.path.append('E:/OneDrive/UBC/code/py_pack')
from statcorr import (StationCorr, BlockToeplitz)
from mc_corr import FullClosedCorr
from margins.uni_margins import skew_t_ab


#%% Hyper parameters

k_arr = [1] * 4
num_reg = 2

#%% Generate transition matrix

trans_mat = np.array([[0.980, 0.020],
                      [0.010, 0.990]])

#%% Generate correlation matrix for each regime

get_rho = lambda x: 0.4*np.sign(x) + 0.5*x
dim = len(k_arr)
max_k = max(k_arr)
mcc_arr = []
for i in range(num_reg):
    uni_R = []
    for j in k_arr:
        uni_btmj = BlockToeplitz(1, j)
        rhos = get_rho(np.random.rand(j)).round(1)
        print(rhos)
        Rj = uni_btmj.get_btm_fr_par(rhos)
        scorrj = StationCorr(1, j, Rj)
        uni_R.append(scorrj)

    mcc = FullClosedCorr(uni_R, dim, max_k)
    
    flag = 1
    while flag:
        mcc.par = (np.random.rand(mcc.cross_par_dim)).round(1)
        flag = not mcc.check_corr_mat()
            
    mcc_arr.append(mcc)
corr_arr = [x.get_stat_corr() for x in mcc_arr]

'''
serial_par = [[0.6, 0.5, 0.5, 0.4],
              [0.5, 0.8, 0.6, 0.5]]
cross_par = [[0.6, 0.6, 0.8, 0.3, 0.7, 0.4], 
             [0.2, 0.2, 0.2, 0.1, 0.8, 0.1]]

'''
#%% Generate dependence parameters between regimes

def check_comp(R1, R2, P):
    B = np.dot(np.dot(P, R2), P)
    diff_R = R1.copy()
    diff_R[-dim:, -dim:] = diff_R[-dim:, -dim:] - B
    return all(np.linalg.eig(diff_R)[0] > 0)
    

flag = 1

while flag:
    P = np.round(np.diag(np.random.rand(dim) * 0.5), 1)
    is_pass = True
    for i in range(num_reg):
        for j in range(i+1, num_reg):
            R1 = mcc_arr[i].get_corr_mat()
            R2 = mcc_arr[j].get_corr_mat()
            
            check1 = check_comp(R1, R2[:dim, :dim], P)
            check2 = check_comp(R2, R1[:dim, :dim], P)
            
            if not (check1 and check2):
                is_pass = False
    
    if is_pass:
        flag = 0

print(P)
'''
P = [[0.4, 0.0, 0.0, 0.0],
     [0.0, 0.3, 0.0, 0.0],
     [0.0, 0.0, 0.4, 0.0],
     [0.0, 0.0, 0.0, 0.3]]
'''

#%%

def get_switch_point(v):
    v_arr = np.array(v)
    return np.where(np.diff(v_arr))[0]+1

def get_current_info(v_arr, corr_arr, max_k):
    lag = min(len(v_arr)-1, max_k+1)
    
    v_cur = v_arr[:(max_k+2)]
    l = get_switch_point(v_cur)
    
    if not l.size:
        new_R = corr_arr[v_cur[0]].extend_corr(lag).R[:(lag*dim + dim), :(lag*dim + dim)]
    else:
        new_R = np.eye(lag*dim + dim)
        j = len(v_cur)
        for i in np.append(l[::-1], 0):
            new_R[(i*dim) : (j*dim), (i*dim) : (j*dim)] \
                = corr_arr[v_cur[i]].extend_corr(j-i).R[:((j-i)*dim), :((j-i)*dim)]
            if i > 0:
                new_R[(i-1)*dim : i*dim, i*dim:] \
                    = np.dot(P, new_R[i*dim : (i+1)*dim, i*dim:])
                new_R[i*dim:, (i-1)*dim : i*dim] \
                    = np.dot(new_R[i*dim:, i*dim : (i+1)*dim], P)
            j = i
        
    return lag, new_R
        
def get_new_obs(R, x):
    z = st.norm.ppf(x.ravel())
    R11 = R[:dim, :dim]
    R22 = R[dim:, dim:]
    R12 = R[:dim, dim:]
    R21 = R[dim:, :dim]
    R1_2 = R11 - np.matmul(R12, np.linalg.solve(R22, R21))
    mu1_2 = np.matmul(R12, np.linalg.solve(R22, z))
    new_x = st.multivariate_normal.rvs(mean=mu1_2, cov=R1_2)
    return st.norm.cdf(new_x)

def cond_logc(u, R, dim):
    if len(u.shape) == 1:
        u = np.array([u])
        R = np.array([R])
    z = st.norm.ppf(u)
    z1, z2 = z[:,:dim], z[:,dim:]
    z1 = z1[:, :, None]
    z2 = z2[:, :, None]
    R11 = R[:, :dim, :dim]
    R22 = R[:, dim:, dim:]
    R12 = R[:, :dim, dim:]
    R21 = R[:, dim:, :dim]
    R11_2 = R11 - np.matmul(R12, np.linalg.solve(R22, R21))
    mu11_2 = np.matmul(R12, np.linalg.solve(R22, z2))
    logpdf = -0.5 * np.log(np.linalg.det(R11_2))[:, None] \
             -0.5 * ((z1 - mu11_2) * \
                     np.linalg.solve(R11_2, z1 - mu11_2)).sum(axis=1) \
             +0.5 * (z1 * z1).sum(axis=1)
    return logpdf.ravel()

#%%

means = np.array([[4., 2., -3.],
                  [2., 0., -2.],
                  [1., -1., -1.]])
covs = np.array([[1.00, 1.00, 1.00],
                 [1.50, 1.50, 1.50],
                 [1.00, 1.00, 1.00]])
means = means[:-1, :-1]
covs = covs[:-1, :-1]

size = 1000
Z, zobs, obs = [], [], []
for i in range(size):
    
    # get new regime
    if not Z:
        Z.append(num_reg//2)
    else:
        new_Z = np.where(np.random.multinomial(1, trans_mat[Z[-1]]) == 1)[0].item()
        Z.append(new_Z)
        
    # get new observation
    new_lag, new_R = get_current_info(Z[::-1], corr_arr, max_k)
    old_zobs = np.array(zobs[-new_lag:][::-1])
    new_zobs = get_new_obs(new_R, old_zobs)
    zobs.append(new_zobs)
    
    new_obs = st.norm.ppf(new_zobs) * np.sqrt(covs[Z[-1]]) + means[Z[-1]]
    obs.append(new_obs)

Z = np.array(Z)
zobs = np.array(zobs)
obs = np.array(obs)

plt.plot(Z)

#%%

plt.plot(obs[:,0])
plt.plot(obs[:,1])

#%%

i = 2

loglik = 0
for l in range(len(Z)):
    v_arr = Z[:(l+1)][::-1]
    new_lag, new_R = get_current_info(v_arr, corr_arr, max_k)
    old_zobs = zobs[:(l+1)][::-1][:(new_lag+1)][:,i]
    
    loglik += st.norm.logpdf(obs[l][i], 
                             means[v_arr[0]][i], 
                             np.sqrt(covs[v_arr[0]][i]))
    new_zobs = st.norm.cdf(obs[l][i], 
                           means[v_arr[0]][i], 
                           np.sqrt(covs[v_arr[0]][i]))
    
    sub_R = new_R[np.arange(new_lag+1)*dim+i, :][:, np.arange(new_lag+1)*dim+i]
    
    # if len(v_arr) > 2:
    #     sub_R2 = Rcom[tuple(v_arr[:3])]
    # else:
    #     use_v = tuple(v_arr[:3]) + (0,) * (3 - len(v_arr))
    #     sub_R2 = Rcom[use_v][:len(v_arr), :len(v_arr)]
    
    assert np.round(old_zobs[0],6) == np.round(new_zobs, 6)
    loglik += cond_logc(old_zobs, sub_R, 1)
    
    # if len(v_arr) > 1:
    #     loglik += np.log(trans_mat[v_arr[1], v_arr[0]])
    
print(loglik)


# %%
