
#%% Import data

with open("load_macro_data.py") as f:
    exec(f.read())

#%% 

import matplotlib.pyplot as plt

import mchmm.latent_update_fitter as fwl
from mchmm.latent_update_fitter import \
    (fit_model_with_external, get_initial_model, fit_model_without_external, plot_single)

#%% 

initial_model3 = get_initial_model(data, 3, 3)
print('Start iterations on sequence...')
all_seq_info3 = {}
all_model_info3 = {}
for l in [1, 2, 3]:
    for cl in [2, 3]:
        for cp in np.linspace(0.5, 0.8, 4):
            update_seq_info, update_model_info = fit_model_without_external(
                data, 3, initial_model3, l=l, cl=cl, cp=cp
            )
            all_seq_info3[f'{l-1} {cl} {cp:.1f}'] = update_seq_info
            all_model_info3[f'{l-1} {cl} {cp:.1f}'] = update_model_info

#%%

y_labels = ['External seq']
fig, ax = plt.subplots(figsize=(20, 10))
plot_single(date_index, latent_seq, 0, ax)
count = 1
for param, seq_info in all_seq_info3.items():
    y_labels.append(r'$\tau$={0}, $\nu$={1}, $\gamma$={2}'.format(*param.split(' ')))
    plot_single(date_index, seq_info[-1], count, ax)
    count += 1

ax.set(ylim=(-0.5, count-0.5),
       yticks=np.arange(count),
       yticklabels=y_labels)
ax.grid()
ax.legend(handles=fwl.legend_lines)

# %%

