
#%%

import numpy as np
import scipy.stats as st
from copy import deepcopy
from scipy.optimize import (minimize, Bounds)

from statcorr import FullClosedCorr


#%%

class MCVAR():

    def __init__(self, dim, k, corr_arr):
        self.dim = dim
        self.num_par = (self.dim - 1) * self.dim //2 
        self.k = k
        self.mc_corr = FullClosedCorr(corr_arr, dim, k)

    def get_cloglik_fr_cross_par(self, par, zdata_arr):
        result = 0
        copy_model = deepcopy(self)
        copy_model.mc_corr.par = par
        for zdata in zdata_arr:
            result += copy_model.get_copula_loglik(zdata)
        return result

    def get_copula_loglik(self, zdata):
        assert self.mc_corr.par_arr is not None, 'No cross-sectional dependence pars!'
        if self.mc_corr.check_corr_mat():
            stat_corr = self.mc_corr.get_stat_corr()
            cloglik = stat_corr.get_likelihood(zdata) \
                        - st.norm.logpdf(zdata).sum()
            return cloglik
        else:
            return -1e6

    def get_init_cross_corr(self, zdata_arr):
        corr = np.corrcoef(np.vstack(zdata_arr).T)
        copy_mc = deepcopy(self.mc_corr)
        par = copy_mc.get_par_fr_arr(corr)
        alpha = 1.
        while True:
            copy_mc.par = alpha * par
            if copy_mc.check_corr_mat():
                print(f'Current alpha is {alpha}')
                return copy_mc.par
            else:
                alpha = alpha * 0.9

    def fit_cross_corr(self, zdata_arr):
        self.mc_corr.par_arr = np.eye(self.dim)
        target_f = lambda par: -self.get_cloglik_fr_cross_par(par, zdata_arr)
        x0 = self.get_init_cross_corr(zdata_arr)
        print(f'The starting point is {x0}')
        lb = [-0.99]*self.num_par
        ub = [0.99]*self.num_par
        b = Bounds(lb=lb, ub=ub, keep_feasible=True)
        sol = minimize(target_f, x0, method='L-BFGS-B', jac='3-point',
                        bounds=b, options={'gtol': 1e-5, 'disp': False})
        self.mc_corr.par = sol.x
        self.loglik = -sol.fun + st.norm.logpdf(np.vstack(zdata_arr)).sum()


# %%
