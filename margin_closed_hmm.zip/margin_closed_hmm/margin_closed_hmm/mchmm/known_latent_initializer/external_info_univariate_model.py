
#%%

import numpy as np
import scipy.stats as st
from copy import deepcopy
from scipy.optimize import (minimize, Bounds)
from itertools import product

from mchmm.model_visual_and_inference.em_funcs import (ForBackwardAlg, GaussianQ)
from .univariate_mixture import UniMixture

import margins.uni_margins as umg
from statcorr import StationCorr

def parameter_optimize(f, b, x0, tol):
    sol = minimize(f, x0, method='L-BFGS-B', jac='2-point',
                    bounds=b, options={'gtol': tol, 'disp': False})
    return sol

def get_switch_point(v):
    v_arr = np.array(v)
    return np.where(np.diff(v_arr))[0]+1

def acf2pacf(rho, n):
    if n == 1:
        return rho[n]
    else:
        A1 = np.array([[rho[0], rho[n]],[rho[n], rho[0]]])
        A2 = np.zeros([n-1, n-1])
        A12 = np.zeros([n-1, 2])
        for i in range(n-1):
            A2[i, i:] = rho[:(n-1-i)]
            A12[i] = [rho[i+1], rho[n-1-i]]
        A2 = A2 + A2.T - np.eye(n-1)
        cov = A1 - np.dot(A12.T, np.linalg.solve(A2, A12))
    return cov[0,1] / cov[0,0]

def break_acf(ts_list, n):
    num = len(ts_list)
    if num == 0: return np.zeros(n)
    all_ts = np.hstack(ts_list)
    mu = np.mean(all_ts)
    adj_ts_list = [ts-mu for ts in ts_list]
    rho, p_rho = [1], []
    for i in range(1, n+1):
        enum, l = 0, len(all_ts)
        for ts in adj_ts_list:
            enum += np.sum(ts[:-i] * ts[i:])
        rho.append(enum / ((l-num) * np.cov(all_ts)))
        p_rho.append(acf2pacf(rho, i))
    return p_rho

class UniRegimeLink():
    
    def get_par_bound(self, Rs):
        l = np.zeros(self.k+1)
        l[-1] = 1.
        h = [np.dot(l, np.linalg.solve(R[1:, 1:], l)) for R in Rs]
        return 1 / np.sqrt(max(h))
    
    def __init__(self, k):
        self.k = k
        
    def corr_com_fr_Rs(self, Rs, link_par):
        assert Rs[0].shape[0] == (self.k+2), 'Dimension must match'
        bound = self.get_par_bound(Rs)
        rho = bound * link_par
        num_reg = len(Rs)
        Rcom = np.zeros([num_reg] * (self.k+2) + [(self.k+2), (self.k+2)])
        
        for v in product(range(num_reg), repeat=self.k+2):
            l = get_switch_point(v)
            v_new = v[0]
            tem_R = np.eye(self.k+2)
            
            if l.size:
                l = l[0]
                tem_R[:l, :l] = Rs[v_new][:l, :l]
                tem_R[l-1, l] = rho
                tem_R[l, l-1] = rho
            else:
                tem_R = Rs[v_new]
            Rcom[v] = tem_R
        return Rcom
        
    def get_com_corr(self, corr_arr, link_par):
        Rs = np.array([corr.extend_corr_one() for corr in corr_arr])
        return self.corr_com_fr_Rs(Rs, link_par)
    
    def get_rho(self, corr_arr, link_par):
        Rs = np.array([corr.extend_corr_one() for corr in corr_arr])
        return self.get_par_bound(Rs) * link_par


#%%    
class UniHMMReg():
    
    def __init__(self, k, num_reg):
        self.dim = 1
        self.k = k
        self.num_reg = num_reg

    def break_data(self, reg_val, data, regs):
        index = np.where(regs == reg_val)[0]
        if len(index) == 0: return []
        
        index_diff = index[1:] - index[:-1]
        iter_index = np.where(index_diff>1)[0]
        iter_index = np.append(-1, iter_index)
        iter_index = np.append(iter_index, len(index)-1)
        
        result = []
        for i in range(len(iter_index)-1):
            l1 = index[iter_index[i] + 1]
            l2 = index[iter_index[i+1]] + 1
            result.append(data[l1:l2])
        return result
        
    def get_stack_data(self, inv_data):
        n = len(inv_data)
        stack_data = np.empty([n-self.k-1, self.k+2])
        for i in range(self.k+2):
            stack_data[:, i] = inv_data[i:(n-self.k-1+i)]
        return stack_data

    def get_margin_data_fr_input(self, mg_arr, data):
        inv_data = data[::-1, None]
        n = len(data)
        
        # loglik of margins
        loglik_mg, inv_udata \
            = [], np.zeros([n, self.num_reg, self.dim]) * np.nan
        for i in range(self.num_reg):
            loglik_mg.append(mg_arr[i].logpdf(inv_data))
            inv_udata[:,i,:] = mg_arr[i].cdf(inv_data)[:, None]
        loglik_mg = np.array(loglik_mg).T
        return loglik_mg, inv_udata
    
    def get_corr_com_fr_input(self, corr_arr, link_par):
        Rcom = UniRegimeLink(self.k).get_com_corr(corr_arr, link_par)
        return Rcom
    
    def get_alg_obj(self, data):
        loglik_mg, inv_udata = self.get_margin_data_fr_input(self.mg_arr, data)
        Rcom = self.get_corr_com_fr_input(self.corr_arr, self.link_par)
        gq_obj = GaussianQ()
        trans_arr = gq_obj.get_trans_arr(loglik_mg, inv_udata, Rcom)
        alg = ForBackwardAlg(self.k+1, data)
        alg.runfrarr(self.log_init_prob, self.log_trans_mat, trans_arr)
        return alg, trans_arr
    
    def get_copy_mg(self, mg_par):
        n = self.mg_arr[0].par_dim
        assert len(mg_par) == (self.num_reg * n)
        copy_mg = deepcopy(self.mg_arr)
        for i in range(self.num_reg):
            copy_mg[i].par = mg_par[(i*n) : (i*n + n)]
        return copy_mg
    
    def get_copy_corr(self, corr_par):
        assert len(corr_par) == (self.num_reg * self.k) + 1
        copy_corr = deepcopy(self.corr_arr)
        for i in range(self.num_reg):
            copy_corr[i].par = corr_par[(i*self.k) : ((i+1)*self.k)]
        return copy_corr, corr_par[-1]
    
    def get_init_mg_par(self):
        mg_par, lb_mg, ub_mg = [], [], []
        for i in range(self.num_reg):
            mg_par = np.append(mg_par, self.mg_arr[i].par)
            lb_mg = np.append(lb_mg, self.mg_arr[i].lb)
            ub_mg = np.append(ub_mg, self.mg_arr[i].ub)
        return mg_par, lb_mg, ub_mg
    
    def get_init_corr_par(self):
        corr_par = []
        for i in range(self.num_reg):
            corr_par = np.append(corr_par, self.corr_arr[i].par)
        #lb_corr = np.maximum(corr_par - 0.5*np.abs(corr_par), -0.99)
        #ub_corr = np.minimum(corr_par + 0.5*np.abs(corr_par), 0.99)
        corr_par = np.append(corr_par, 0)
        lb_corr = [-0.95] * len(corr_par)
        ub_corr = [0.95] * len(corr_par)
        return corr_par, lb_corr, ub_corr
    
    def get_start_loglik(self, Rcom, inv_udata, inv_reg):
        v_arr = inv_udata[-(self.k+1):]
        z_arr = st.norm.ppf(v_arr)
        R = Rcom[tuple(inv_reg[-(self.k+1):])][0, :-1, :-1]
        logpdf = -0.5 * np.log(np.linalg.det(R)) \
                 -0.5 * np.dot(z_arr, np.linalg.solve(R, z_arr)) \
                 +0.5 * np.dot(z_arr, z_arr)
        return logpdf
                 
    def get_loglik(self, mg_arr, corr_arr, link_par, data, regs):
        Rcom = self.get_corr_com_fr_input(corr_arr, link_par)
        loglik_mg, inv_udata = self.get_margin_data_fr_input(mg_arr, data)
        gq_obj = GaussianQ()
        n = len(data)
        inv_reg = regs[::-1]
        
        loglik_mg = loglik_mg[tuple(range(n)), tuple(inv_reg)]
        
        inv_udata = inv_udata[tuple(range(n)), tuple(inv_reg)].ravel()
        reg_arr = self.get_stack_data(inv_reg)
        udata_arr = self.get_stack_data(inv_udata)
        R_arr = Rcom[tuple(reg_arr.T.astype(int))]
        
        loglik1 = self.get_start_loglik(Rcom, inv_udata, inv_reg)
        loglik2 = gq_obj.cond_logc(udata_arr, R_arr, self.dim)
        return loglik1 + loglik2.sum() + loglik_mg.sum()
    
    def get_init_margins(self, data, regs, dist_cls):
        self.mg_par_dim = dist_cls().par_dim * self.num_reg
        self.mg_arr = []
        for i in range(self.num_reg):
            self.mg_arr.append(dist_cls())
            sub_data = data[regs == i]
            self.mg_arr[-1].fit(sub_data)
    
    def get_init_reg_corr(self, data, regs):
        self.corr_arr = []
        for i in range(self.num_reg):
            data_list = self.break_data(i, data, regs)
            udata_list = [self.mg_arr[i].cdf(x) for x in data_list]
            zdata_list = [st.norm.ppf(x) for x in udata_list]
            self.corr_arr.append(StationCorr(self.dim, self.k))
            self.corr_arr[-1].par = break_acf(zdata_list, self.k)
    
    def get_init_par(self, data, regs, dist_cls):
        self.corr_par_dim = self.k * self.num_reg
        self.link_par = 0
        self.get_init_margins(data, regs, dist_cls)
        self.get_init_reg_corr(data, regs)
        mg_par, lb_mg, ub_mg = self.get_init_mg_par()
        corr_par, lb_corr, ub_corr = self.get_init_corr_par()
        return np.append(mg_par, corr_par), \
               np.append(lb_mg, lb_corr), \
               np.append(ub_mg, ub_corr)

    def get_nllk_fr_par(self, par, data, regs):
        copy_mg = self.get_copy_mg(par[:self.mg_par_dim])
        copy_corr, copy_link = self.get_copy_corr(par[self.mg_par_dim:])
        return -self.get_loglik(copy_mg, copy_corr, copy_link, data, regs)
    
    def fit_trans_mat(self, regs):
        self.trans_mat = np.zeros([self.num_reg]*2)
        self.init_prob = np.zeros([self.num_reg]) + 1e-6
        for i in range(len(regs)-1):
            self.trans_mat[regs[i], regs[i+1]] += 1.
        self.trans_mat[self.trans_mat==0.] = 1e-6 * len(regs)
        self.trans_mat = self.trans_mat / self.trans_mat.sum(axis=1)[:, None]
        self.init_prob[regs[0]] = 1 - (self.num_reg - 1) * 1e-6
        self.log_init_prob = np.log(self.init_prob)
        self.log_trans_mat = np.log(self.trans_mat)
        
    def fit_model(self, data, regs, dist_cls=umg.skew_t_ab, tol=1e-3):
        self.dist_cls = dist_cls
        self.fit_trans_mat(regs)
        init_par, lb, ub = self.get_init_par(data, regs, dist_cls)
        f = lambda par: self.get_nllk_fr_par(par, data, regs)
        b = Bounds(lb=lb, ub=ub, keep_feasible=True)
        sol = parameter_optimize(f, b, init_par, tol)
        par = sol.x
        self.mg_arr = self.get_copy_mg(par[:self.mg_par_dim])
        self.corr_arr, self.link_par \
                        = self.get_copy_corr(par[self.mg_par_dim:])
        self.rho = UniRegimeLink(self.k).get_rho(self.corr_arr, self.link_par)
# %%
