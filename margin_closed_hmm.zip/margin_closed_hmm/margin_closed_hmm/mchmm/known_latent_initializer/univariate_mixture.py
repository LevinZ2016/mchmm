
#%%

import numpy as np
from copy import deepcopy
from sklearn.cluster import KMeans
from scipy.special import logsumexp
import matplotlib.pyplot as plt

import margins.uni_margins as umg

#%%

class UniMixture():
    
    def __init__(self, n_states, dist_cls=umg.Gaussian):
        self.n_states, self.dist_cls = n_states, dist_cls
        self.mdists = [dist_cls() for _ in range(self.n_states)]
    
    def get_log_emission(self, data):
        log_emission = [m.logpdf(data) for m in self.mdists]
        return np.array(log_emission).T
        
    def Estep(self, data):
        log_emission = self.get_log_emission(data)
        bw = BaumWelch(self.log_init_prob, 
                        self.log_trans_mat, 
                        log_emission)
        self.log_gamma = bw.log_gamma()
        self.log_xi = bw.log_xi()
        old_loglik = self.loglik
        self.loglik = bw.likelihood()
        self.dloglik = self.loglik - old_loglik
    
    def Mstep(self, data):
        for i in range(self.n_states):
            self.mdists[i].fit(data, weights=np.exp(self.log_gamma[:,i]))
        
        self.log_init_prob = self.log_gamma[0]
        self.log_trans_mat = logsumexp(self.log_xi, axis=0) \
                            - logsumexp(self.log_gamma[:-1], axis=0)[:,None]
        
    def get_init(self, data, init_model):
        if init_model is None:
            self.log_init_prob = np.log([1/self.n_states] \
                                        * self.n_states)
            self.log_trans_mat = np.log(np.ones([self.n_states]*2) \
                                        / self.n_states)
            
            kmeans = KMeans(n_clusters=self.n_states, 
                            random_state=0)
            kmeans.fit(data[:, None])
            for i in range(self.n_states):
                sub_data = data[kmeans.labels_==i]
                self.mdists[i].fit(sub_data)
        else:
            self.mdists = deepcopy(init_model.mdists)
            self.log_init_prob = deepcopy(init_model.log_init_prob)
            self.log_trans_mat = deepcopy(init_model.log_trans_mat)
        self.order_par()
    
    def fit(self, data, init_model=None, num_itr=100, tol=1e-5):
        self.get_init(data, init_model)
        self.loglik = -np.inf
        flag, count = 1, 0
        while flag: 
            self.Estep(data)
            self.Mstep(data)
            count += 1
            if (count > num_itr) or (self.dloglik < tol):
                flag = 0
        self.order_par()
        
    def order_par(self):
        order = np.argsort([m.ppf(0.5).item() for m in self.mdists])
        self.mdists = [self.mdists[i] for i in order]
        self.log_init_prob = self.log_init_prob[order]
        self.log_trans_mat = self.log_trans_mat[order][:, order]
    
    def get_pi(self):
        trans_mat = np.exp(self.log_trans_mat)
        A = trans_mat.T - np.eye(self.n_states)
        A[-1] = [1] * self.n_states
        b = np.zeros(self.n_states)
        b[-1] = 1
        return np.linalg.solve(A, b)
    
    def plot_mix(self, data=None, bins=None):
        stat_p = self.get_pi()
        min_val = min([m.ppf(0.01) for m in self.mdists])
        max_val = max([m.ppf(0.99) for m in self.mdists])
        vals = np.linspace(min_val, max_val, 100)
        logpdf = np.array([m.logpdf(vals) + np.log(stat_p[i]) 
                           for (i,m) in enumerate(self.mdists)])
        mlogpdf = logsumexp(logpdf, axis=0)
        
        fig, ax = plt.subplots()
        for i in range(self.n_states):
            ax.plot(vals, np.exp(logpdf[i]), 
                    label=f'Class {i}, w={stat_p[i]:.2f}')
        ax.plot(vals, np.exp(mlogpdf), label='Mix')
        if data is not None:
            if bins:
                ax.hist(data, density=True, bins=bins)
            else:
                ax.hist(data, density=True)
        ax.legend()
        plt.grid()
        plt.show()
        
    def get_predict_prob(self, data):
        log_emission = self.get_log_emission(data)
        bw = BaumWelch(self.log_init_prob, 
                        self.log_trans_mat, 
                        log_emission)
        log_gamma = bw.log_gamma()
        return np.exp(log_gamma)
        
#%%

class IndepMixture():
    
    def __init__(self, dim, n_states, dist_cls=umg.Gaussian):
        self.dim = dim
        self.n_states, self.dist_cls = n_states, dist_cls
        self.mdists = [
            [dist_cls() for _ in range(self.dim)] \
                        for _ in range(self.n_states)
        ]
    
    def get_log_emission(self, data):
        log_emission = np.zeros([len(data), self.n_states])
        for i in range(self.n_states):
            for j in range(self.dim):
                log_emission[:, i] += self.mdists[i][j].logpdf(data[:,j])
        return log_emission
        
    def Estep(self, data):
        log_emission = self.get_log_emission(data)
        bw = BaumWelch(self.log_init_prob, 
                        self.log_trans_mat, 
                        log_emission)
        self.log_gamma = bw.log_gamma()
        self.log_xi = bw.log_xi()
        old_loglik = self.loglik
        self.loglik = bw.likelihood()
        self.dloglik = self.loglik - old_loglik
    
    def Mstep(self, data):
        for i in range(self.n_states):
            w = np.exp(self.log_gamma[:,i])
            for j in range(self.dim):
                self.mdists[i][j].fit(data[:,j], 
                                    weights=w)
        
        self.log_init_prob = self.log_gamma[0]
        self.log_trans_mat = logsumexp(self.log_xi, axis=0) \
                            - logsumexp(self.log_gamma[:-1], axis=0)[:,None]
        
    def get_init(self, data, init_model):
        self.log_init_prob = np.log([1/self.n_states] \
                                    * self.n_states)
        self.log_trans_mat = np.log(np.ones([self.n_states]*2) \
                                    / self.n_states)
        
        kmeans = KMeans(n_clusters=self.n_states, 
                        random_state=0)
        kmeans.fit(data)
        for i in range(self.n_states):
            sub_data = data[kmeans.labels_==i]
            for j in range(self.dim):
                self.mdists[i][j].fit(sub_data[:,j])
        self.order_par()
    
    def fit(self, data, init_model=None, num_itr=100, tol=1e-5):
        assert data.shape[1] == self.dim
        self.get_init(data, init_model)
        self.loglik = -np.inf
        flag, count = 1, 0
        while flag: 
            self.Estep(data)
            self.Mstep(data)
            count += 1
            if (count > num_itr) or (self.dloglik < tol):
                flag = 0
        self.order_par()
        
    def order_par(self):
        m_values = [0.] * self.n_states
        for i in range(self.n_states):
            for j in range(self.dim):
                m_values[i] += self.mdists[i][j].ppf(0.5).item()
        order = np.argsort(m_values)
        self.mdists = [self.mdists[i] for i in order]
        self.log_init_prob = self.log_init_prob[order]
        self.log_trans_mat = self.log_trans_mat[order][:, order]
    
    def get_pi(self):
        trans_mat = np.exp(self.log_trans_mat)
        A = trans_mat.T - np.eye(self.n_states)
        A[-1] = [1] * self.n_states
        b = np.zeros(self.n_states)
        b[-1] = 1
        return np.linalg.solve(A, b)
    
    def plot_mix(self, var_ind, data=None, bins=None):
        stat_p = self.get_pi()
        mgs = [m[var_ind] for m in self.mdists]
        min_val = min([m.ppf(0.01) for m in mgs])
        max_val = max([m.ppf(0.99) for m in mgs])
        vals = np.linspace(min_val, max_val, 100)
        logpdf = np.array([m.logpdf(vals) + np.log(stat_p[i]) 
                           for (i,m) in enumerate(mgs)])
        mlogpdf = logsumexp(logpdf, axis=0)
        
        fig, ax = plt.subplots()
        for i in range(self.n_states):
            ax.plot(vals, np.exp(logpdf[i]), 
                    label=f'Class {i}, w={stat_p[i]:.2f}')
        ax.plot(vals, np.exp(mlogpdf), label='Mix')
        if data is not None:
            if bins:
                ax.hist(data[:,var_ind], density=True, bins=bins)
            else:
                ax.hist(data[:,var_ind], density=True)
        ax.legend()
        plt.grid()
        plt.show()
        
    def get_predict_prob(self, data):
        log_emission = self.get_log_emission(data)
        bw = BaumWelch(self.log_init_prob, 
                        self.log_trans_mat, 
                        log_emission)
        log_gamma = bw.log_gamma()
        return np.exp(log_gamma)
        
        
#%%        
class BaumWelch():
    
    def __init__(self, log_init_prob, log_trans_mat, log_emission):
        
        self.log_init_prob = log_init_prob
        self.log_trans_mat = log_trans_mat
        self.n_states = len(log_init_prob)
        self.n_obs = log_emission.shape[0]
        self.log_emission = log_emission
        
    def forward(self):
        
        log_alpha = np.empty([self.n_obs, self.n_states])
        log_alpha[0] = self.log_init_prob + self.log_emission[0]
        
        for t in range(1, self.n_obs):
            log_alpha[t] = logsumexp(log_alpha[t-1, np.newaxis] \
                                    + self.log_trans_mat.T, 
                                    axis=1) \
                            + self.log_emission[t]
        return log_alpha
    
    def backward(self):
        
        log_beta = np.zeros([self.n_obs, self.n_states])
        for t in range(self.n_obs-1, 0, -1):
            log_beta[t-1] = logsumexp(log_beta[t] + self.log_emission[t] \
                                     + self.log_trans_mat, axis=1)
        return log_beta
    
    def log_gamma(self):
        temp = self.forward() + self.backward()
        return temp - logsumexp(temp, axis=1)[:, np.newaxis]
    
    def log_xi(self):
        log_alpha = self.forward()[:-1, :, np.newaxis]
        log_beta = self.backward()[1:, np.newaxis, :]
        log_ab = self.log_trans_mat[np.newaxis, :, :] \
                 + self.log_emission[1:, np.newaxis, :]
        temp = log_alpha + log_beta + log_ab
        log_sum_temp = logsumexp(logsumexp(temp, axis=2), axis=1)
        return temp - log_sum_temp[:, np.newaxis, np.newaxis]
        
    def likelihood(self):
        temp = self.forward() + self.backward()
        return logsumexp(temp, axis=1)[0]
        
        
# %%
