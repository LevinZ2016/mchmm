
import numpy as np
import scipy.stats as st
from .external_info_univariate_model import UniHMMReg
from statcorr import MCVAR

class MultiHMMReg():

    def __init__(self, dim, k, num_reg):
        self.dim = dim
        self.k = k
        self.num_reg = num_reg

    def _extract_parameters_from_uni(self, uni_models):
        self.states_margin_arr = []
        self.states_corr_arr = []
        margin_par = []
        serial_par = []
        for i in range(self.num_reg):
            corr_arr = []
            margin_arr = []
            sub_margin_par = []
            sub_serial_par = []
            for j in range(self.dim):
                corr_arr.append(uni_models[j].corr_arr[i])
                sub_serial_par.append(uni_models[j].corr_arr[i].par)
                margin_arr.append(uni_models[j].mg_arr[i])
                sub_margin_par.append(uni_models[j].mg_arr[i].par)
            self.states_corr_arr.append(corr_arr)
            self.states_margin_arr.append(margin_arr)
            margin_par.append(sub_margin_par)
            serial_par.append(sub_serial_par)

        self.margin_par = np.array(margin_par)
        self.serial_par = np.array(serial_par)
        self.log_init_prob = uni_models[0].log_init_prob
        self.log_trans_mat = uni_models[0].log_trans_mat

    def _get_state_uniform(self, reg_val, data):
        udata = []
        for i in range(self.dim):
            udata.append(self.states_margin_arr[reg_val][i].cdf(data[:, i]))
        return np.array(udata).T

    def fit_serial_pcor(self, data, regs):
        uni_models = []
        for i in range(self.dim):
            model = UniHMMReg(self.k, self.num_reg)
            model.fit_model(data[:, i], regs)
            uni_models.append(model)
        self._extract_parameters_from_uni(uni_models)

    def break_zdata(self, reg_val, data, regs):
        index = np.where(regs == reg_val)[0]
        if len(index) == 0: return []
        
        index_diff = index[1:] - index[:-1]
        iter_index = np.where(index_diff>1)[0]
        iter_index = np.append(-1, iter_index)
        iter_index = np.append(iter_index, len(index)-1)
        
        result = []
        udata = self._get_state_uniform(reg_val, data)
        zdata = st.norm.ppf(udata)
        for i in range(len(iter_index)-1):
            l1 = index[iter_index[i] + 1]
            l2 = index[iter_index[i+1]] + 1
            result.append(zdata[l1:l2])
        return result
    
    def fit_cross_cor(self, data, regs):
        self.states_mc_corr = []
        cross_par = []
        for i in range(self.num_reg):
            zdata_arr = self.break_zdata(i, data, regs)
            model = MCVAR(self.dim, self.k, self.states_corr_arr[i])
            model.fit_cross_corr(zdata_arr)
            self.states_mc_corr.append(model.mc_corr)
            cross_par.append(model.mc_corr.par)
        self.cross_par = np.array(cross_par)

    def fit(self, data, regs):
        self.fit_serial_pcor(data, regs)
        self.fit_cross_cor(data, regs)