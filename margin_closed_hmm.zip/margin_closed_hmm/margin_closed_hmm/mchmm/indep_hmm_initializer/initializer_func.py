#%%

import tensorflow as tf
import numpy as np
from scipy.special import logsumexp

from .independent_hmm import IndepHiddenMarkovModel

def adjust_trans_mat(log_mat):
    log_mat[log_mat < -14] = -14
    if len(log_mat.shape) == 1:
        return log_mat - logsumexp(log_mat)
    else:
        return log_mat - logsumexp(log_mat, axis=1)[:, None]

def initializer_generator(n_states, data, dtype=tf.float64):
    dim = data.shape[-1]
    model = IndepHiddenMarkovModel(dim, n_states)
    model.fit(data)
    
    margin_parameters = []
    for i in range(dim):
        sub_parameters = []
        for j in range(n_states):
            sub_parameters.append(model.mdists[j][i].par.tolist())
        margin_parameters.append(sub_parameters)

    margin_parameters = tf.constant(margin_parameters, dtype=dtype)
    log_start_prob = tf.constant(
            adjust_trans_mat(model.log_init_prob), dtype=dtype
    )
    log_transit_mat = tf.constant(
            adjust_trans_mat(model.log_trans_mat), dtype=dtype
    )

    def margin_initializer(*args, **kargs):
        return margin_parameters
    
    def hmm_initializer(*args, **kargs):
        return log_start_prob, log_transit_mat
    
    return margin_initializer, hmm_initializer, model

# %%
