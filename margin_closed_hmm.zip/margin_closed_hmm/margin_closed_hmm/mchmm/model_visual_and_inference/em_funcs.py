# -*- coding: utf-8 -*-
"""
Created on Sat Aug 20 00:19:45 2022

@author: Levin
"""

import numpy as np
import scipy.stats as st
from itertools import product
from scipy.special import logsumexp

#%% 

class ForBackwardAlg():
    
    def __init__(self, k, data):
        self.k = k
        self.data = data
        
    def runfrfunc(self, log_init_prob, log_trans_prob, logf_trans):
        self.log_init_prob = log_init_prob
        self.log_trans_prob = log_trans_prob
        self.logf_trans = logf_trans
        self.r = len(log_init_prob)
        self.T = len(self.data)
        self.forward()
        self.backward()
        
    def runfrarr(self, log_init_prob, log_trans_prob, trans_arr):
        self.log_init_prob = log_init_prob
        self.log_trans_prob = log_trans_prob
        self.trans_arr = trans_arr
        self.r = len(log_init_prob)
        self.T = len(self.data)
        self.forward_arr()
        self.backward_arr()
        
    def decode(self, data, log_init_prob, log_trans_prob, logf_trans):
        max_seq = np.arange(self.r)[:, None]
        max_logpdf = log_init_prob \
                    + np.array([logf_trans[0](data[:1], [i]) \
                                for i in range(self.r)]).ravel()
        
        for t in range(1, self.T): 
            tem_max_seq = np.zeros([self.r] * (min(self.k, t)+1) + [t+1])
            tem_max_logpdf = np.zeros([self.r] * (min(self.k, t)+1))
            
            if t <= self.k:
                sub_data = self.data[:(t+1)]
                for v in product(range(self.r), repeat=t+1):
                    tem_max_seq[v] = v
                    tem_max_logpdf[v] = max_logpdf[v[:-1]] \
                                        + log_trans_prob[v[-2:]] \
                                        + logf_trans[t](sub_data, v)
            else:
                sub_data = self.data[(t-self.k):(t+1)]
                for v in product(range(self.r), repeat=self.k+1):
                    lag_v = np.tile(v, [self.r, 1]).T
                    lag_v = np.vstack([np.arange(self.r), lag_v]).astype(int)
                    tem_logpdf = max_logpdf[tuple(lag_v[:-1])]
                
                    log_trans = log_trans_prob[tuple(lag_v[-2:])]
                    log_emission = np.array([logf_trans[-1](sub_data, v)] * self.r)
                    tem_logpdf += (log_trans + log_emission.ravel())
                    max_arg = np.argmax(tem_logpdf)
                    max_lag_v = tuple(lag_v[:, max_arg])
                    tem_max_seq[v] = np.append(max_seq[max_lag_v[:-1]], v[-1])
                    tem_max_logpdf[v] = np.max(tem_logpdf)
            
            max_seq = tem_max_seq
            max_logpdf = tem_max_logpdf
        
        max_v = np.unravel_index(np.argmax(max_logpdf), max_logpdf.shape)
        return max_logpdf[max_v], max_seq[max_v].astype(int)
    
    def decode_arr(self, data, log_init_prob, log_trans_prob, trans_arr):
        max_seq = np.arange(self.r)[:, None]
        max_logpdf = log_init_prob \
                    + np.array([trans_arr[0][(i,)] \
                                for i in range(self.r)]).ravel()
        
        for t in range(1, self.T): 
            tem_max_seq = np.zeros([self.r] * (min(self.k, t)+1) + [t+1])
            tem_max_logpdf = np.zeros([self.r] * (min(self.k, t)+1))
            
            if t <= self.k:
                for v in product(range(self.r), repeat=t+1):
                    tem_max_seq[v] = v
                    tem_max_logpdf[v] = max_logpdf[v[:-1]] \
                                        + log_trans_prob[v[-2:]] \
                                        + trans_arr[t][v]
            else:
                for v in product(range(self.r), repeat=self.k+1):
                    lag_v = np.tile(v, [self.r, 1]).T
                    lag_v = np.vstack([np.arange(self.r), lag_v]).astype(int)
                    tem_logpdf = max_logpdf[tuple(lag_v[:-1])]
                
                    log_trans = log_trans_prob[tuple(lag_v[-2:])]
                    log_emission = np.array([trans_arr[-1][(t-self.k-1,) + v]]\
                                            * self.r)
                    tem_logpdf += (log_trans + log_emission.ravel())
                    max_arg = np.argmax(tem_logpdf)
                    max_lag_v = tuple(lag_v[:, max_arg])
                    tem_max_seq[v] = np.append(max_seq[max_lag_v[:-1]], v[-1])
                    tem_max_logpdf[v] = np.max(tem_logpdf)
            
            max_seq = tem_max_seq
            max_logpdf = tem_max_logpdf
        
        max_v = np.unravel_index(np.argmax(max_logpdf), max_logpdf.shape)
        return max_logpdf[max_v], max_seq[max_v].astype(int)
        
    def forward(self):
        log_alpha = [] 
        logpdf = np.array([self.logf_trans[0](self.data[:1], [i]) \
                           for i in range(self.r)]).ravel()
        log_alpha.append(logpdf + self.log_init_prob)
        
        for t in range(1,self.T):
            if t <= self.k:
                sub_data = self.data[:(t+1)]
                tem_array = np.zeros([self.r]*(t+1))*np.nan
                
                for v in product(range(self.r), repeat=t+1):
                    tem_array[v] = self.log_trans_prob[v[-2:]] \
                                 + log_alpha[t-1][v[:-1]] \
                                 + self.logf_trans[t](sub_data, v)
                                 
                log_alpha.append(tem_array)
                
            else:
                sub_data = self.data[(t-self.k):(t+1)]
                tem_array = np.zeros([self.r]*(self.k+1))*np.nan
                
                for v in product(range(self.r), repeat=self.k+1):
                    v_comb = [[i]*self.r for i in v[:-1]]
                    v_comb = tuple([list(range(self.r))] + v_comb)
                    lag_log_alpha = logsumexp(log_alpha[t-1][v_comb])
                    
                    tem_array[v] = self.log_trans_prob[v[-2:]] \
                                 + lag_log_alpha \
                                 + self.logf_trans[-1](sub_data, v)
                                 
                log_alpha.append(tem_array)
        
        self.log_alpha = log_alpha

    def backward(self):
        log_beta = [np.zeros([self.r]*(self.k+1))]
        
        for t in range(self.T-2,-1,-1):
            if t >= self.k:
                sub_data = self.data[(t-self.k+1):(t+2)]
                tem_array = np.zeros([self.r]*(self.k+1))*np.nan
                
                for v in product(range(self.r), repeat=self.k+1):
                    v_comb = [[i]*self.r for i in v[1:]]
                    v_comb = tuple(v_comb + [list(range(self.r))])
                    pre_log_beta = log_beta[0][v_comb]
                    
                    lf, lp = np.array([]), np.array([])
                    for i in range(self.r):
                        new_v = v[1:] + (i,)
                        lf = np.append(lf, self.logf_trans[-1](sub_data, new_v))
                        lp = np.append(lp, self.log_trans_prob[new_v[-2:]])
                    
                    log_comp = pre_log_beta + np.array(lf) + np.array(lp)
                    tem_array[v] = logsumexp(log_comp)
                
                log_beta = [tem_array] + log_beta
                
            else:
                sub_data = self.data[:(t+2)]
                tem_array = np.zeros([self.r]*(t+1))*np.nan
                
                for v in product(range(self.r), repeat=t+1):
                    v_comb = [[i]*self.r for i in v]
                    v_comb = tuple(v_comb + [list(range(self.r))])
                    pre_log_beta = log_beta[0][v_comb]
                    
                    lf, lp = np.array([]), np.array([])
                    for i in range(self.r):
                        new_v = v + (i,)
                        lf = np.append(lf, self.logf_trans[t+1](sub_data, new_v))
                        lp = np.append(lp, self.log_trans_prob[new_v[-2:]])
                    
                    log_comp = pre_log_beta + np.array(lf) + np.array(lp)
                    tem_array[v] = logsumexp(log_comp)
                
                log_beta = [tem_array] + log_beta
                
        self.log_beta = log_beta
        
    def forward_arr(self):
        log_alpha = [] 
        logpdf = np.array([self.trans_arr[0][(i,)]\
                           for i in range(self.r)]).ravel()
        log_alpha.append(logpdf + self.log_init_prob)
        
        for t in range(1,self.T):
            if t <= self.k:
                tem_array = np.zeros([self.r]*(t+1))*np.nan
                
                for v in product(range(self.r), repeat=t+1):
                    tem_array[v] = self.log_trans_prob[v[-2:]] \
                                 + log_alpha[t-1][v[:-1]] \
                                 + self.trans_arr[t][v]
                                 
                log_alpha.append(tem_array)
                
            else:
                tem_array = np.zeros([self.r]*(self.k+1))*np.nan
                
                for v in product(range(self.r), repeat=self.k+1):
                    v_comb = [[i]*self.r for i in v[:-1]]
                    v_comb = tuple([list(range(self.r))] + v_comb)
                    lag_log_alpha = logsumexp(log_alpha[t-1][v_comb])
                    
                    tem_array[v] = self.log_trans_prob[v[-2:]] \
                                 + lag_log_alpha \
                                 + self.trans_arr[-1][(t-self.k-1,) + v]
                                 
                log_alpha.append(tem_array)
        
        self.log_alpha = log_alpha

    def backward_arr(self):
        log_beta = [np.zeros([self.r]*(self.k+1))]
        
        for t in range(self.T-2,-1,-1):
            if t >= self.k:
                tem_array = np.zeros([self.r]*(self.k+1))*np.nan
                
                for v in product(range(self.r), repeat=self.k+1):
                    v_comb = [[i]*self.r for i in v[1:]]
                    v_comb = tuple(v_comb + [list(range(self.r))])
                    pre_log_beta = log_beta[0][v_comb]
                    
                    lf, lp = np.array([]), np.array([])
                    for i in range(self.r):
                        new_v = v[1:] + (i,)
                        lf = np.append(lf, 
                                       self.trans_arr[-1][(t-self.k,) + new_v])
                        lp = np.append(lp, self.log_trans_prob[new_v[-2:]])
                    
                    log_comp = pre_log_beta + np.array(lf) + np.array(lp)
                    tem_array[v] = logsumexp(log_comp)
                
                log_beta = [tem_array] + log_beta
                
            else:
                tem_array = np.zeros([self.r]*(t+1))*np.nan
                
                for v in product(range(self.r), repeat=t+1):
                    v_comb = [[i]*self.r for i in v]
                    v_comb = tuple(v_comb + [list(range(self.r))])
                    pre_log_beta = log_beta[0][v_comb]
                    
                    lf, lp = np.array([]), np.array([])
                    for i in range(self.r):
                        new_v = v + (i,)
                        lf = np.append(lf, self.trans_arr[t+1][new_v])
                        lp = np.append(lp, self.log_trans_prob[new_v[-2:]])
                    
                    log_comp = pre_log_beta + np.array(lf) + np.array(lp)
                    tem_array[v] = logsumexp(log_comp)
                
                log_beta = [tem_array] + log_beta
                
        self.log_beta = log_beta
                
    def loglik(self):
        return logsumexp(self.log_alpha[0] + self.log_beta[0])
    
    def dim_sum(self, arr, left_dim):
        dim = len(arr.shape)
        return logsumexp(arr, axis=tuple(range(dim-left_dim)))
        
    def logpost(self, order):
        assert order <= self.k + 1, 'Input order exceed the maximum.'
        loglik = self.loglik()
        post = []
        for i in range(order-1, self.T):
            log_sum = self.dim_sum(self.log_alpha[i] + self.log_beta[i], order)
            post.append(log_sum - loglik)
        return np.array(post)
    
    def inv_logpost(self, order):
        post_prob = self.logpost(order)
        n = post_prob.shape[0]
        inv_post_prob = np.zeros(post_prob.shape) * np.nan
        
        v_index = np.array(list(product(range(self.r), repeat=order)))
        v_index = np.tile(v_index, [n,1])
        x_index = tuple(np.repeat(np.arange(n), self.r**order))
        
        index = (x_index,) + tuple([tuple(arr) for arr in v_index.T])
        inv_index = (x_index[::-1],) + \
                    tuple([tuple(arr) for arr in v_index[:,::-1].T])
                    
        inv_post_prob[inv_index] = post_prob[index]
        return inv_post_prob
        
    def fit_mc(self):
        post1 = self.logpost(1) 
        post2 = self.logpost(2)         
        log_mat = logsumexp(post2, axis=0) - logsumexp(post1[:-1], axis=0)[:,None]
        return post1[0], log_mat
    
    
class GaussianQ():
    
    @staticmethod
    def check_u(u):
        u = np.array(u)
        u[u >= 1.] = 1-np.finfo(float).eps
        u[u <= 0.] = np.finfo(float).eps
        return u
    
    @classmethod
    def cond_logc(cls, u, R, dim):
        if len(u.shape) == 1:
            u = np.array([u])
            R = np.array([R])
        u = cls.check_u(u)
        z = st.norm.ppf(u)
        z1, z2 = z[:,:dim], z[:,dim:]
        z1 = z1[:, :, None]
        z2 = z2[:, :, None]
        R11 = R[:, :dim, :dim]
        R22 = R[:, dim:, dim:]
        R12 = R[:, :dim, dim:]
        R21 = R[:, dim:, :dim]
        R11_2 = R11 - np.matmul(R12, np.linalg.solve(R22, R21))
        mu11_2 = np.matmul(R12, np.linalg.solve(R22, z2))
        logpdf = -0.5 * np.log(np.linalg.det(R11_2))[:, None] \
                 -0.5 * ((z1 - mu11_2) * \
                         np.linalg.solve(R11_2, z1 - mu11_2)).sum(axis=1) \
                 +0.5 * (z1 * z1).sum(axis=1)
        return logpdf.ravel()

    
    def __init__(self):
        pass
        
    def get_trans_arr(self, loglik_mg, inv_udata, Rcom):
        n, num_reg, dim = inv_udata.shape
        k = Rcom.shape[-1] // dim - 1
        
        # for index < k+1
        trans_arr = []
        for i in range(1,k+1):
            sub_arr = np.zeros([num_reg] * i)
            
            vp = np.array(list(product(range(num_reg), repeat=i)))
            xp = np.array([n-np.arange(i,0,-1)] * (num_reg**i))
            v_index = tuple([tuple(v) for v in vp.T])
            
            logpdf_mg = loglik_mg[(tuple(xp.T[0]), v_index[0])]
            
            input_u = inv_udata[(tuple(xp.ravel()), tuple(vp.ravel()))]
            input_u.shape = (vp.shape[0], dim*i)
            
            cplmt = tuple([tuple([0]*vp.shape[0])] * (k+1-i))
            input_Rs = Rcom[v_index + cplmt][:, :(dim*i), :(dim*i)]
            
            sub_arr[v_index[::-1]] = self.cond_logc(input_u, input_Rs, dim) \
                                     + logpdf_mg
            trans_arr.append(sub_arr)
        
        # for index > k
        sub_arr = np.zeros([n-k] + [num_reg] * (k+1))
        vp = np.array(list(product(range(num_reg), repeat=k+1)))
        vp = np.tile(vp, [n-k,1])
        xp = np.array([np.arange(i, (n-k+i)) for i in range(k+1)]).T
        xp = np.repeat(xp, num_reg**(k+1), axis=0)
        v_index = tuple([tuple(v) for v in vp.T])
        
        logpdf_mg = loglik_mg[(tuple(xp.T[0]), v_index[0])]
        
        input_u = inv_udata[(tuple(xp.ravel()), tuple(vp.ravel()))]
        input_u.shape = (vp.shape[0], dim*(k+1))
        input_Rs = Rcom[tuple(v_index)]
        
        sub_arr[(tuple(xp.T[0])[::-1],) + v_index[::-1]] = \
            self.cond_logc(input_u, input_Rs, dim) + logpdf_mg
        trans_arr.append(sub_arr[0])
        trans_arr.append(sub_arr[1:])
        
        return trans_arr
    
    def funcQ(self, loglik_mg, inv_udata, Rcom, inv_post_prob, inv_post_prob_k):
        n, num_reg, dim = inv_udata.shape
        k = Rcom.shape[-1] // dim - 1
        
        # loglik of margins
        loglik = np.sum(loglik_mg * inv_post_prob)
        
        # get index 
        vp = np.array(list(product(range(num_reg), repeat=k+1)))
        vp = np.tile(vp, [n-k,1])
        xp = np.array([np.arange(i, (n-k+i)) for i in range(k+1)]).T
        xp = np.repeat(xp, num_reg**(k+1), axis=0)
        v_index = tuple([tuple(v) for v in vp.T])
        
        # get element of length k+1
        input_u = inv_udata[(tuple(xp.ravel()), tuple(vp.ravel()))]
        input_u.shape = (vp.shape[0], dim*(k+1))
        input_Rs = Rcom[tuple(v_index)]
        
        xv_index = (tuple(xp[:,0].astype(int)),)+v_index
        prob_weights = inv_post_prob_k[xv_index]
        loglik += np.dot(self.cond_logc(input_u, input_Rs, dim), prob_weights)
        
        # get element of length smaller than k+1
        inv_post_k_1 = prob_weights[-num_reg**(k+1):]
        for i in range(k,0,-1):
            inv_post_k_1.shape = (num_reg, num_reg**i)
            inv_post_k_1 = inv_post_k_1.sum(axis=0)
            vp_1 = np.array(list(product(range(num_reg), repeat=i)))
            xp_1 = np.tile(np.arange(len(inv_udata)-i, len(inv_udata)), [num_reg**i,1])
            input_u_1 = inv_udata[(tuple(xp_1.ravel()), tuple(vp_1.ravel()))]
            input_u_1.shape = (vp_1.shape[0], dim*i)
            
            v_index_1 = ((0,) * (num_reg**i),) * (k+1-i)
            for arr in vp_1.T[::-1]:
                v_index_1 = (tuple(arr),) + v_index_1
            input_Rs_1 = Rcom[v_index_1][:, :(dim*i), :(dim*i)]
            
            loglik += np.dot(self.cond_logc(input_u_1, input_Rs_1, dim), 
                             inv_post_k_1)      
        return loglik
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        