#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 11 16:24:46 2022

@author: levin
"""
#%%

import numpy as np
import pandas as pd
import scipy.stats as st
from copy import deepcopy
from scipy.optimize import (minimize, Bounds, LinearConstraint)
import matplotlib.pyplot as plt
from scipy.special import logsumexp
from itertools import product

from .em_funcs import (ForBackwardAlg, GaussianQ)
from statcorr import (StationCorr, FullClosedCorr)
import margins.uni_margins as umg
from margins.cop_margins import CopulaMargin

#%%

def get_switch_point(v):
    v_arr = np.array(v)
    return np.where(np.diff(v_arr))[0]+1

def get_latent_sequence(probs, cl=1, cp=0.6):
    n = len(probs)
    sequence = np.empty(len(probs)).astype(int)
    sequence[0] = int(np.argmax(probs[0]))
    state = sequence[0]
    for i in range(1, n):
        if (i+cl) <= n:
            current_prob = probs[i:(i+cl)].copy()
            current_prob[:, state] = 0.
            switching_index = np.all(current_prob>cp, axis=0)
            if any(switching_index):
                state = np.where(switching_index)[0].item()
        sequence[i] = state
    return sequence

class RegimeLink():
    
    def __init__(self, dim, k):
        self.dim = dim
        self.k = k
        
    def corr_com_fr_Rs(self, Rs, P):
        assert Rs[0].shape[0] == (self.k+1)*self.dim, 'Dimension must match'
        
        num_reg = len(Rs)
        Rcom = np.zeros([num_reg] * (self.k+2) \
                + [(self.k+2) * self.dim, (self.k+2) * self.dim])
        
        for v in product(range(num_reg), repeat=self.k+2):
            l = get_switch_point(v)
            v_new = v[0]
            tem_R = np.eye((self.k+2) * self.dim)
            
            if l.size:
                l = l[0]
                tem_R[:(l*self.dim), :(l*self.dim)] \
                    = Rs[v_new][:(l*self.dim), :(l*self.dim)]
                
                tem_R22 = Rs[v[l]][:self.dim, :self.dim]
                tem_R[(l*self.dim):((l+1)*self.dim), 
                      (l*self.dim):((l+1)*self.dim)] = tem_R22
                tem_R[((l-1)*self.dim):(l*self.dim), 
                      (l*self.dim):((l+1)*self.dim)] = np.dot(P, tem_R22)
                tem_R[(l*self.dim):((l+1)*self.dim), 
                      ((l-1)*self.dim):(l*self.dim)] = np.dot(tem_R22, P)
            else:
                tem_R[:-self.dim, :-self.dim] = Rs[v_new]
            Rcom[v] = tem_R
        return Rcom
    
    def corr_com_fr_mc_corr(self, mc_corr_arr, link_par):
        Rs = [mc_corr.get_corr_mat() for mc_corr in mc_corr_arr]
        return self.corr_com_fr_Rs(Rs, np.diag(link_par))
    
    
class MCHMMInference():

    def __init__(self, dim, k, num_reg, 
                 data,
                 marign_pars,
                 log_strat_prob,
                 log_transition_mat,
                 serial_pcor,
                 cross_sectional_cor,
                 link_coefs,
                 dist_cls=umg.skew_t_ab):
        self.data = data
        self.dim = dim
        self.k = k
        self.num_reg = num_reg
        
        margin_arr = [
            [dist_cls(par=x) for x in sub_pars] for sub_pars in marign_pars
        ]
        self.copmg_arr = [CopulaMargin(self.dim, x) for x in margin_arr]

        self.mc_corr_arr = []
        for i in range(self.num_reg):
            corr_arr = []
            for j in range(self.dim):
                corr = StationCorr(1, self.k)
                corr.par = serial_pcor[i, j]
                corr_arr.append(corr)
            mc_corr = FullClosedCorr(corr_arr, self.dim, self.k)
            mc_corr.par = cross_sectional_cor[i]
            self.mc_corr_arr.append(mc_corr)

        self.log_init_prob = log_strat_prob
        self.log_trans_mat = log_transition_mat
        self.link_par = link_coefs

        self.alg, _ = self.get_alg_obj(data)
        
    def get_margin_data_fr_input(self, copmg_arr, data):
        inv_data = data[::-1]
        n = len(data)
        
        # loglik of margins
        loglik_mg, inv_udata \
            = [], np.zeros([n, self.num_reg, self.dim]) * np.nan
        for i in range(self.num_reg):
            loglik_mg.append(copmg_arr[i].logpdf(inv_data).sum(axis=1))
            inv_udata[:,i,:] = copmg_arr[i].cdf(inv_data)
        loglik_mg = np.array(loglik_mg).T
        return loglik_mg, inv_udata
    
    def get_corr_com_fr_input(self, mc_corr_arr, link_par):
        Rcom = RegimeLink(self.dim, self.k).corr_com_fr_mc_corr(mc_corr_arr, link_par)
        return Rcom
    
    def get_alg_obj(self, data):
        loglik_mg, inv_udata = self.get_margin_data_fr_input(self.copmg_arr, data)
        Rcom = self.get_corr_com_fr_input(self.mc_corr_arr, self.link_par)
        gq_obj = GaussianQ()
        trans_arr = gq_obj.get_trans_arr(loglik_mg, inv_udata, Rcom)
        alg = ForBackwardAlg(self.k+1, data)
        alg.runfrarr(self.log_init_prob, self.log_trans_mat, trans_arr)
        return alg, trans_arr
    
    def get_pi(self):
        trans_mat = np.exp(self.log_trans_mat)
        A = trans_mat.T - np.eye(self.num_reg)
        A[-1] = [1] * self.num_reg
        b = np.zeros(self.num_reg)
        b[-1] = 1
        return np.linalg.solve(A, b)
    
    def plot_mix(self, var_ind, plot_data=True, bins=None):
        stat_p = self.get_pi()
        mgs = [copmg.margins[var_ind] for copmg in self.copmg_arr]
        min_val = min([m.ppf(0.01) for m in mgs])
        max_val = max([m.ppf(0.99) for m in mgs])
        vals = np.linspace(min_val, max_val, 100)
        logpdf = np.array([m.logpdf(vals) + np.log(stat_p[i]) 
                           for (i,m) in enumerate(mgs)])
        mlogpdf = logsumexp(logpdf, axis=0)
        
        fig, ax = plt.subplots()
        for i in range(self.num_reg):
            ax.plot(vals, np.exp(logpdf[i]), 
                    label=f'Class {i}, w={stat_p[i]:.2f}')
        ax.plot(vals, np.exp(mlogpdf), label='Mix')
        if plot_data:
            if bins: 
                ax.hist(self.data[:,var_ind], density=True, bins=bins)
            else:
                ax.hist(self.data[:,var_ind], density=True)
        ax.legend()
        plt.grid()
        plt.show()
    
    def smooth_predict(self, l):
        if l <= self.k+1:
            return np.exp(self.alg.logpost(l))
        else:
            ext_model = deepcopy(self)
            ext_model.k = l-1
            ext_mc_corr_arr = []
            for i in range(self.num_reg):
                new_mc_corr = FullClosedCorr(self.mc_corr_arr[i].corr_arr, 
                                             self.dim, l-1, 
                                             self.mc_corr_arr[i].par_arr)
                ext_mc_corr_arr.append(new_mc_corr)
            ext_model.mc_corr_arr = ext_mc_corr_arr
            alg, _ = ext_model.get_alg_obj(self.data)
            return np.exp(alg.logpost(l))
    
    def get_smooth_probs(self, df, l, plot=True):
        series_enter = []
        series_exit = []
        for i in range(1, l+1):
            seq_enter = (...,) + (0,)*i
            seq_exit = (...,) + (1,)*i
            probs_arr = self.smooth_predict(df.values, i)
            probs_enter = probs_arr[seq_enter]
            probs_exit = probs_arr[seq_exit]
            
            series_enter.append(
                pd.Series(data=probs_enter, name='Probs '+str(i), 
                          index=df.index[:len(probs_enter)])
            )
            series_exit.append(
                pd.Series(data=probs_exit, name='Probs '+str(i),
                          index=df.index[:len(probs_enter)])
            )
        df_enter = pd.concat(series_enter, axis=1)
        df_exit = pd.concat(series_exit, axis=1)
        if plot:
            df_enter.mean(axis=1).plot(figsize=(14, 5), grid=True)
            df_exit.mean(axis=1).plot(figsize=(14, 5), grid=True)
        return df_enter, df_exit
        
    def get_inferred_latent(self, l=1, cl=3, cp=0.6):
        probs = self.smooth_predict(l)
        adj_probs = []
        for i in range(self.num_reg):
            adj_probs.append(probs[(...,)+(i,)*l])
        adj_probs = np.array(adj_probs).T
        seq = get_latent_sequence(adj_probs, cl, cp)
        seq = np.hstack([seq, [seq[-1]]*(len(self.data) - len(seq))])
        return seq.astype(int)