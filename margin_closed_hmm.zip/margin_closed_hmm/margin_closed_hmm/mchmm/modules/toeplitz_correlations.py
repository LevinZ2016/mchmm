

#%%

import tensorflow as tf
import numpy as np

from .utility_funcs import (_convert_slices, tensor_slice_nd_update)


LOmatrix = tf.linalg.LinearOperatorFullMatrix
Kronecker = tf.linalg.LinearOperatorKronecker
Toeplitz = tf.linalg.LinearOperatorToeplitz


def single_pcor2cor(P, i, j, indices):
    p = P[..., i, j]
    S1 = P[..., (i+1):j, (i+1):j]
    S2 = tf.concat([P[..., (i+1):j, i:(i+1)], 
                    P[..., (i+1):j, j:(j+1)]], 
                    axis=-1)

    omega = tf.linalg.matrix_transpose(S2) @ tf.linalg.solve(S1, S2)
    rho = (
        omega[..., 0, 1] + 
        p * tf.math.sqrt((1-omega[..., 0, 0]) * (1-omega[..., 1, 1]))
    )
    indices1 = np.broadcast_to([i, j], P.shape[:-2]+(2,))
    indices2 = np.broadcast_to([j, i], P.shape[:-2]+(2,))
    indices1 = np.concatenate([indices, indices1], axis=-1)
    indices2 = np.concatenate([indices, indices2], axis=-1)
    result = tf.tensor_scatter_nd_update(P, 
                                         [indices1, indices2],
                                         [rho]*2)
    return result

def pcor2cor(P):
    n = P.shape[-1]
    result = P
    indices, _ = _convert_slices(P.shape[:-2], [...])
    for i in range(2, n):
        for j in range(n-i):
            result = single_pcor2cor(result, j, i+j, indices)
    return result


def fill_corr_mat(arr, n):
    shape = arr.get_shape()
    assert shape[-1] == int(n*(n-1)/2)
    P = np.zeros(shape[:-1] + (n, n))
    P[..., :, :] = np.eye(n)
    
    iu1, iu2 = np.triu_indices(n, 1)
    indices1 = list(zip(iu1, iu2))
    indices1 = np.broadcast_to(indices1, shape+(2,))
    indices2 = list(zip(iu2, iu1))
    indices2 = np.broadcast_to(indices2, shape+(2,))

    batch_indices, _ = _convert_slices(arr.shape[:-1], [...])
    batch_indices = np.expand_dims(batch_indices, axis=-2)
    batch_indices = np.broadcast_to(batch_indices, 
                                    shape+batch_indices.shape[-1:])
    indices1 = np.concatenate([batch_indices, indices1], 
                               axis=-1)
    indices2 = np.concatenate([batch_indices, indices2], 
                               axis=-1)

    P = tf.constant(P, dtype=arr.dtype)
    P = tf.tensor_scatter_nd_update(P, indices1, arr)
    P = tf.tensor_scatter_nd_update(P, indices2, arr)
    return P

class UnivariateToeplitzCorr(tf.Module):
    
    def _get_partial_corr_mat(self, serial_pcor):
        diag = tf.ones(self.batch_size+(1,), dtype=self.dtype)
        diag_and_pcor = tf.concat([diag, serial_pcor], axis=-1)
        return Toeplitz(diag_and_pcor, diag_and_pcor).to_dense()

    def _check_parameters(self, serial_pcor):
        expected_shape = (self.batch_size) + (self.k,)
        try:
            assert expected_shape == serial_pcor.shape
        except:
            raise ValueError('expected input should have a '
                            + f'shape {expected_shape} '
                            + f'instead of {serial_pcor.shape}')

    def _save_paras(self, **kargs):
        for name, value in kargs.items():
            setattr(self, name, tf.cast(value, dtype=self.dtype))

    def __init__(self, dtype=tf.float32, name=None):
        super().__init__(name=name)
        self.is_built = False
        self.dtype = dtype

    def __call__(self, serial_pcor):
        '''
        serial_pcor: (..., k)

        '''
        if not self.is_built:
            shape = serial_pcor.get_shape()
            self.batch_size = shape[:-1]
            self.k = shape[-1]
            self.par_dim = self.k
            self.is_built = True
        else:
            self._check_parameters(serial_pcor)

        self._save_paras(serial_pcor=serial_pcor)
        pcor_mat = self._get_partial_corr_mat(self.serial_pcor)
        return pcor2cor(pcor_mat)

class BlockToeplitzCorr(tf.Module):

    def _get_block_partial_corr_mat(self, cross_pcor, serial_pcor):
        LOblock_pcor_mat = Kronecker([LOmatrix(tf.eye(self.k+1, 
                                                      dtype=self.dtype)), 
                                      LOmatrix(cross_pcor)])
        block_pcor_mat = LOblock_pcor_mat.to_dense()
        for i in range(self.k):
            block_i = serial_pcor[..., :(self.k-i)*self.dim]
            block_i_T = tf.linalg.matrix_transpose(block_i)
            slice1 = [
                ..., 
                (i*self.dim, (i+1)*self.dim, None),
                ((i+1)*self.dim, None, None)
            ]
            slice2 = [..., slice1[2], slice1[1]]
            block_pcor_mat = tensor_slice_nd_update(block_pcor_mat, 
                                                    slice1,
                                                    block_i)
            block_pcor_mat = tensor_slice_nd_update(block_pcor_mat, 
                                                    slice2,
                                                    block_i_T)
        return block_pcor_mat

    def _check_parameters(self, cross_rho, serial_pcor):
        try:
            assert self.cross_shape == cross_rho.shape
            assert self.serial_shape == serial_pcor.shape
        except:
            raise ValueError('expected inputs should have '
                            + f'shape {self.cross_shape} and '
                            + f'{self.serial_shape} '
                            + f'instead of {self.cross_shape} and '
                            + f'{self.serial_shape}')

    def _save_paras(self, **kargs):
        for name, value in kargs.items():
            setattr(self, name, tf.cast(value, dtype=self.dtype))

    def __init__(self, dtype=tf.float32, name=None):
        super().__init__(name=name)
        self.is_built = False
        self.dtype = dtype

    def __call__(self, cross_rho, serial_pcor):
        '''
        cross_rho: (..., D(D-1)/2)
        serial_pcor: (..., D, D(k+1))

        '''
        if not self.is_built:
            self.cross_shape = cross_rho.get_shape()
            self.serial_shape = serial_pcor.get_shape()
            self.batch_size = self.serial_shape[:-2]
            self.dim = self.serial_shape[-2]
            self.k = self.serial_shape[-1] // self.serial_shape[-2]
            self.par_dim = self.dim*(self.dim-1) // 2 + self.dim**2 * self.k
            self.is_built = True
        else:
            self._check_parameters(cross_rho, serial_pcor)

        self._save_paras(serial_pcor=serial_pcor,
                         cross_rho=cross_rho)
        cross_pcor = fill_corr_mat(cross_rho, self.dim)
        block_pcor_mat = self._get_block_partial_corr_mat(cross_pcor, serial_pcor)
        return pcor2cor(block_pcor_mat)
        


# %%
