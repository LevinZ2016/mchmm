#%%
import tensorflow as tf
import numpy as np

from .utility_funcs import tensor_slice_nd_update

#%%

class MCHMMCorrMats(tf.Module):

    @staticmethod
    def _check_positive_definite(R):
        try:
            np.linalg.cholesky(R.numpy())
        except:
            return False
        return True
    
    @staticmethod
    def _get_eigvals(R):
        return tf.reshape(tf.math.real(tf.linalg.eigvals(R)), -1)

    def _save_paras(self, **kargs):
        for name, value in kargs.items():
            setattr(self, name, tf.cast(value, dtype=self.dtype))

    def __init__(self,
                 dtype=tf.float32, 
                 name=None):
        super().__init__(name)
        self.dtype = dtype
        self.is_built = False

    def build_module(self, mats_shape, link_shape):
        self.batch_size = mats_shape[:-3]
        self.num_states = mats_shape[-3]
        self.mat_dim = mats_shape[-1]
        self.series_dim = link_shape[-1]
        self.k = self.mat_dim // self.series_dim - 1
        self.is_built = True

    def __call__(self, toeplitz_mats, link_coefs, get_eigvals=False):
        '''
        toeplitz_mats: (..., S, D(k+1), D(k+1))
        link_coefs: (..., D)
        
        '''
        if not self.is_built:
            self.build_module(toeplitz_mats.shape, link_coefs.shape)

        self._save_paras(toeplitz_mats=toeplitz_mats,
                         link_coefs=link_coefs)
        transition_corr_mats = tf.zeros(self.batch_size + 
                                        (self.num_states,
                                         self.num_states, 
                                         self.mat_dim+self.series_dim, 
                                         self.mat_dim+self.series_dim),
                                        dtype=self.dtype)
        
        slices1 = (
            ..., 
            (0, (self.k+1)*self.series_dim, None), 
            (0, (self.k+1)*self.series_dim, None)
        )
        transition_corr_mats = tensor_slice_nd_update(
            transition_corr_mats, 
            slices1,
            tf.expand_dims(toeplitz_mats, axis=-3)
        )

        slices2 = (
            ..., 
            ((self.k+1)*self.series_dim, None, None), 
            ((self.k+1)*self.series_dim, None, None)
        )
        transition_corr_mats = tensor_slice_nd_update(
            transition_corr_mats, 
            slices2,
            tf.expand_dims(toeplitz_mats[..., :self.series_dim, :self.series_dim], 
                           axis=-4)
        )

        link_block = (
            self.link_coefs[..., None, None, :, None] * 
            transition_corr_mats[..., -self.series_dim:, -self.series_dim:]
        )
        slices12 = (
            ..., 
            (self.k*self.series_dim, (self.k+1)*self.series_dim, None),
            ((self.k+1)*self.series_dim, None, None)
        )
        transition_corr_mats = tensor_slice_nd_update(
            transition_corr_mats, 
            slices12,
            link_block
        )
        slices21 = (
            ...,
            ((self.k+1)*self.series_dim, None, None),
            (self.k*self.series_dim, (self.k+1)*self.series_dim, None)
        )
        transition_corr_mats = tensor_slice_nd_update(
            transition_corr_mats, 
            slices21,
            tf.linalg.matrix_transpose(link_block)
        )
        if get_eigvals:
            is_feasible = self._get_eigvals(transition_corr_mats)
        else:
            is_feasible = self._check_positive_definite(transition_corr_mats)
        return transition_corr_mats, is_feasible
