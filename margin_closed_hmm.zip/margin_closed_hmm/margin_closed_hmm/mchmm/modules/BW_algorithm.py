#%%
from functools import partial
import tensorflow as tf
import tensorflow_probability as tfp
import numpy as np
from einops import repeat

from .Gaussian_copula_funcs import Gaussian_copula_cond_log_prob
from .utility_funcs import tensor_slice_nd_update

tfd = tfp.distributions


def _fill_last_dim(tensor, value, n_steps, forward=False):
    paddings = np.zeros([len(tensor.shape), 2])
    if forward:
        paddings[-1] = [n_steps, 0]
    else:
        paddings[-1] = [0, n_steps]
    return tf.pad(tensor, paddings, mode='CONSTANT', constant_values=value)

class MCHMMBaumWelch(tf.Module):

    def _adjust_diagonals(self, tensor, CONSTANT):
        '''
        log_serial_likelihoods: (..., S, S, L, k+2)

        '''
        left_size = tensor.shape[:-4]
        impute_vaules = tf.ones(left_size
                                + (1, 1, self.series_length, self.k+2),
                                dtype=self.dtype)
        impute_vaules = impute_vaules * CONSTANT
        for i in range(self.num_states):
            tensor = tensor_slice_nd_update(
                tensor,
                (..., (i, i+1, None), (i, i+1, None), (None,)*3, (None,)*3),
                impute_vaules
            )
        return tensor

    def _get_cross_states_data(self, tensor):
        extend_tensor1 = repeat(tensor, 
                                '... n l-> ... s n l',
                                s=self.num_states)
        extend_tensor2 = repeat(tensor, 
                                '... m n l -> ... s m n l',
                                s=self.num_states)
        return extend_tensor1, extend_tensor2

    def _reshape_by_states_order(self, tensor):
        '''
        u_tensor: (..., S, L, D)
        --------
        return: (..., S, S, L, D(k+2), k+1)
        
        '''
        NaN = tf.constant(np.nan, dtype=self.dtype)
        tensor1, tensor2 = self._get_cross_states_data(tensor)
        new_regime_concat_list = []
        for i in range(1, self.k+2):
            concat_list = [tf.roll(tensor1, shift=j, axis=-2) 
                           for j in range(i)]
            concat_list.append(tf.roll(tensor2, shift=i, axis=-2))

            tensor_slice_i = tf.concat(concat_list, axis=-1)
            tensor_slice_i = _fill_last_dim(tensor_slice_i, NaN,
                                            (self.k+1-i)*self.series_dim)
            new_regime_concat_list.append(tensor_slice_i)

        return tf.stack(new_regime_concat_list, axis=-1)


    def _get_conditional_log_prob(self,
                                  input_log_margin_prob,
                                  input_tensor,
                                  input_mats):
        input_log_likelihood = self._copula_prob(input_tensor, input_mats) #(..., S, S, L-k-1)
        repeat_margins = repeat(input_log_margin_prob, 
                                '... l -> ... s l', 
                                s=self.num_states)
        return  repeat_margins + input_log_likelihood

    def _save_paras(self, **kargs):
        for name, value in kargs.items():
            setattr(self, name, tf.cast(value, dtype=self.dtype))

    def _log_beta_initializer(self, shared_batch_axis=None):
        other_dims = (self.num_states, self.num_states, self.k+2)
        if shared_batch_axis:
            left_batch = tf.TensorShape(self.batch_size[i] 
                                        for i in range(len(self.batch_size)) 
                                        if i not in shared_batch_axis)
        else:
            left_batch = self.batch_size
        return tf.zeros(left_batch+other_dims, dtype=self.dtype)

    def _log_alpha_initializer(self, shared_batch_axis=None, 
                               broadcast=True):
        log_prob = tf.squeeze(self.log_start_prob)
        one_dim_values = tf.concat([self.log_serial_likelihoods[..., :1, 1, 0, 0],
                                    self.log_serial_likelihoods[..., 1:, 0, 0, 0]],
                                   axis=-1)
        if shared_batch_axis:
            one_dim_values = tf.reduce_sum(one_dim_values, 
                                           axis=shared_batch_axis)
            log_prob = tf.squeeze(self.log_start_prob)
        
        one_dim_values = one_dim_values + log_prob
        if broadcast:
            return repeat(one_dim_values, '... -> ... m n',
                          m=self.num_states, n=1)
        else:
            return one_dim_values

    def __init__(self, dtype=tf.float32, name=None):
        super().__init__(name=name)
        self.dtype = dtype
        self.is_built = False

    def _likelihood_in_single_state(self,
                                   sum_log_margin_prob,
                                   score_tensor, 
                                   transition_corr_mats):
        input_log_margin_prob = sum_log_margin_prob[..., (self.k+1):]
        input_tensor = score_tensor[..., (self.k+1):, 
                                    :-self.series_dim,
                                    -1]
        input_mats =  transition_corr_mats[...,
                                           :-self.series_dim, 
                                           :-self.series_dim]
        log_likelihood = self._get_conditional_log_prob(input_log_margin_prob,
                                                       input_tensor,
                                                       input_mats)
        neg_inf = tf.math.log(tf.constant(0., dtype=self.dtype))                                               
        log_likelihood = _fill_last_dim(log_likelihood, neg_inf,
                                       self.k+1, forward=True)
        return log_likelihood
                                
    def _likelihood_during_states_change(self,
                                        sum_log_margin_prob,
                                        score_tensor, 
                                        transition_corr_mats, 
                                        lag_order):
        '''
        sum_log_margin_prob: (..., S, L)
        score_tensor: (..., S, S, L, D(k+2), k+1)
        transition_corr_mats: (..., S, S, D(k+2), D(k+2))
        lag_order: 1:(k+1)
        '''
        input_log_margin_prob = sum_log_margin_prob[..., lag_order:]
        input_tensor = score_tensor[..., lag_order:, 
                                    :self.series_dim*(lag_order+1),
                                    lag_order-1]
        input_mats =  transition_corr_mats[...,
                                           -self.series_dim*(lag_order+1):, 
                                           -self.series_dim*(lag_order+1):]
        log_likelihood = self._get_conditional_log_prob(input_log_margin_prob,
                                                        input_tensor,
                                                        input_mats)

        input_log_margin_prob_top = sum_log_margin_prob[..., (lag_order-1):lag_order]                                  
        input_tensor_top = score_tensor[..., (lag_order-1):lag_order, 
                                        :self.series_dim*lag_order,
                                        lag_order-1]
        input_mats_top =  transition_corr_mats[...,
                                               :self.series_dim*lag_order, 
                                               :self.series_dim*lag_order]
        log_likelihood_top = self._get_conditional_log_prob(
            input_log_margin_prob_top, input_tensor_top, input_mats_top
        )

        log_likelihood = tf.concat([log_likelihood_top, log_likelihood],
                                  axis=-1)
        
        neg_inf = tf.math.log(tf.constant(0., dtype=self.dtype))
        log_likelihood = _fill_last_dim(log_likelihood, neg_inf,
                                       lag_order-1, forward=True)
        return log_likelihood

    def _get_log_likelihood_tensor(self):
        '''
        log_margin_prob: (..., S, L, D)
        u_tensor: (..., S, L, D)
        transition_corr_mats: (..., S, S, D(k+2), D(k+2))
        --------
        return: (..., S, S, L, k+2)

        '''
        dist = tfd.Normal(loc=tf.cast(0., dtype=self.dtype), 
                          scale=tf.cast(1., dtype=self.dtype))
        score_tensor = dist.quantile(self.u_tensor)
        score_tensor = self._reshape_by_states_order(score_tensor)

        sum_log_margin_prob = tf.reduce_sum(self.log_margin_prob, axis=-1)

        log_serial_likelihoods = []
        for i in range(1, self.k+2):
            log_likelihood_i = self._likelihood_during_states_change(
                sum_log_margin_prob, score_tensor, self.transition_corr_mats, i
            )

            log_serial_likelihoods.append(log_likelihood_i)
        log_single_likelihoods = self._likelihood_in_single_state(
            sum_log_margin_prob, score_tensor, self.transition_corr_mats
        )

        log_serial_likelihoods.append(log_single_likelihoods)
        log_serial_likelihoods = tf.stack(log_serial_likelihoods, axis=-1)
        # last index = 0:(k+1) for l = 1:(k+2)
        # (..., S, S, L, k+2)
        neg_inf = tf.math.log(tf.constant(0., dtype=self.dtype))
        return self._adjust_diagonals(log_serial_likelihoods, neg_inf)

    def _log_beta_iteration(self, log_beta, t, shared_batch_axis=None):
        '''
        t : 1 ~ L-1
        log_beta : (..., S, S, k+2) for t >= k+1
                   (..., S, S, t+1) for t < k+1
        --------
        return : (..., S, S, k+2) for t > k+1
                 (..., S, S, t) for t <= k+1

        '''
        log_beta1 = log_beta[..., 0]
        tlog_trans = self.tlog_transition_mat
        log_f1 = self.log_serial_likelihoods[..., t, 0]
        if shared_batch_axis:
            log_f1 = tf.reduce_sum(log_f1, axis=shared_batch_axis)
            tlog_trans = tf.squeeze(self.tlog_transition_mat)
        update_log_beta1 = log_beta1 + log_f1 + tlog_trans #(..., S, S)
        update_log_beta1 = tf.reduce_logsumexp(update_log_beta1, axis=-2)

        if t > self.k+1:
            lag_log_beta = tf.concat([log_beta[..., 1:], log_beta[..., -1:]],
                                     axis=-1)
            lag_log_f = tf.concat([self.log_serial_likelihoods[..., t, 1:], 
                                   self.log_serial_likelihoods[..., t, -1:]],
                                  axis=-1)
        else:
            lag_log_beta = log_beta[..., 1:]
            lag_log_f = self.log_serial_likelihoods[..., t, 1:(t+1)]
        
        if shared_batch_axis:
            lag_log_f = tf.reduce_sum(lag_log_f, axis=shared_batch_axis)
        update_log_beta2 = (
            lag_log_beta 
            + lag_log_f
            + tf.linalg.diag_part(tlog_trans)[..., None, None]
        )
        update_log_beta1 = tf.broadcast_to(update_log_beta1[..., None, None], 
                                           update_log_beta2.shape)
        updated_log_beta = tf.math.reduce_logsumexp([update_log_beta1, 
                                                     update_log_beta2], 
                                                    axis=0)
        return updated_log_beta


    def __call__(self, 
                 log_margin_prob,
                 u_tensor, 
                 transition_corr_mats, 
                 log_transition_mat,
                 log_start_prob,
                 shared_batch_axis=None):
        '''
        log_margin_prob: (..., S, L, D)
        u_tensor: (..., S, L, D)
        transition_corr_mats: (..., S, S, D(k+2), D(k+2)):
        transition_mat: (..., S, S)
        log_start_prob: (..., S)
        shared_batch_axis: list of non-negtive int
        ---------------
        return: (...)

        '''
        # If shared_batch_axis is neither None nor [], the corresponding
        # axis in shared_batch_axis for log_transition_mat and log_start_prob
        # should be 1, meaning that the parameters are shared along the 
        # shared_batch_axis.

        if not self.is_built:
            mats_shapes = transition_corr_mats.get_shape()
            self.batch_size = mats_shapes[:-4]
            self.num_states = mats_shapes[-3]
            self.series_dim = u_tensor.shape[-1]
            self.series_length = u_tensor.shape[-2]
            self.k = mats_shapes[-1] // self.series_dim - 2
            self._copula_prob = partial(Gaussian_copula_cond_log_prob,
                                        dim=self.series_dim,
                                        is_uniform=False)
            self.is_built = True

        tlog_transition_mat = tf.linalg.matrix_transpose(log_transition_mat)
        self._save_paras(log_margin_prob=log_margin_prob,
                         u_tensor=u_tensor, 
                         transition_corr_mats=transition_corr_mats, 
                         log_transition_mat=log_transition_mat,
                         log_start_prob=log_start_prob,
                         tlog_transition_mat=tlog_transition_mat)

        self.log_serial_likelihoods = self._get_log_likelihood_tensor()

        log_beta = self._log_beta_initializer(shared_batch_axis)
        for t in range(self.series_length-1, 0, -1):
            log_beta = self._log_beta_iteration(log_beta, t, shared_batch_axis)
        
        log_alpha0 = self._log_alpha_initializer(shared_batch_axis, 
                                                 broadcast=False) # (..., S)
        log_beta0 = tf.concat([log_beta[..., :1, 1, 0],
                               log_beta[..., 1:, 0, 0]],
                               axis=-1) # (..., S)
        return tf.math.reduce_logsumexp(log_alpha0+log_beta0, axis=-1)

    def get_log_beta(self, shared_batch_axis):
        log_beta_slice = self._log_beta_initializer(shared_batch_axis)
        log_beta_concat_list = [log_beta_slice]
        for t in range(self.series_length-1, 0, -1):
            log_beta_slice = self._log_beta_iteration(log_beta_slice, t, 
                                                      shared_batch_axis)
            if t <= self.k+1:
                NaN = tf.constant(np.nan, dtype=self.dtype)
                new_log_beta_slice = _fill_last_dim(log_beta_slice, NaN,
                                                    self.k+2-t)
            else:
                new_log_beta_slice = log_beta_slice

            log_beta_concat_list.append(new_log_beta_slice)

        log_beta = tf.stack(log_beta_concat_list[::-1], axis=-2)
        return self._adjust_diagonals(log_beta, NaN)
    

class KnownLatentAlgo(MCHMMBaumWelch):

    @staticmethod
    def _get_latent_info(v):
        v_arr = np.array(v)
        posi = np.where(np.diff(v_arr))[0]+1
        v1 = v_arr[-1]
        l = len(v) if len(posi)==0 else len(v) - posi[-1]
        v2 = abs(v1-1) if len(posi)==0 else v_arr[-(l+1)]
        return (v1, v2, l)

    def __init__(self, dtype=tf.float32, name=None):
        super().__init__(dtype=dtype, name=name)
    
    def _get_latent_sequence_loglik(self, 
                                    latent_sequence, 
                                    log_start_prob, 
                                    log_transition_mat):
        loglik = log_start_prob[latent_sequence[0]]
        for i in range(1, len(latent_sequence)):
            v1 = latent_sequence[i]
            v2 = latent_sequence[i-1]
            loglik += log_transition_mat[v1, v2]
        return loglik
    
    def __call__(self, latent_sequence,
                 log_margin_prob,
                 u_tensor, 
                 transition_corr_mats, 
                 log_transition_mat,
                 log_start_prob,
                 include_sequence=True):
        if not self.is_built:
            mats_shapes = transition_corr_mats.get_shape()
            self.batch_size = mats_shapes[:-4]
            self.num_states = mats_shapes[-3]
            self.series_dim = u_tensor.shape[-1]
            self.series_length = u_tensor.shape[-2]
            self.k = mats_shapes[-1] // self.series_dim - 2
            self._copula_prob = partial(Gaussian_copula_cond_log_prob,
                                        dim=self.series_dim,
                                        is_uniform=False)
            self.is_built = True

        tlog_transition_mat = tf.linalg.matrix_transpose(log_transition_mat)
        self._save_paras(latent_sequence=latent_sequence,
                         log_margin_prob=log_margin_prob,
                         u_tensor=u_tensor, 
                         transition_corr_mats=transition_corr_mats, 
                         log_transition_mat=log_transition_mat,
                         log_start_prob=log_start_prob,
                         tlog_transition_mat=tlog_transition_mat)

        self.log_serial_likelihoods = self._get_log_likelihood_tensor()
        
        loglik = tf.zeros(self.batch_size+(1,), dtype=self.dtype)
        for i in range(self.series_length):
            start = max(i-self.k-1, 0)
            sub_seq = latent_sequence[start:(i+1)]
            v1, v2, l = self._get_latent_info(sub_seq)
            loglik += self.log_serial_likelihoods[..., v1, v2, i, l-1]
        if include_sequence:
            loglik += self._get_latent_sequence_loglik(
                latent_sequence, log_start_prob, log_transition_mat)
        return loglik

# %%
