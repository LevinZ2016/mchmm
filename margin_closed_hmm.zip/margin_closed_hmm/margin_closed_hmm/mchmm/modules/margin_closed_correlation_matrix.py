#%%

import tensorflow as tf
import numpy as np
from einops import repeat

from .utility_funcs import tensor_slice_nd_update

LOmatrix = tf.linalg.LinearOperatorFullMatrix
Kronecker = tf.linalg.LinearOperatorKronecker
BlockDiag = tf.linalg.LinearOperatorBlockDiag

def comm_mat(m, n):
    A = np.reshape(np.arange(m*n), (m,n), order='F')
    w = np.reshape(A.T, m*n, order='F')
    M = np.eye(m*n)
    M = M[w,:]
    return M

def _vec(tensor):
    shape = tensor.get_shape()
    batch = shape[:-2]
    m, n = shape[-2:]
    tensor = tf.linalg.matrix_transpose(tensor)
    return tf.reshape(tensor, shape=batch+(m*n,1))

def _dvec(tensor, m):
    shape = tensor.get_shape()
    batch = shape[:-2]
    n = shape[-2] // m
    tensor = tf.reshape(tensor, shape=batch+(n, m))
    return tf.linalg.matrix_transpose(tensor)

def _get_batch_comm_mat(batch_size, m, n, dtype):
    block = np.empty(batch_size + (m*n,)*2)
    block[..., :, :] = comm_mat(m, n)
    return tf.constant(block, dtype=dtype)

def _get_batch_eye(batch_size, mat_size, dtype):
    block = np.empty(batch_size + (mat_size,)*2)
    block[..., :, :] = np.eye(mat_size)
    return tf.constant(block, dtype=dtype)

def _get_batch_rotate_eye(batch_size, mat_size, dtype):
    block = np.empty(batch_size + (mat_size,)*2)
    block[..., :, :] = np.rot90(np.eye(mat_size))
    return tf.constant(block, dtype=dtype)

def _kron(matrix1, matrix2):
    LOblock_pcor_mat = Kronecker([LOmatrix(matrix1), 
                                  LOmatrix(matrix2)])
    return LOblock_pcor_mat.to_dense()



class MarginBlockCorr:
    
    def __init__(self, batch_size, dim, k, dtype=tf.float32):
        self.k = k
        self.batch_size = batch_size
        self.dim = dim
        self.dtype = dtype
        
    def _check_R(self, R):
        '''
        R: (..., N, N)

        '''
        assert R.shape[-1] == self.dim * (self.k+1), \
            'Wrong dimension of the input Toeplitz matrix.'
        return tf.cast(R, dtype=self.dtype)

    def _get_blocks(self):
        block1 = tf.zeros(self.batch_size + (self.dim, self.dim*(self.k-1)),
                          dtype=self.dtype)
        block2 = -_get_batch_eye(self.batch_size, self.dim, self.dtype)
        block3 = tf.zeros(self.batch_size + (self.dim, self.dim),
                          dtype=self.dtype)
        return block1, block2, block3

    def get_coefs(self, R):
        R21 = R[..., self.dim:, :self.dim]
        R22 = R[..., self.dim:, self.dim:]
        coefs = tf.linalg.solve(R22, R21)
        return tf.linalg.matrix_transpose(coefs)
    
    def get_coefs_inv(self, R):
        R11 = R[..., :-self.dim, :-self.dim]
        R12 = R[..., :-self.dim, -self.dim:]
        coefs = tf.linalg.solve(R11, R12)
        return tf.linalg.matrix_transpose(coefs)
    
    def get_shift_mat(self, R):
        R = self._check_R(R)
        coefs = self.get_coefs(R)
        block1, block2, block3 = self._get_blocks()
        row_mat = tf.concat([block1, block2, coefs, block3], axis=-1)
        m = []
        for i in range(self.k):
            m.append(tf.roll(row_mat, -self.dim*i, axis=-1))
        return tf.concat(m, axis=-2)
    
    def get_shift_mat_inv(self, R):
        R = self._check_R(R)
        coefs_inv = self.get_coefs_inv(R)
        block1, block2, block3 = self._get_blocks()
        row_mat = tf.concat([block1, block3, coefs_inv, block2], axis=-1)
        m = []
        for i in range(self.k):
            m.append(tf.roll(row_mat, -self.dim*i, axis=-1))
        return tf.concat(m, axis=-2)


# %%

class PairClosedCorr(tf.Module):

    @staticmethod
    def get_link_block_toeplitz(blocks, dim, l):
        m = []
        for i in range(l-1, -1, -1):
            m.append(blocks[..., (i*dim):((i+l)*dim)])
        return tf.concat(m, axis=-2)

    def _check_input(self, R1, R2):
        assert R1.shape[-1] == (self.k+1) * self.dim1, \
                'Wrong input of matrix dimension!'
        assert R2.shape[-1] == (self.k+1) * self.dim2, \
                'Wrong input of matrix dimension!'

    def __init__(self, k, dtype=tf.float32, name=None):
        super().__init__(name)
        self.dtype = dtype
        self.k = k
        self.is_built = False

    def get_link_mat(self, R1, R2, Sigma, condition_type):
        mg1 = MarginBlockCorr(self.batch_size, self.dim1, self.k, self.dtype)
        mg2 = MarginBlockCorr(self.batch_size, self.dim2, self.k, self.dtype)
        
        J = _get_batch_rotate_eye(self.batch_size, 2*self.k+1, self.dtype)
        J = _kron(J, tf.eye(self.dim1, dtype=self.dtype))
        
        if condition_type[0] != condition_type[1]:
            S = np.zeros(self.batch_size + (self.k+1, self.k+1))
            S[..., -1, 0] = 1.
            S = tf.constant(S, dtype=self.dtype)
            if condition_type[0] == 0:
                return _kron(S, Sigma)
            else:
                return _kron(tf.linalg.matrix_transpose(S), Sigma)
        
        elif condition_type[0] == 0:
            m1 = tf.linalg.matmul(mg1.get_shift_mat(R1), J)
            m2 = mg2.get_shift_mat(R2)
        else:
            m1 = tf.linalg.matmul(mg1.get_shift_mat_inv(R1), J)
            m2 = mg2.get_shift_mat_inv(R2)
        
        A = tf.concat([m1[..., :(self.k * self.dim1)], 
                       m1[..., -(self.k * self.dim1):]],
                      axis=-1)
        B = tf.concat([m2[..., :(self.k * self.dim2)], 
                       m2[..., -(self.k * self.dim2):]],
                       axis=-1)
        
        Ha = -m1[..., (self.k * self.dim1):((self.k+1) * self.dim1)]
        Hb = -m2[..., (self.k * self.dim2):((self.k+1) * self.dim2)]
        
        K12 = _get_batch_comm_mat(self.batch_size, self.dim1, 
                                  self.dim2, self.dtype)
        M1 = tf.linalg.matmul(
            _kron(A, tf.eye(self.dim2, dtype=self.dtype)), 
            _kron(tf.eye(2*self.k, dtype=self.dtype), K12)
        )
        M2 = _kron(B, tf.eye(self.dim1, dtype=self.dtype))
        M = tf.concat([M1, M2], axis=-2)
        
        H1 = tf.linalg.matmul(_kron(Ha, tf.eye(self.dim2, dtype=self.dtype)), 
                              K12)
        H2 = _kron(Hb, tf.eye(self.dim1, dtype=self.dtype))
        H = tf.concat([H1, H2], axis=-2)
        
        v = tf.linalg.solve(M, tf.linalg.matmul(H, _vec(Sigma)))
        D = _dvec(v, self.dim1)
        D = tf.concat([D[..., :(self.k * self.dim2)], 
                       Sigma, 
                       D[..., -(self.k * self.dim2):]],
                      axis=-1)
        S = self.get_link_block_toeplitz(D, self.dim2, self.k+1)
        return S

    def __call__(self, R1, R2, Sigma, condition_type=(1, 1)):
        '''
        R1: (..., d1(k+1), d1(k+1))
        R2: (..., d2(k+1), d2(k+1))
        
        '''
        if not self.is_built:
            shape = Sigma.get_shape()
            self.batch_size = shape[:-2]
            self.dim1 = shape[-2]
            self.dim2 = shape[-1]
            self.is_built = True

        self._check_input(R1, R2)
        R1 = tf.cast(R1, dtype=self.dtype) 
        R2 = tf.cast(R2, dtype=self.dtype)
        Sigma = tf.cast(Sigma, dtype=self.dtype)
        return self.get_link_mat(R1, R2, Sigma, condition_type)

# %%

class UniCompoentMC(tf.Module):

    @staticmethod
    def _check_positive_definite(R):
        try:
            np.linalg.cholesky(R.numpy())
        except:
            return False
        return True
    
    @staticmethod
    def _get_eigvals(R):
        return tf.reshape(tf.math.real(tf.linalg.eigvals(R)), -1)
    
    def _get_position_matrix(self):
        ind_matrix = np.zeros([self.dim]*2)
        count = 0
        for i in range(1, self.dim):
            for j in range(self.dim-i):
                ind1, ind2 = j, i+j
                ind_matrix[ind1, ind2] = count
                count += 1
        return ind_matrix.astype(int)

    def _get_mc_matrix(self, uni_toeplitz_mats, cross_component_rho):
        component_matrix = tf.unstack(uni_toeplitz_mats, axis=-3)
        LOmats = [LOmatrix(mat) for mat in component_matrix]
        block_diag = BlockDiag(LOmats).to_dense()

        for i in range(self.dim-1):
            for j in range(i+1, self.dim):
                posi = self._rho_position_mat[..., i, j].item()
                cross_ij = cross_component_rho[..., None, posi:(posi+1)]
                Sij = self._pcc(component_matrix[i],
                                component_matrix[j],
                                cross_ij,
                                (1, 1))
                Sji = tf.linalg.matrix_transpose(Sij)
                slices1 = (
                    ..., 
                    (i*(self.k+1), (i+1)*(self.k+1), None),
                    (j*(self.k+1), (j+1)*(self.k+1), None)
                )
                block_diag = tensor_slice_nd_update(block_diag,
                                                    slices1,
                                                    Sij)
                slices2 = (
                    ..., 
                    (j*(self.k+1), (j+1)*(self.k+1), None),
                    (i*(self.k+1), (i+1)*(self.k+1), None)
                )
                block_diag = tensor_slice_nd_update(block_diag,
                                                    slices2,
                                                    Sji)
        return block_diag

    def _reorder_corr(self, R):
        index = np.arange(self.k+1)[:, None] \
                + np.arange(self.dim) * (self.k+1)
        index = index.ravel()
        I = np.eye(len(index))
        perm_mat1 = tf.cast(I[index], dtype=self.dtype)
        perm_mat2 = tf.cast(I[:, index], dtype=self.dtype)
        R = tf.linalg.matmul(perm_mat1, R)
        R = tf.linalg.matmul(R, perm_mat2)
        return R

    def __init__(self, dtype=tf.float32, name=None):
        super().__init__(name)
        self.dtype = dtype
        self.is_built = False

    def __call__(self, 
                 uni_toeplitz_mats, 
                 cross_component_rho, 
                 get_eigvals=False):
        '''
        uni_toeplitz_mats: (..., D, k+1, k+1)
        cross_component_rho: (..., D(D-1)/2)
        
        '''
        if not self.is_built:
            shape = uni_toeplitz_mats.get_shape()
            self.dim = shape[-3]
            self.k = shape[-1] - 1
            self._rho_position_mat = self._get_position_matrix()
            self._pcc = PairClosedCorr(self.k, dtype=self.dtype)
            self.is_built = True

        uni_toeplitz_mats = tf.cast(uni_toeplitz_mats, dtype=self.dtype)
        cross_component_rho = tf.cast(cross_component_rho, dtype=self.dtype)

        R = self._get_mc_matrix(uni_toeplitz_mats, cross_component_rho)
        R = self._reorder_corr(R)
        if get_eigvals:
            is_feasible = self._get_eigvals(R)
        else:
            is_feasible = self._check_positive_definite(R)
        return R, is_feasible

        
        


# %%
