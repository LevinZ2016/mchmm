
import tensorflow as tf
import numpy as np


def _convert_slices(shape, slices):
    slices = list(slices)
    dim, ls = len(shape), len(slices)
    if dim >= ls:
        if slices[0] is Ellipsis:
            slices = [(None,) * 3] * (dim - ls + 1) + slices[1:]
        ls = dim
    elif (ls == (dim+1)) and (slices[0] is Ellipsis):
        ls = dim
        slices = slices[1:]
    else:
        raise IndexError('too many indices for tensor:' 
                        + f'tensor is {dim}-dimensional, '
                        + f'but {ls} were indexed')

    try:
        axis_indices = [
            [s] if isinstance(s, int)
            else np.arange(l)[slice(*s)].tolist()
            for l, s in zip(shape[:ls], slices)    
        ]
    except:
        raise IndexError('unacceptable input slices')
    shape_slice = tuple(len(ind) for ind in axis_indices)
    target_shape = shape_slice + shape[ls:]
    indices = _get_indices(axis_indices).tolist()
    return indices, target_shape
    
def _get_indices(axis_indices):
    indices = np.array([], dtype=int)
    current_shape = []
    for i, axis_index in enumerate(axis_indices):
        indices = np.expand_dims(indices, -2)
        current_shape.append(len(axis_index))
        indices = np.broadcast_to(indices, current_shape+[i])
        new_component = np.reshape(axis_index, (1,)*i+(-1,1))
        new_component = np.broadcast_to(new_component, current_shape+[1])
        indices = np.concatenate([indices, new_component], axis=-1)
    return indices

def tensor_slice_nd_update(tensor, slices, update_tensor):
    shape = tensor.get_shape()
    indices, target_shape = _convert_slices(shape, slices)
    try:
        values = tf.broadcast_to(update_tensor, target_shape)
    except:
        raise ValueError('could not broadcast input array '
                         + f'from shape {update_tensor.shape} '
                         + f'into shape {target_shape}')
    return tf.tensor_scatter_nd_update(tensor, indices, values)
