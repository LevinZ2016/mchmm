
#%%
import tensorflow as tf
from einops import rearrange, repeat
import tensorflow_probability as tfp

tfd = tfp.distributions
multiGaussian = tfd.MultivariateNormalFullCovariance

#%%

def Gaussian_copula_log_prob(tensor, corr_matrix, is_uniform=True):
    '''
    tensor: (..., L, E)
    corr_matrix: (..., E, E)

    '''
    
    if is_uniform:
        dtype = tensor.dtype
        dist = tfd.Normal(loc=tf.cast(0., dtype=dtype), 
                          scale=tf.cast(1., dtype=dtype))
        tensor = dist.quantile(tensor)

    log_corr_det = tf.expand_dims(tf.linalg.logdet(corr_matrix), 
                                  axis=-1)
    trans_tensor = tf.linalg.matrix_transpose(tensor)
    log_corr_density = tf.reduce_sum(trans_tensor * 
                                     tf.linalg.solve(corr_matrix, 
                                                     trans_tensor),
                                     axis=-2)
    log_uncorr_density = tf.reduce_sum(trans_tensor * trans_tensor,
                                       axis=-2)
    return -0.5 * (log_corr_det + log_corr_density - log_uncorr_density)
    
def Gaussian_copula_cond_log_prob(tensor, corr_matrix, dim, is_uniform=True):
    '''
    tensor: (..., L, E)
    corr_matrix: (..., E, E)
    dim: 1~(E-1)
    '''
    
    if is_uniform:
        dtype = tensor.dtype
        dist = tfd.Normal(loc=tf.cast(0., dtype=dtype), 
                          scale=tf.cast(1., dtype=dtype))
        tensor = dist.quantile(tensor)
    
    R11 = corr_matrix[..., :dim, :dim]
    R12 = corr_matrix[..., :dim, dim:]
    R21 = corr_matrix[..., dim:, :dim]
    R22 = corr_matrix[..., dim:, dim:]
    t_tensor1 = tf.linalg.matrix_transpose(tensor[..., :dim])
    t_tensor2 = tf.linalg.matrix_transpose(tensor[..., dim:])

    R1_2 = R11 - R12 @ tf.linalg.solve(R22, R21)
    mu1_2 = R12 @ tf.linalg.solve(R22, t_tensor2)

    dt_tensor1 = t_tensor1 - mu1_2
    log_corr_det = tf.expand_dims(tf.linalg.logdet(R1_2), 
                                  axis=-1)
    log_corr_density = tf.reduce_sum(dt_tensor1 * 
                                     tf.linalg.solve(R1_2, 
                                                     dt_tensor1),
                                     axis=-2)
    log_uncorr_density = tf.reduce_sum(t_tensor1 * t_tensor1,
                                       axis=-2)                              
    return -0.5 * (log_corr_det + log_corr_density - log_uncorr_density)

def Gaussian_copula_series_log_prob(tensor, corr_matrix, is_uniform=True):
    '''
    tensor: (..., L, D)
    corr_matrix: (..., D(k+1), D(k+1))

    '''
    L, D = tensor.get_shape()
    Dk = corr_matrix.shape[-1]
    assert Dk % D == 0, 'dimension of correlation matrix cannot match data'
    k = corr_matrix.shape[-1] // D - 1
    
    if is_uniform:
        dist = tfd.Normal(loc=0., scale=1.)
        tensor = dist.quantile(tensor)
    concat_list = [tensor[..., i:(L-k+i), :] for i in range(k+1)]
    reshaped_tensor = tf.concat(concat_list, axis=-1)
    
    return Gaussian_copula_log_prob(reshaped_tensor, 
                                    corr_matrix, 
                                    is_uniform=False)
