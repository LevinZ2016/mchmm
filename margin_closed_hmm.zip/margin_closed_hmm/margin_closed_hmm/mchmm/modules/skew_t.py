
import scipy.stats as st
import numpy as np
import tensorflow as tf
import tensorflow_probability as tfp

tfd = tfp.distributions

class Skewt(tf.Module):

    def __init__(self, dtype=tf.float32, name=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.is_built = False
        self.dtype = dtype

    def _parameter_initalizer(self, input_data):
        k = st.kurtosis(input_data, axis=-1)
        a = (3/k+2) * (k>0) + 2 * (k<=0)
        b = (3/k+2) * (k>0) + 2 * (k<=0)
        mu = np.mean(input_data, axis=-1)
        sigma = np.std(input_data, axis=-1) * np.sqrt((a-1)/a)
        init_pars = np.stack([mu, sigma, a, b],      
                             axis=-1)
        self.par =  tf.Variable(init_pars, dtype=self.dtype)

    def log_prob(self, input_data):
        mu = self.par[..., 0:1]
        sigma = self.par[..., 1:2]
        a = self.par[..., 2:3]
        b = self.par[..., 3:4]
        z = (input_data - mu) / sigma
        z = z / tf.math.sqrt(a + b + z**2)

        ln2 = tf.cast(tf.math.log(2.), dtype=self.dtype)
        logM = -(a+b-1) * ln2 \
                - 0.5 * tf.math.log(
                    tf.reduce_sum(self.par[..., 2:], 
                                  axis=-1, 
                                  keepdims=True)) \
                + (a + 0.5) * tf.math.log(1 + z) \
                + (b + 0.5) * tf.math.log(1 - z)
        logB = -tf.expand_dims(tf.math.lbeta(self.par[..., 2:4]),
                               axis=-1)
        return logM + logB - tf.math.log(sigma)

    def cdf(self, input_data):
        mu = self.par[..., 0:1]
        sigma = self.par[..., 1:2]
        a = self.par[..., 2:3]
        b = self.par[..., 3:4]
        z = (input_data - mu) / sigma
        z = z / tf.math.sqrt(a + b + z**2)
        z = 0.5 + 0.5*z
        dist = tfd.Beta(a, b)
        return dist.cdf(z)

    def __call__(self, parameters, input_data):
        '''
        input_data: (..., L)
        par: (..., 4)
        -------------
        return:
        log_prob: (..., L)
        u_tensor: (..., L)

        '''
        input_data = tf.cast(input_data, dtype=self.dtype)
        self.par = tf.cast(parameters, dtype=self.dtype)
        if not self.is_built:
            self.batch_size = input_data.shape[:-1]
            self.sample_size = input_data.shape[-1]
            self.is_built = True

        log_prob = self.log_prob(input_data)
        u_tensor = self.cdf(input_data)
        return  log_prob, u_tensor
