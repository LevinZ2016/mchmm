
import tensorflow as tf
from mchmm.modules.skew_t import Skewt
from einops import repeat
import numpy as np

from hmmlearn import hmm

def _trans_margin_parameters(tensor):
    tensor1 = tf.math.log(tensor[..., 1:2]) - 1e-6
    tensor2 = tf.math.atanh((tensor[..., 2:] - 1e-6) / 500. - 1)
    return tf.concat([tensor[..., 0:1], tensor1, tensor2], axis=-1)

def _invtrans_margin_parameters(tensor):
    tensor1 = tf.math.exp(tensor[..., 1:2]) + 1e-6
    tensor2 = (tf.math.tanh(tensor[..., 2:]) + 1.) * 500. + 1e-6
    return tf.concat([tensor[..., 0:1], tensor1, tensor2], axis=-1)

def _uniform_contractor(tensor, truncate_level):
    return (tensor-0.5) * (1.-2*truncate_level) + 0.5

def Gaussian_hmm_initializer(data, num_states, dtype):
    model = hmm.GaussianHMM(n_components=num_states,
                            covariance_type="diag",
                            n_iter=10)
    model.fit(data)
    means = tf.constant(model.means_, dtype=dtype)
    sigmas = tf.linalg.diag_part(model.covars_)
    sigmas = tf.math.sqrt(sigmas)
    sigmas = tf.cast(sigmas, dtype=dtype)

    degree = tf.ones(shape=means.shape, dtype=dtype) \
            * tf.constant(50., dtype=dtype)
    parameters = tf.stack([means, sigmas, degree, degree], axis=-1)
    return tf.transpose(parameters, perm=[1, 0, 2])

class SkewtStateMargins(tf.keras.layers.Layer):

    def __init__(self, 
                 num_states,
                 margin_initializer=Gaussian_hmm_initializer,
                 dtype=tf.float32, 
                 truncate_level=1e-7,
                 name=None, **kwargs):
        super().__init__(dtype=dtype, name=name, **kwargs)
        self.is_build = False
        self.num_states = num_states
        self.truncate_level = truncate_level
        self.margin_initializer = margin_initializer

    def _get_left_extreme(self, u_tensor):
        is_left_extreme = tf.math.sign(u_tensor - self.truncate_level)
        is_left_extreme = - (is_left_extreme - 1) / 2
        return tf.cast(is_left_extreme, dtype=self.dtype)

    def _get_right_extreme(self, u_tensor):
        is_right_extreme = tf.math.sign(u_tensor - 1 + self.truncate_level)
        is_right_extreme = (is_right_extreme + 1) / 2
        return tf.cast(is_right_extreme, dtype=self.dtype)

    def _truncate_extreme_uniform(self, u_tensor):
        is_left_extreme = self._get_left_extreme(u_tensor)
        is_right_extreme = self._get_right_extreme(u_tensor)
        u_tensor = (
            u_tensor * (1 - is_left_extreme) 
            + self.truncate_level * is_left_extreme
        )
        u_tensor = (
            u_tensor * (1 - is_right_extreme) 
            + (1.-self.truncate_level) * is_right_extreme
        )
        return u_tensor

    def _initialize_parameters(self, data):
        pars = self.margin_initializer(data, 
                                       self.num_states, 
                                       self.dtype)
        return _trans_margin_parameters(pars)
    
    def _get_bound(self):
        lb = np.array([-np.inf, 1e-6, 1e-6, 1e-6])
        ub = np.array([np.inf] * 4)
        lb = repeat(lb, 'p -> s d p', s=self.num_states, d=self.series_dim)
        ub = repeat(ub, 'p -> s d p', s=self.num_states, d=self.series_dim)
        return lb, ub

    def call(self, data):
        '''
        data: (L, D)
        
        '''
        data = tf.cast(data, dtype=self.dtype)
        if not self.is_build:
            self.series_dim = data.shape[-1]
            self.pars = tf.Variable(self._initialize_parameters(data),
                                    name='margin_parameters')
            self.bounds = self._get_bound()
            self.is_build = True
        
        margin_dist = Skewt(dtype=self.dtype)
        data = repeat(data, 'l d -> d s l', s=self.num_states)
        log_prob, u_tensor = margin_dist(
                _invtrans_margin_parameters(self.pars), data
        )
        u_tensor = _uniform_contractor(u_tensor, self.truncate_level)
        return_tensor = tf.stack([log_prob, u_tensor], axis=0)
        return tf.transpose(return_tensor, perm=[0, 2, 3, 1])
