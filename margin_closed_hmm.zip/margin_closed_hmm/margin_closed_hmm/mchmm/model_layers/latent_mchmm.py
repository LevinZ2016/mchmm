#%% 
import tensorflow as tf
from einops import (repeat, rearrange)
import numpy as np

from mchmm.modules.toeplitz_correlations import (UnivariateToeplitzCorr, BlockToeplitzCorr)
from mchmm.modules.mchmm_correlation_matrix import MCHMMCorrMats
from mchmm.modules.BW_algorithm import (MCHMMBaumWelch, KnownLatentAlgo)
from mchmm.modules.margin_closed_correlation_matrix import UniCompoentMC

NaN = tf.constant(np.nan)

def _trans_rho_parameters(tensor):
    return tf.math.atanh(tensor / 0.99)

def _invtrans_rho_parameters(tensor):
    return tf.math.tanh(tensor) * 0.99

def _trans_hmm_parameters(tensor):
    return tensor[..., :-1] - tensor[..., -1:]

def _invtrans_hmm_parameters(tensor):
    shape = tensor.get_shape()
    new_shape = shape[:-1] + (1,)
    last_column = tf.zeros(new_shape, dtype=tensor.dtype)
    tensor = tf.concat([tensor, last_column], axis=-1)
    denominator = tf.math.reduce_logsumexp(tensor, axis=-1, keepdims=True)
    return tensor - denominator

def vague_state_initializer(num_states, dtype):
    denominator = tf.math.log(tf.constant(num_states, dtype=dtype))
    log_start_prob = tf.zeros(num_states, dtype=dtype)
    log_transition_mat = tf.zeros([num_states, num_states], dtype=dtype)
    log_start_prob = log_start_prob - denominator
    log_transition_mat = log_transition_mat - denominator
    return log_start_prob, log_transition_mat

def zero_rho_initializer(shape, dtype):
    return tf.zeros(shape=shape, dtype=dtype)

class IndepHMM(tf.keras.layers.Layer):

    def __init__(self, 
                 k, 
                 link_states = True,
                 hmm_initializer = vague_state_initializer,
                 serial_dependence_initializer = zero_rho_initializer,
                 cross_states_initializer = zero_rho_initializer,
                 dtype = tf.float32, 
                 name=None, **kwargs):
        super().__init__(dtype=dtype, name=name, **kwargs)
        self.k = k
        self.link_states = link_states
        self.hmm_initializer = hmm_initializer
        self.serial_dependence_initializer = serial_dependence_initializer
        self.cross_states_initializer = cross_states_initializer

    def check_parameters_feasibility(self, get_eigvals=False):
        serial_pcor = _invtrans_rho_parameters(self.serial_pcor_par)
        link_coefs = _invtrans_rho_parameters(self.link_coefs_par)
        toeplitz_mats = self.uni_toep(serial_pcor) #(D, S, k+1, k+1)
        transition_corr_mats, is_feasible = self.mchmm_corr_mats(toeplitz_mats, 
                                                                 link_coefs,
                                                                 get_eigvals)
        return transition_corr_mats, is_feasible

    def build(self, input_shape):
        '''
        input_shape: (2, S, L, D)

        '''
        self.series_dim = input_shape[-1]
        self.num_states = input_shape[1]

        log_start_prob, log_transition_mat = self.hmm_initializer(self.num_states, 
                                                                  dtype=self.dtype)
        self.log_start_prob = tf.Variable(
                _trans_hmm_parameters(log_start_prob),
                name='log_start_prob')
        self.log_transition_mat = tf.Variable(
                _trans_hmm_parameters(log_transition_mat),
                name='log_transition_mat')
        self.serial_pcor_par = tf.Variable(
            _trans_rho_parameters(
            self.serial_dependence_initializer(shape=[self.series_dim, 
                                                      self.num_states, 
                                                      self.k], 
                                               dtype=self.dtype)),
            name='serial_dependence_within_states')
        self.link_coefs_par = tf.Variable(
                _trans_rho_parameters(
                self.cross_states_initializer(shape=[self.series_dim, 1], 
                                              dtype=self.dtype)),
                name='serial_dependence_between_states')
        if not self.link_states:
            self.link_coefs_par = tf.constant(self.link_coefs_par)
        self.uni_toep = UnivariateToeplitzCorr(dtype=self.dtype)
        self.mchmm_corr_mats = MCHMMCorrMats(dtype=self.dtype)
        self.bw_algo = MCHMMBaumWelch(dtype=self.dtype)

    def call(self, input_tensor):
        '''
        input_tensor: (2, S, L, D)
        
        '''

        log_transition_mat = _invtrans_hmm_parameters(self.log_transition_mat)
        log_start_prob = _invtrans_hmm_parameters(self.log_start_prob)

        input_tensor = tf.cast(input_tensor, dtype=self.dtype)
        input_tensor = rearrange(input_tensor, 'n s l (d b) -> n d s l b', b=1)
        log_margin_prob, u_tensor = input_tensor
        
        transition_corr_mats, is_feasible = self.check_parameters_feasibility()
        if not is_feasible: return tf.cast(np.nan, dtype=self.dtype), False

        loglik = self.bw_algo(log_margin_prob,
                              u_tensor, 
                              transition_corr_mats, 
                              log_transition_mat,
                              log_start_prob,
                              [0])
        return loglik, True


class MCHMM(IndepHMM):

    def __init__(self, 
                 k,
                 hmm_initializer = vague_state_initializer,
                 serial_dependence_initializer = zero_rho_initializer,
                 cross_states_initializer = zero_rho_initializer,
                 cross_sectional_initializer = zero_rho_initializer,
                 dtype = tf.float32, 
                 name=None, **kwargs):
        super().__init__(
            k=k, 
            link_states=True,
            hmm_initializer=hmm_initializer,
            serial_dependence_initializer=serial_dependence_initializer,
            cross_states_initializer=cross_states_initializer,
            dtype=dtype, 
            name=name,
            **kwargs
        )
        self.cross_sectional_initializer = cross_sectional_initializer

    def check_parameters_feasibility(self, get_eigvals=False):
        serial_pcor = _invtrans_rho_parameters(self.serial_pcor_par)
        link_coefs = _invtrans_rho_parameters(self.link_coefs_par)
        cross_sectional_cor = _invtrans_rho_parameters(self.cross_sectional_par)

        toeplitz_mats = self.uni_toep(serial_pcor) #(D, S, k+1, k+1)
        toeplitz_mats = tf.transpose(toeplitz_mats, perm=[1, 0, 2, 3])
        toeplitz_mats, is_feasible = self.uni_mc_mats(toeplitz_mats,
                                                      cross_sectional_cor) #(S, D(k+1), D(k+1))
        if not get_eigvals:
            if not is_feasible: return [], False
            return self.mchmm_corr_mats(toeplitz_mats, link_coefs, get_eigvals)
        else:
            return self.mchmm_corr_mats(toeplitz_mats, link_coefs, get_eigvals)

    def build(self, input_shape):
        '''
        input_shape: (2, S, L, D)

        '''
        super().build(input_shape)
        cross_par_nums = self.series_dim * (self.series_dim - 1) // 2
        cross_par_shape = [self.num_states, cross_par_nums]
        self.cross_sectional_par = tf.Variable(
            _trans_rho_parameters(
            self.cross_sectional_initializer(shape=cross_par_shape, 
             dtype=self.dtype)),
            name='cross_sectional_dependence')
        self.link_coefs_par = tf.Variable(
            _trans_rho_parameters(
            self.cross_states_initializer(shape=[self.series_dim], 
                                          dtype=self.dtype)),
            name='serial_dependence_between_states')
        self.uni_mc_mats = UniCompoentMC(dtype=self.dtype)

    def call(self, input_tensor):
        '''
        input_tensor: (2, S, L, D)
        
        '''
        log_transition_mat = _invtrans_hmm_parameters(self.log_transition_mat)
        log_start_prob = _invtrans_hmm_parameters(self.log_start_prob)

        input_tensor = tf.cast(input_tensor, dtype=self.dtype)
        log_margin_prob, u_tensor = input_tensor

        transition_corr_mats, is_feasible = self.check_parameters_feasibility()
        if not is_feasible: return tf.cast(np.nan, dtype=self.dtype), False
        
        loglik = self.bw_algo(log_margin_prob,
                              u_tensor, 
                              transition_corr_mats, 
                              log_transition_mat,
                              log_start_prob)
        return loglik, True

# %%

class MCHMMLatentInfo(MCHMM):

    def __init__(self, 
                 k,
                 hmm_initializer = vague_state_initializer,
                 serial_dependence_initializer = zero_rho_initializer,
                 cross_states_initializer = zero_rho_initializer,
                 cross_sectional_initializer = zero_rho_initializer,
                 dtype = tf.float32, 
                 name=None, **kwargs):
        super().__init__(
            k=k, 
            hmm_initializer=hmm_initializer,
            serial_dependence_initializer=serial_dependence_initializer,
            cross_states_initializer=cross_states_initializer,
            cross_sectional_initializer=cross_sectional_initializer,
            dtype=dtype, 
            name=name,
            **kwargs
        )
        self.is_built = False

    def build_layer(self, input_shape):
        '''
        input_shape: (2, S, L, D)

        '''
        super().build(input_shape)
        self.algo = KnownLatentAlgo(dtype=self.dtype)
        self.is_built = True

    def call(self, input_tensor, latent_sequence, include_sequence=True):
        '''
        input_tensor: (2, S, L, D)
        
        '''
        if not self.is_built:
            self.build_layer(input_tensor.shape)

        latent_sequence = tf.constant(latent_sequence)
        log_transition_mat = _invtrans_hmm_parameters(self.log_transition_mat)
        log_start_prob = _invtrans_hmm_parameters(self.log_start_prob)

        input_tensor = tf.cast(input_tensor, dtype=self.dtype)
        log_margin_prob, u_tensor = input_tensor

        transition_corr_mats, is_feasible = self.check_parameters_feasibility()
        if not is_feasible: return tf.cast(np.nan, dtype=self.dtype), False
        
        loglik = self.algo(latent_sequence,
                           log_margin_prob,
                           u_tensor,
                           transition_corr_mats,
                           log_transition_mat,
                           log_start_prob,
                           include_sequence)
        return loglik, True