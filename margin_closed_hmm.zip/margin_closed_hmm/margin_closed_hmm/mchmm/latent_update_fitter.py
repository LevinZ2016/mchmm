
import pathlib
import logging
import numpy as np
import matplotlib.lines as mlines

from .indep_hmm_initializer.initializer_func import initializer_generator as indep_generator
from .known_latent_initializer.initializer_func import initializer_generator as latent_generator
from .mchmm import (FullMCHMM, KnownLatentMCHMM)

def create_logger(file_name, name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    ch = logging.FileHandler(file_name)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    return logger
    
def fit_model_with_external(data, k, latent_sequence, l=1, cl=3, cp=0.6, log_folder='logs'):
    int_cp = int(round(cp*10))
    log_file_name = f'l={l}_cl={cl}_cp={int_cp}.log'
    logger_name = f'Parameters_({l}_{cl}_{int_cp})'
    print(f'cp values: {int_cp}, log_file_name: {log_file_name}, logger_name: {logger_name}')
    log_file = pathlib.Path().cwd().joinpath(log_folder, log_file_name)
    logger = create_logger(log_file, logger_name)
    logger.info('Start fitting the model...')
    logger.info(f'Initial sequence is {latent_sequence.tolist()!r}')
    update_seq_info = [latent_sequence.copy().astype(int).tolist()]
    update_model_info = []
    num_states = len(np.unique(latent_sequence))

    count = 0
    while True:
        margin_initializer, hmm_initializer, serial_dependence_initializer, \
            cross_sectional_initializer, _ = latent_generator(k, num_states, data, 
                                                              np.array(update_seq_info[-1]))
        model = KnownLatentMCHMM(max(k, 1), num_states,
                            margin_initializer=margin_initializer,
                            hmm_initializer=hmm_initializer,
                            serial_dependence_initializer=serial_dependence_initializer,
                            cross_sectional_initializer=cross_sectional_initializer)
        model.neg_log_likelihood(data, np.array(update_seq_info[-1]), False)
        if k: model.constrained_fit(data, np.array(update_seq_info[-1]), 5)
        model.inference_module = model.get_inference_module(data)
        update_model_info.append(model)
        new_seq = model.inference_module.get_inferred_latent(l=l, cl=cl, cp=cp)

        seq_diff = sum(np.array(update_seq_info[-1]) != new_seq)
        if (seq_diff==0) or (new_seq.tolist() in update_seq_info):
            return update_seq_info, update_model_info
        
        update_seq_info.append(new_seq.tolist())
        count += 1
        logger.info(f'Update the sequence as {new_seq.tolist()!r}')
        logger.info(f'The number of updates is {count}, the sequences difference is {seq_diff}')

def get_initial_model(data, k, num_states):
    margin_initializer, hmm_initializer, _ = indep_generator(num_states, data)
    initial_model = FullMCHMM(k=k, num_states=num_states,
                    margin_initializer=margin_initializer,
                    hmm_initializer=hmm_initializer)
    initial_model.neg_log_likelihood(data)
    initial_model.inference_module = initial_model.get_inference_module(data)
    return initial_model

def fit_model_without_external(data, k, initial_model, l=1, cl=3, cp=0.6, log_folder='logs'):
    latent_sequence = initial_model.inference_module.get_inferred_latent(l=l, cl=cl, cp=cp)
    return fit_model_with_external(data, k, latent_sequence, l=l, cl=cl, cp=cp, log_folder=log_folder)


color_dict = {
    'red': "#d62728",
    'blue': "#1f77b4",
    'orange': "#ff7f0e"
}
dash_list = ['-', '--', ':']
legend_lines = [
    mlines.Line2D([], [], color="#d62728", 
                  linestyle='-', label='Regime 0', linewidth=3),
    mlines.Line2D([], [], color="#1f77b4", 
                  linestyle='--', label='Regime 1', linewidth=3),
    mlines.Line2D([], [], color="#ff7f0e", 
                  linestyle=':', label='Regime 2', linewidth=3)
]



def plot_single(date_index, arr, plot_value, show_value, color, linestyle, ax):
    show_value -= len(np.unique(arr)) // 2 * 0.1
    index = np.where(arr[:-1] != arr[1:])[0]+1
    index = index.tolist()
    index = [0] + index + [len(arr)+1]
    for i in range(len(index)-1):
        start, end = index[i:(i+2)]
        value = arr[start]
        if value == plot_value:
            plot_index = date_index[start:end]
            ax.plot(plot_index,
                    [show_value+0.1*value]*len(plot_index),
                    color=color,
                    linestyle=linestyle,
                    linewidth=3)