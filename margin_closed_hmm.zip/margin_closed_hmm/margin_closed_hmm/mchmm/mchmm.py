#%%

from copy import deepcopy
import functools
import tensorflow as tf
import tensorflow_probability as tfp
from scipy.optimize import minimize
import numpy as np

from .model_layers.skew_t_margins import (SkewtStateMargins,     
                                         Gaussian_hmm_initializer,
                                         _invtrans_margin_parameters)
from .model_layers.latent_mchmm import (IndepHMM, MCHMM, MCHMMLatentInfo,
                                       vague_state_initializer, zero_rho_initializer,
                                       _invtrans_rho_parameters,
                                       _invtrans_hmm_parameters)
from mchmm.model_visual_and_inference.visual_and_inference import MCHMMInference

def make_val_and_grad_fn(value_fn):
  @functools.wraps(value_fn)
  def val_and_grad(x):
    return tfp.math.value_and_gradient(value_fn, x)
  return val_and_grad

class Monitor():
    
    def __init__(self, n_par, loglik, sample_size, sols=None):
        self.n_par = n_par
        self.sample_size = sample_size
        self.loglik = loglik
        self.sols = sols
        
    def __repr__(self):
        return ('n_samples = {}\n'.format(self.n_par)
                + 'loglik = {}\n'.format(self.loglik)
                + 'aic = {}\n'.format(self.aic())
                + 'bic = {}\n'.format(self.bic()))
    
    def aic(self):
        return 2 * self.n_par - 2 * self.loglik
    
    def bic(self):
        return np.log(self.sample_size) * self.n_par - 2 * self.loglik
    

class IndepMCHMM(tf.keras.Model):

    def __init__(self,
                 k,
                 num_states,
                 link_states = True,
                 truncate_level = 1e-8,
                 margin_distribution = SkewtStateMargins,
                 margin_initializer = Gaussian_hmm_initializer,
                 hmm_initializer = vague_state_initializer,
                 serial_dependence_initializer = zero_rho_initializer,
                 cross_states_initializer = zero_rho_initializer,
                 dtype = tf.float64):
        super().__init__(dtype=dtype)
        self.k = k
        self.num_states = num_states
        self.truncate_level = truncate_level
        self.link_states = link_states

        self.margin_distribution = margin_distribution(
            num_states=self.num_states,
            margin_initializer=margin_initializer,
            dtype=self.dtype, 
            truncate_level=self.truncate_level,
            name='margin_distribution'
        )
        self.latent_mchmm = IndepHMM(
            k=self.k, 
            link_states=self.link_states,
            hmm_initializer=hmm_initializer,
            serial_dependence_initializer=serial_dependence_initializer,
            cross_states_initializer=cross_states_initializer,
            dtype=self.dtype, 
            name='latent_mchmm'
        )

    def check_parameters_feasibility(self, get_eigvals=False):
        return self.latent_mchmm.check_parameters_feasibility(get_eigvals)[1]

    def neg_log_likelihood(self, inputs):
        '''
        inputs: (L, D)
        
        '''
        copula_tensor = self.margin_distribution(inputs)
        loglik, is_feasible = self.latent_mchmm(copula_tensor)
        return -loglik, is_feasible
    
    def get_model_from_seperate_parameters(self,
                                  margin_pars,
                                  log_strat_prob,
                                  log_transition_mat,
                                  serial_pcor_par, 
                                  link_coefs_par):
        _copy_model = deepcopy(self)
        _copy_model.margin_distribution.pars = margin_pars
        _copy_model.latent_mchmm.log_start_prob = log_strat_prob
        _copy_model.latent_mchmm.log_transition_mat = log_transition_mat
        _copy_model.latent_mchmm.serial_pcor_par = serial_pcor_par
        _copy_model.latent_mchmm.link_coefs_par = link_coefs_par
        return _copy_model
    
    def get_model_from_single_parameters(self, i, input_vector):
        input_vector = tf.cast(input_vector, dtype=self.dtype)
        variable_list = deepcopy(self.variables)
        variable_list[i] = tf.reshape(input_vector, self.variables[i].shape)
        return self.get_model_from_seperate_parameters(*variable_list)
    
    def get_model_from_all_parameters(self, input_vector):
        input_vector = tf.cast(input_vector, dtype=self.dtype)
        variable_list = []
        left_ind = 0
        for var in self.variables:
            right_ind = left_ind + tf.size(var)
            sub_vec = tf.reshape(input_vector[left_ind : right_ind],
                                 shape=var.shape)
            variable_list.append(sub_vec)
            left_ind = right_ind
        return self.get_model_from_seperate_parameters(*variable_list)

    def _vec_single_parameters(self, i):
        return tf.reshape(self.variables[i], -1)
    
    def _add_single_parameters(self, i, input_vector):
        input_vector = tf.cast(input_vector, dtype=self.dtype)
        var = self.variables[i]
        sub_vec = tf.reshape(input_vector, shape=var.shape)
        var.assign_add(sub_vec)
    
    def _vec_parameters(self):
        cancat_list = []
        for var in self.variables:
            cancat_list.append(tf.reshape(var, -1))
        return tf.concat(cancat_list, axis=0)

    def _add_parameters(self, input_vector):
        input_vector = tf.cast(input_vector, dtype=self.dtype)
        left_ind = 0
        for var in self.variables:
            right_ind = left_ind + tf.size(var)
            sub_vec = tf.reshape(input_vector[left_ind : right_ind],
                                 shape=var.shape)
            var.assign_add(sub_vec)
            left_ind = right_ind


class FullMCHMM(IndepMCHMM):

    def __init__(self,
                 k,
                 num_states,
                 truncate_level = 1e-7,
                 margin_distribution = SkewtStateMargins,
                 margin_initializer = Gaussian_hmm_initializer,
                 hmm_initializer = vague_state_initializer,
                 serial_dependence_initializer = zero_rho_initializer,
                 cross_states_initializer = zero_rho_initializer,
                 cross_sectional_initializer = zero_rho_initializer,
                 dtype = tf.float64):
        super().__init__(k=k,
                         num_states=num_states,
                         link_states = True,
                         truncate_level = truncate_level,
                         margin_distribution = margin_distribution,
                         margin_initializer = margin_initializer,
                         hmm_initializer = hmm_initializer,
                         serial_dependence_initializer = serial_dependence_initializer,
                         cross_states_initializer = cross_states_initializer,
                         dtype = dtype)
        
        self.cross_sectional_initializer = cross_sectional_initializer
        self.latent_mchmm = MCHMM(
            k=self.k, 
            hmm_initializer=hmm_initializer,
            serial_dependence_initializer=serial_dependence_initializer,
            cross_states_initializer=cross_states_initializer,
            cross_sectional_initializer=cross_sectional_initializer,
            dtype=self.dtype, 
            name='latent_mchmm'
        )

    def get_model_from_seperate_parameters(self,
                                            marign_pars,
                                            log_strat_prob,
                                            log_transition_mat,
                                            serial_pcor_par,
                                            cross_sectional_par,
                                            link_coefs_par):
        _copy_model = deepcopy(self)
        _copy_model.margin_distribution.pars = marign_pars
        _copy_model.latent_mchmm.log_start_prob = log_strat_prob
        _copy_model.latent_mchmm.log_transition_mat = log_transition_mat
        _copy_model.latent_mchmm.serial_pcor_par = serial_pcor_par
        _copy_model.latent_mchmm.cross_sectional_par = cross_sectional_par
        _copy_model.latent_mchmm.link_coefs_par = link_coefs_par
        return _copy_model
    
    def get_inference_module(self, data):
        marign_pars = _invtrans_margin_parameters(self.margin_distribution.pars)
        marign_pars = tf.transpose(marign_pars, perm=[1, 0, 2])

        serial_pcor = _invtrans_rho_parameters(self.latent_mchmm.serial_pcor_par)
        serial_pcor = tf.transpose(serial_pcor, perm=[1, 0, 2])

        log_strat_prob = _invtrans_hmm_parameters(self.latent_mchmm.log_start_prob)
        log_transition_mat = _invtrans_hmm_parameters(self.latent_mchmm.log_transition_mat)
        cross_sectional_cor = _invtrans_rho_parameters(self.latent_mchmm.cross_sectional_par)
        link_coefs = _invtrans_rho_parameters(self.latent_mchmm.link_coefs_par)

        return MCHMMInference(marign_pars.shape[1], 
                              self.k,
                              self.num_states,
                              data,
                              marign_pars,
                              log_strat_prob,
                              log_transition_mat,
                              serial_pcor,
                              cross_sectional_cor,
                              link_coefs)
    
    # part of model fitting
    def get_target_func(self, data, var_ind):
        @make_val_and_grad_fn
        def target(inputs):
            copy_model = self.get_model_from_single_parameters(var_ind, inputs)
            return copy_model.neg_log_likelihood(data)[0]
        return target

    def constraint(self, inputs, var_ind):
        copy_model = self.get_model_from_single_parameters(var_ind, inputs)
        return copy_model.check_parameters_feasibility(True)

    def constraint_jacobian(self, inputs, var_ind):
        with tf.GradientTape() as t:
            t.watch(inputs)
            eigvals = self.constraint(inputs, var_ind)
        return t.jacobian(eigvals, inputs)

    def unconstrained_fit(self, data, var_ind, tol=1e-3, max_iter=100):
        start = tf.reshape(self.variables[var_ind], -1)
        sol = tfp.optimizer.lbfgs_minimize(self.get_target_func(
                                                        data, var_ind), 
                                                  start,
                                                  tolerance=tol,
                                                  max_iterations=max_iter)
        self._add_single_parameters(var_ind, sol.position-start)
        return sol

    def constrained_fit(self, data, var_ind, tol=1e-3, max_iter=100):
        cast = lambda inputs: tf.cast(inputs, dtype=self.dtype)
        start = self._vec_single_parameters(var_ind).numpy()
        ineq_cons = {'type': 'ineq',
                     'fun' : lambda x: self.constraint(cast(x), var_ind) - 1e-3,
                     'jac' : lambda x: self.constraint_jacobian(cast(x), var_ind)}
        sol = minimize(lambda x: self.get_target_func(data, var_ind)(cast(x)), 
                            start, constraints=[ineq_cons],
                            method='SLSQP', jac=True,
                            options={'ftol': tol, 'maxiter': max_iter})
        self._add_single_parameters(var_ind, sol.x-start)
        return sol

    def simultaneous_fit(self, data, tol=1e-3, max_iter=100):
        cast = lambda inputs: tf.cast(inputs, dtype=self.dtype)
        start = self._vec_parameters().numpy()

        @make_val_and_grad_fn
        def target(inputs):
            copy_model = self.get_model_from_all_parameters(inputs)
            return copy_model.neg_log_likelihood(data)[0]

        def constraint(inputs):
            copy_model = self.get_model_from_all_parameters(inputs)
            return copy_model.check_parameters_feasibility(True)

        def constraint_jacobian(inputs):
            with tf.GradientTape() as t:
                t.watch(inputs)
                eigvals = constraint(inputs)
            return t.jacobian(eigvals, inputs)

        ineq_cons = {'type': 'ineq',
                     'fun' : lambda x: constraint(cast(x)) - 1e-3,
                     'jac' : lambda x: constraint_jacobian(cast(x))}
        sol_all = minimize(lambda x: target(cast(x)), 
                            start, constraints=[ineq_cons],
                            method='SLSQP', jac=True,
                            options={'ftol': tol, 'maxiter': max_iter})
        self._add_parameters(sol_all.x - start)
        return sol_all

    def fit(self, data, serial_correlated=True, is_simuls=False, display=False, tol=1e-3, max_iter=100):
        if serial_correlated:
            sols = self.fit_with_serial_dependence(
                data, is_simuls=is_simuls, display=display, tol=tol, max_iter=max_iter)
            n_par = len(self._vec_parameters())
        else:
            sols = self.fit_without_serial_dependence(
                data,  display=display, tol=tol, max_iter=max_iter)
            dim = len(tf.reshape(self.variables[-1], -1))
            n_par = len(self._vec_parameters()) - (self.num_states*self.k+1)*dim
        self.inference_module = self.get_inference_module(data)
        self.monitor = Monitor(n_par,
                               -self.neg_log_likelihood(data)[0].numpy(),
                               len(data),
                               sols)

    def fit_with_serial_dependence(self, data, is_simuls=False, display=False, tol=1e-3, max_iter=100):
        if display: print('Fitting the within-regime serial dependence...')
        sol1 = self.unconstrained_fit(data, var_ind=3, tol=tol, max_iter=max_iter)
        if display: print('Fitting the cross-sectional correlation...')
        sol2 = self.constrained_fit(data, var_ind=4, tol=tol, max_iter=max_iter)
        if display: print('Fitting the between-regime serial dependence correlation...')
        sol3 = self.constrained_fit(data, var_ind=5, tol=tol, max_iter=max_iter)
        sols = [sol1, sol2, sol3]
        if is_simuls:
            if display: print('Fitting all parameters together...')
            sol_all = self.simultaneous_fit(data, tol=tol, max_iter=max_iter)
            sols.append(sol_all)
        return sols

    def fit_without_serial_dependence(self, data, display=False, tol=1e-3, max_iter=100):
        if display: print('Fitting the cross-sectional correlation...')
        cast = lambda inputs: tf.cast(inputs, dtype=self.dtype)
        start = self._vec_single_parameters(4).numpy()
        sol = minimize(lambda x: self.get_target_func(data, 4)(cast(x)), 
                       start, method='SLSQP', jac=True,
                       options={'ftol': tol, 'maxiter': max_iter})
        self._add_single_parameters(4, sol.x-start)
        return [sol]

class KnownLatentMCHMM(FullMCHMM):

    def __init__(self,
                 k,
                 num_states,
                 truncate_level = 1e-7,
                 margin_distribution = SkewtStateMargins,
                 margin_initializer = Gaussian_hmm_initializer,
                 hmm_initializer = vague_state_initializer,
                 serial_dependence_initializer = zero_rho_initializer,
                 cross_states_initializer = zero_rho_initializer,
                 cross_sectional_initializer = zero_rho_initializer,
                 dtype = tf.float64):
        super().__init__(k=k,
                         num_states=num_states,
                         truncate_level = truncate_level,
                         margin_distribution = margin_distribution,
                         margin_initializer = margin_initializer,
                         hmm_initializer = hmm_initializer,
                         serial_dependence_initializer = serial_dependence_initializer,
                         cross_states_initializer = cross_states_initializer,
                         cross_sectional_initializer = cross_sectional_initializer,
                         dtype = dtype)
        
        self.latent_mchmm = MCHMMLatentInfo(
            k=self.k, 
            hmm_initializer=hmm_initializer,
            serial_dependence_initializer=serial_dependence_initializer,
            cross_states_initializer=cross_states_initializer,
            cross_sectional_initializer=cross_sectional_initializer,
            dtype=self.dtype, 
            name='latent_mchmm'
        )

    def neg_log_observe_likelihood(self, inputs):
        sub_model = FullMCHMM(self.k, self.num_states, self.truncate_level)
        _ = sub_model.neg_log_likelihood(inputs)
        for i in range(len(self.variables)):
            sub_model.variables[i].assign(self.variables[i])
        return sub_model.neg_log_likelihood(inputs)

    def neg_log_likelihood(self, inputs, latent_sequence, include_sequence=True):
        '''
        inputs: (L, D)
        
        '''
        copula_tensor = self.margin_distribution(inputs)
        loglik, is_feasible = self.latent_mchmm(copula_tensor, 
                                                latent_sequence,
                                                include_sequence)
        return -loglik, is_feasible
    
    def set_monitors(self, n_par, data, latent_sequence, sol):
        self.complete_monitor = Monitor(n_par,
                                        -self.neg_log_likelihood(data, 
                                                        latent_sequence)[0].numpy(),
                                        len(data),
                                        sol)
        self.observe_monitor = Monitor(n_par,
                                        -self.neg_log_observe_likelihood(data)[0].numpy(),
                                        len(data),
                                        sol)
    
    def get_target_func(self, data, latent_sequence, var_ind):
        @make_val_and_grad_fn
        def target(inputs):
            copy_model = self.get_model_from_single_parameters(var_ind, inputs)
            return copy_model.neg_log_likelihood(data, latent_sequence, False)[0]
        return target
    
    def unconstrained_fit(self, data, latent_sequence, var_ind, 
                          tol=1e-3, max_iter=100):
        cast = lambda inputs: tf.cast(inputs, dtype=self.dtype)
        start = self._vec_single_parameters(var_ind).numpy()
        sol = minimize(lambda x: self.get_target_func(
                                    data, latent_sequence, var_ind)(cast(x)), 
                            start, method='SLSQP', jac=True,
                            options={'ftol': tol, 'maxiter': max_iter})
        dim = len(tf.reshape(self.variables[-1], -1))
        n_par = len(self._vec_parameters()) - (self.num_states*self.k+1)*dim
        self._add_single_parameters(var_ind, sol.x-start)
        self.inference_module = self.get_inference_module(data)
        self.set_monitors(n_par, data, latent_sequence, sol)

    def constrained_fit(self, data, latent_sequence, var_ind, 
                        tol=1e-3, max_iter=100):
        cast = lambda inputs: tf.cast(inputs, dtype=self.dtype)
        start = self._vec_single_parameters(var_ind).numpy()
        ineq_cons = {'type': 'ineq',
                     'fun' : lambda x: self.constraint(cast(x), var_ind) - 1e-3,
                     'jac' : lambda x: self.constraint_jacobian(cast(x), var_ind)}
        sol = minimize(lambda x: self.get_target_func(
                                        data, latent_sequence, var_ind)(cast(x)), 
                            start, constraints=[ineq_cons],
                            method='SLSQP', jac=True,
                            options={'ftol': tol, 'maxiter': max_iter})
        n_par = len(self._vec_parameters())
        self._add_single_parameters(var_ind, sol.x-start)
        self.inference_module = self.get_inference_module(data)
        self.set_monitors(n_par, data, latent_sequence, sol)

# %%
