
#%% Import data
with open("load_macro_data.py") as f:
    exec(f.read())

#%% 
import numpy as np
import matplotlib.pyplot as plt

import mchmm.latent_update_fitter as fwl
from mchmm.latent_update_fitter import \
    (fit_model_with_external, get_initial_model, fit_model_without_external, plot_single)


#%% Estimation with external information

all_seq_info = {}
all_model_info = {}
for j in np.linspace(0.6, 0.8, 3):
    update_seq_info, update_model_info = fit_model_with_external(data, 3, latent_seq, cp=j)
    all_seq_info[str(j)] = update_seq_info
    all_model_info[str(j)] = update_model_info

y_labels = ['External seq']
fig, ax = plt.subplots(figsize=(14, 5))
plot_single(date_index, latent_seq, 0, ax)
count = 1
for gamma, seq_info in all_seq_info.items():
    y_labels.append(r'$\gamma$ = '+str(gamma))
    plot_single(date_index, seq_info[-1], count, ax)
    count += 1

#%%
ax.set(ylim=(-0.5, count-0.5),
        yticks=np.arange(count),
        yticklabels=y_labels)
ax.grid()
ax.legend(handles=fwl.legend_lines[:2])

# %%
