
import numpy as np
import scipy.stats as st
import matplotlib.lines as mlines

color_dict = {
    'red': "#d62728",
    'blue': "#1f77b4",
    'orange': "#ff7f0e"
}
dash_list = ['-', '--', ':']
legend_lines = [
    mlines.Line2D([], [], color="#d62728", 
                  linestyle='-', label='Regime 0', linewidth=3),
    mlines.Line2D([], [], color="#1f77b4", 
                  linestyle='--', label='Regime 1', linewidth=3),
    mlines.Line2D([], [], color="#ff7f0e", 
                  linestyle=':', label='Regime 2', linewidth=3)
]

def plot_single(date_index, arr, show_value, ax):
    show_value -= len(np.unique(arr)) // 2 * 0.1
    index = np.where(arr[:-1] != arr[1:])[0]+1
    index = index.tolist()
    index = [0] + index + [len(arr)+1]
    for i in range(len(index)-1):
        start, end = index[i:(i+2)]
        value = arr[start]
        plot_index = date_index[start:end]
        ax.plot(plot_index,
                [show_value+0.1*value]*len(plot_index),
                color=list(color_dict.values())[value],
                linestyle=dash_list[value],
                linewidth=3)

def get_contour_arrays(mgx, mgy, rho, x_array, y_array):
    xx, yy = np.meshgrid(x_array, y_array)
    lx, ly = xx.ravel(), yy.ravel()
    logpdf_x = mgx.logpdf(lx)
    logpdf_y = mgy.logpdf(ly)
    zx = st.norm.ppf(mgx.cdf(lx))
    zy = st.norm.ppf(mgy.cdf(ly))
    zxy = np.vstack([zx, zy]).T
    R = np.array([[1., rho], [rho, 1.]])
    zxy[zxy > 1-1e-8] = 1-1e-8
    zxy[zxy < 1e-8] = 1e-8
    logpdf_xy = st.multivariate_normal.logpdf(zxy, cov=R) \
                - st.multivariate_normal.logpdf(zxy, cov=np.eye(2))
    log_z = logpdf_x + logpdf_y + logpdf_xy
    log_z.shape = xx.shape
    return xx, yy, np.exp(log_z)