#%%

import numpy as np
import scipy as sp

from .utils import *
from .cross_sectional_corr import * 


#%%

def get_cross_par_dim(dim_arr):
    '''
    Get the number of parameters for correlations between all sub-processes 
    
    '''
    if len(dim_arr) == 2:
        return dim_arr[0] * dim_arr[1]
    else:
        return dim_arr[0] * sum(dim_arr[1:]) \
                + get_cross_par_dim(dim_arr[1:])

def get_cross_section_mat_fr_par_dict(R_arr, dim_arr, k, par_dict, condition_types):
    '''
    Get the dictionary of cross-sectional correlation matrices for all pairs 
    of sub-processes from the dictionary of parameters. 'par_dict[(i,j)]' gives
    the parameters for cross-sectional correlation between the i-th and j-th sub-processes.
    
    '''
    cross_section_mat_dict = {}
    for i in range(len(dim_arr)):
        for j in range(i+1, len(dim_arr)):
            condition_pair = (condition_types[i], condition_types[j])
            cross_section_mat_dict[(i,j)] = get_pair_cross_section_mat_fr_par(R_arr[i],
                                                            R_arr[j],
                                                            dim_arr[i],
                                                            dim_arr[j],
                                                            k,
                                                            par_dict[(i,j)],
                                                            condition_pair)
    return cross_section_mat_dict

def get_corr_fr_cross_section_mat(R_arr, dim_arr, k, cross_section_mat_dict):
    '''
    Get the covariance matrix of stationary joint distribution. 
    
    '''
    rR = np.empty([sum(dim_arr) * (k+1)]*2)
    index_arr, cum_dimi_ = [], 0
    
    for i in range(len(dim_arr)):
        dimi = dim_arr[i]
        cum_dimi = cum_dimi_ + dimi * (k+1)
        cum_dimj_ = cum_dimi
        rR[cum_dimi_:cum_dimi, cum_dimi_:cum_dimi] = R_arr[i]
        
        for j in range(i+1, len(dim_arr)):
            dimj = dim_arr[j]
            cum_dimj = cum_dimj_ + dimj * (k+1)
            
            rR[cum_dimi_:cum_dimi, cum_dimj_:cum_dimj] \
                                            = cross_section_mat_dict[(i,j)]
            rR[cum_dimj_:cum_dimj, cum_dimi_:cum_dimi] \
                                            = cross_section_mat_dict[(i,j)].T
            cum_dimj_ = cum_dimj
        
        index_i = np.reshape(np.arange(cum_dimi_, cum_dimi), [-1, dimi])
        index_arr.append(index_i)
        cum_dimi_ = cum_dimi
    
    index = np.block(index_arr).ravel()
    R = rR[index, :][:, index]
    return rR, R

def get_par_dict(dim_arr, par):
    '''
    Get the dictionary of parameters from the vector of parameters. 
    
    '''
    par_dict, left_index = {}, 0
    for i in range(1, len(dim_arr)):
        for j in range(len(dim_arr)-i):
            ind1, ind2 = j, i+j
            dim1, dim2 = dim_arr[ind1], dim_arr[ind2]
            right_index = left_index + dim1 * dim2
            par_dict[(ind1, ind2)] = np.array(par[left_index:right_index])
            left_index = right_index
    return par_dict

def get_par_fr_dict(dim_arr, par_dict):
    '''
    Get the vector of parameters from the dictionary of parameters. 
    
    '''
    par = np.array([])
    for i in range(1, len(dim_arr)):
        for j in range(len(dim_arr)-i):
            ind1, ind2 = j, i+j
            par = np.append(par, par_dict[(ind1, ind2)])
    return par

def get_corr_fr_par_dict(R_arr, dim_arr, k, par_dict, condition_types):
    '''
    Get the covariance matrix of stationary joint distribution, with cross-sectionl 
    correlation parameters in a dictionary.
    
    '''
    cross_section_mat_dict = get_cross_section_mat_fr_par_dict(R_arr, 
                                                               dim_arr, 
                                                               k, 
                                                               par_dict, 
                                                               condition_types)
    rR, R = get_corr_fr_cross_section_mat(R_arr, 
                                          dim_arr, 
                                          k, 
                                          cross_section_mat_dict)
    cross_par_dim = get_cross_par_dim(dim_arr)
    uni_par_dim = sum([dim**2*k + dim*(dim-1)//2 for dim in dim_arr])
    return rR, R, cross_par_dim, uni_par_dim

def get_corr_fr_par(R_arr, dim_arr, k, par, condition_types):
    '''
    Get the covariance matrix of stationary joint distribution, with cross-sectionl 
    correlation parameters in a vector.
    
    '''
    par_dict = get_par_dict(dim_arr, par)
    return get_corr_fr_par_dict(R_arr, dim_arr, k, par_dict, condition_types)

#%%

def get_full_corr_fr_par(R_arr, k, par):
    '''
    Get the covariance matrix of stationary joint distribution, with all sub-processes
    being univariate satisfying condition 2 (type==1).
    
    '''
    num_component = R_arr.shape[0]
    dim_arr = [1] * num_component
    condition_types = [1] * num_component
    return get_corr_fr_par(R_arr, dim_arr, k, par, condition_types)

