
#%%
import numpy as np

from .utils import *

def get_mat_G(R, dim, k):
    '''
    Get matrix G

    '''
    J = get_exchange_mat(k)
    L = np.kron(J, np.eye(dim))

    back_order_coefs = get_coefs(R, dim) @ L
    row_mat = np.block([np.zeros([dim, dim]),
                        back_order_coefs, 
                        -np.eye(dim), 
                        np.zeros([dim, dim*(k-1)])])
    m = np.empty([k*dim, (2*k+1) * dim])
    for i in range(k):
        m[(i*dim):((i+1)*dim)] = np.roll(row_mat, 
                                         dim*i, 
                                         axis=1)
    return m

def get_mat_H(R, dim, k):
    '''
    Get matrix H

    '''
    J = get_exchange_mat(k)
    L = np.kron(J, np.eye(dim))

    back_order_coefs_inv = get_coefs_inv(R, dim) @ L
    row_mat = np.block([-np.eye(dim),
                        back_order_coefs_inv,
                        np.zeros([dim, dim*k])])
    m = np.empty([k*dim, (2*k+1) * dim])
    for i in range(k):
        m[(i*dim):((i+1)*dim)] = np.roll(row_mat, 
                                         dim*i, 
                                         axis=1)
    return m

def get_cross_section_block_toeplitz(blocks, dim, l):
    '''
    Transform the matirx (Sigma_{-k},...,Sigma_0,...,Sigma_{k}) into 
    the block Toeplitz correlation matrix:
        Sigma_0     ... Sigma_{k} 
        Sigma_{-1}  ... Sigma_{k-1}
        ...
        Sigma_{-k}  ... Sigma_{0}

    '''
    m = []
    for i in range(l-1, -1, -1):
        m.append(blocks[:, (i*dim):((i+l)*dim)])
    return np.vstack(m)

def get_cross_section_mat(R1, R2, dim1, dim2, k, Sigma, condition_types=(1,1)):
    '''
    Get cross-sectional correlation matrix between to sub-processes. 
    condition_types: 0 and 1 for Condition 1 and 2 in the paper.
    
    '''
    
    if condition_types[0] != condition_types[1]:
        S = np.zeros([k+1, k+1])
        S[-1][0] = 1
        return np.kron(S, Sigma) if type_arr[0] == 0 else np.kron(S.T, Sigma)
    elif condition_types[0] == 0:
        M1 = get_mat_G(R1, dim1, k)
        M2 = get_mat_G(R2, dim2, k)
    else:
        M1 = get_mat_H(R1, dim1, k)
        M2 = get_mat_H(R2, dim2, k)
    
    J = get_exchange_mat(2*k+1)
    L = np.kron(J, np.eye(dim2))
    K = get_comm_mat(dim1, dim2)
    A = M2 @ L

    M1_nk = np.block([M1[:, :(k * dim1)], 
                      M1[:, -(k * dim1):]])
    M1_k = M1[:, (k * dim1):((k+1) * dim1)]

    A_nk = np.block([A[:, :(k * dim2)], 
                     A[:, -(k * dim2):]])
    M2_k = M2[:, (k * dim2):((k+1) * dim2)]
    
    B = np.block([[np.kron(M1_nk, np.eye(dim2)) @ np.kron(np.eye(2*k), K)],
                  [np.kron(A_nk, np.eye(dim1))]])
    
    C = np.block([[np.kron(M1_k, np.eye(dim2)) @ K],
                  [np.kron(M2_k, np.eye(dim1))]])
    
    v = -np.linalg.solve(B, np.dot(C, vec(Sigma)))
    D = dvec(v, dim1)
    D = np.hstack([D[:, :(k * dim2)], 
                   Sigma, 
                   D[:, -(k * dim2):]])
    S = get_cross_section_block_toeplitz(D, dim2, k+1)
    return S

def get_pair_cross_section_mat_fr_par(R1, R2, dim1, dim2, k, par, condition_types=(1,1)):
    '''
    Get cross-sectional correlation matrix between to sub-processes from vector of parameters. 
    
    '''
    Sigma = np.reshape(par, [dim1, dim2])
    return  get_cross_section_mat(R1, R2, dim1, dim2, k, Sigma, condition_types)

# %%
