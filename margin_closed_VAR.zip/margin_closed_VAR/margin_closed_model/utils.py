#%%

import numpy as np

#%% manipulate (block) toeplitz matrix

def get_btm_fr_par(par, dim, k, partial=True):
    assert len(par) == dim*(dim-1) // 2 + dim**2 * k, 'Wrong input dimension of pars.'
    diag_block = np.eye(dim) * 0.5
    diag_block[np.triu_indices(dim, 1)] = par[:(dim*(dim-1)//2)]
    diag_block = diag_block + diag_block.T
    blocks_arr = np.reshape(par[(dim*(dim-1)//2):], 
                            [dim,-1], 
                            order='F')
    
    roll_mat = np.block([diag_block, blocks_arr])
    block_mat = np.empty([dim*(k+1), dim*(k+1)])
    for i in range(k+1):
        block_mat[(i*dim):((i+1)*dim), (i*dim):] \
            = roll_mat[:, :(k+1-i)*dim]
        block_mat[(i*dim):, (i*dim):((i+1)*dim)] \
            = roll_mat[:, :(k+1-i)*dim].T
        
    return pcor2cor(block_mat) if partial else block_mat

#%% transfer toeplitz matrix

def cor2pcor(R):
    d = R.shape[0]
    if d==2:
        return R
    
    P = np.eye(d)
    P[range(d-1), range(1,d)] = R[range(d-1), range(1,d)]
    P[range(1,d), range(d-1)] = R[range(d-1), range(1,d)]
    
    for i in range(2,d):
        for j in range(d-i):
            posi = (j, i+j)
            rho = R[posi]
            S11 = R[(j+1):(j+i), (j+1):(j+i)]
            S12 = R[(j+1):(j+i), (j, i+j)]

            omega = np.dot(S12.T, np.linalg.solve(S11, S12))
            p = (rho - omega[0,1]) / np.sqrt((1-omega[0,0]) * (1-omega[1,1]))
            P[posi] = p
            P[i+j, j] = p
    return P

def pcor2cor(P):
    d = P.shape[0]
    if d==2:
        return P

    R = np.eye(d)
    R[range(d-1), range(1,d)] = P[range(d-1), range(1,d)]
    R[range(1,d), range(d-1)] = P[range(d-1), range(1,d)]
    for i in range(2,d):
        for j in range(d-i):
            posi = (j, i+j)
            p = P[posi]
            S11 = R[(j+1):(j+i), (j+1):(j+i)]
            S12 = R[(j+1):(j+i), (j, i+j)]
            
            omega = np.dot(S12.T, np.linalg.solve(S11, S12))
            rho = omega[0,1] + p * np.sqrt((1-omega[0,0]) * (1-omega[1,1]))
            
            R[posi] = rho
            R[i+j, j] = rho
    return R


#%%

def vec(A):
    return A.T.ravel()

def dvec(v, n):
    '''
    Inverse function of vec

    '''
    return np.reshape(v, [n,-1], order='F')

def get_comm_mat(m,n):
    '''
    Commutation matrix

    '''
    A = np.reshape(np.arange(m*n), (m,n), order='F')
    w = np.reshape(A.T, m*n, order='F')
    M = np.eye(m*n)
    M = M[w,:]
    return M

def get_exchange_mat(n):
    '''
    Exchange matrix

    '''
    J = np.rot90(np.eye(n))
    return J

def get_coefs(R, dim):
    '''
    Get coefficient matrices in conditional mean of Z_t given Z_{t-1}, ... , Z_{t-k}
    
    '''
    R22 = R[dim:, dim:]
    R12 = R[dim:, :dim]
    return np.linalg.solve(R22, R12).T

def get_coefs_inv(R, dim):
    '''
    Get coefficient matrices in conditional mean of Z_{t-k-1} given Z_{t}, ... , Z_{t-k}
    
    '''
    R11 = R[:-dim, :-dim]
    R21 = R[:-dim, -dim:]
    return np.linalg.solve(R11, R21).T

def get_mat_G(R, dim, k):
    '''
    Get matrix G

    '''
    coefs = get_coefs(R, dim) 
    row_mat = np.block([np.zeros([dim, dim*(k-1)]), 
                        -np.eye(dim), 
                        coefs, 
                        np.zeros([dim, dim])])
    m = np.empty([k*dim, (2*k+1) * dim])
    for i in range(k):
        m[(i*dim):((i+1)*dim)] = np.roll(row_mat, 
                                         -dim*i, 
                                         axis=1)
    return m

def get_shift_mat_inv(R, dim, k):
    '''
    Get matrix H * L2 where L2 is the Kronecker product 
        between (2k+1)-dimensional exchange matrix and I_d2

    '''
    coefs_inv = get_coefs_inv(R, dim)
    row_mat = np.block([np.zeros([dim, dim*k]),
                        coefs_inv, 
                        -np.eye(dim)])
    m = np.empty([k*dim, (2*k+1) * dim])
    for i in range(k):
        m[(i*dim):((i+1)*dim)] = np.roll(row_mat, 
                                         -dim*i, 
                                         axis=1)
    return m

