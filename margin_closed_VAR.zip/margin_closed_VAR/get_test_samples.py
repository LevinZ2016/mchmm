
#%%

import numpy as np
from margin_closed_model.utils import get_btm_fr_par
from margin_closed_model.cross_sectional_corr import get_mat_G, get_mat_H
from margin_closed_model.margin_closed_corr import (get_pair_cross_section_mat_fr_par,
                                                    get_corr_fr_par,
                                                    get_cross_par_dim,
                                                    get_par_dict)

def get_sample(func):
    def inner(sample_idx, **kargs):
        results = func(**kargs)
        with np.printoptions(linewidth=200):
            with open(f'test_samples.txt', 'a') as f:
                f.write('\n')
                f.write(f"Test sample {sample_idx:d} of {func.__name__}: \n")
                # write inputs
                f.write('Input: \n')
                for key, value in kargs.items():
                    if isinstance(value, np.ndarray):
                        f.write(f"{key} = \n{repr(value)},\n")
                    elif isinstance(value, list) and isinstance(value[0], np.ndarray):
                        f.write(f"{key} = [\n")
                        for array in value:
                            f.write(f"{repr(array)}\n")
                        f.write(f"],\n")
                    else:
                        f.write(f"{key} = {value},\n")

                # write outputs
                f.write('Output:'.ljust(76, '-') + '\n')
                outputs = results if isinstance(results, tuple) else (results,)
                for i, value in enumerate(outputs):
                    if isinstance(value, np.ndarray):
                        f.write(f"output_{i} = \n{repr(np.round(value,2))},\n")
                    else:
                        f.write(f"output_{i} = {value},\n")
                f.write('#'.ljust(76, '=') + '\n')
        return results
    return inner

get_sample_btm = get_sample(get_btm_fr_par)
get_sample_shift_mat = get_sample(get_mat_G)
get_sample_shift_mat_inv = get_sample(get_mat_H)
get_sample_cross_section_mat_fr_par = get_sample(get_pair_cross_section_mat_fr_par)
get_sample_full_mat_fr_par = get_sample(get_corr_fr_par)

def generate_samples(dims, k, seed):

    with np.printoptions(linewidth=200):
        with open(f'test_samples.txt', 'a') as f:
            f.write('\n')
            f.write(f'Samples with seed {seed}'.ljust(76, '-'))
            f.write('\n')

    np.random.seed(seed)
    btms = []
    num_of_subprocess = len(dims)
    for i in range(num_of_subprocess):
        dim = dims[i]
        n_par = dim*(dim-1) // 2 + dim**2 * k
        par = np.round(np.random.rand(n_par) * 1.6 - 0.8, 1)
        btms.append(np.round(get_sample_btm(i, par=par, dim=dims[i], k=k),2))

    mats = [get_sample_shift_mat(i, R=btms[i], dim=dims[i], k=k) for i in range(num_of_subprocess)]
    mats_inv = [get_sample_shift_mat_inv(i, R=btms[i], dim=dims[i], k=k) for i in range(num_of_subprocess)]

    cross_par_dim = get_cross_par_dim(dims)
    cross_par = np.round(np.random.rand(cross_par_dim)*1.6-0.8, 1)
    cross_par_dict = get_par_dict(dims, cross_par)

    pairs = [(i, j) for j in range(i+1,num_of_subprocess) for i in range(num_of_subprocess)]
    for idx, (i, j) in enumerate(pairs):
        get_sample_cross_section_mat_fr_par(idx, 
                                   R1=btms[i],
                                   R2=btms[j],
                                   dim1=dims[i],
                                   dim2=dims[j],
                                   k=k,
                                   par=cross_par_dict[(i,j)],
                                   condition_types=(1,1))

    closed_mat = get_sample_full_mat_fr_par(0, 
                                            R_arr=btms, 
                                            dim_arr=dims, 
                                            k=k, 
                                            par=cross_par, 
                                            condition_types=(1,)*num_of_subprocess)

    with np.printoptions(linewidth=200):
        with open(f'test_samples.txt', 'a') as f:
            f.write('\n')
            f.write('#' + '='*76 + '\n')
            f.write('#' + '*'*76 + '\n')
            f.write('#' + '='*76 + '\n')
            f.write('\n')

    print(f"Successfully generate samples with seed {seed}.")

if __name__ == '__main__':
    k = 2
    dims = [1, 2, 3]
    seed = 123
    generate_samples(dims, k, seed)
