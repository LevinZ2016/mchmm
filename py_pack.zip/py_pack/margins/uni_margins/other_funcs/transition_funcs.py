# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 12:35:26 2022

@author: Levin
"""

import scipy.stats as st
import scipy.special as sp
import autograd.numpy as np
from autograd import elementwise_grad


class Transition():
    
    def __init__(self, sup, par_dim, lb, ub):
        self.sup = sup
        self.par_dim = par_dim
        self.lb, self.ub = np.array(lb), np.array(ub)
        self.class_name = self.__class__.__name__
        
    def __repr__(self):
        return ("{},".format(self.class_name))
    
    def elementwise_cdf_func(self):
        pass
    
    def elementwise_logpdf_func(self):
        pass
    
    def elementwise_ppf_func(self):
        pass
    
    def elementwise_pdf_func(self, data, *pars):
        if self.par_dim == 2:
            kappa_l, alpha_l = pars
            return np.exp(self.elementwise_logpdf_func(data, kappa_l, alpha_l))
        else:
            return np.exp(self.elementwise_logpdf_func(data, pars[0]))
    
    def elementwise_dlogpdf_func(self, data, *pars):
        if self.par_dim == 2:
            kappa_l, alpha_l = pars
            g_kappa = elementwise_grad(self.elementwise_logpdf_func, 1)(data, 
                                                                        kappa_l, 
                                                                        alpha_l)
            g_alpha = elementwise_grad(self.elementwise_logpdf_func, 2)(data, 
                                                                        kappa_l, 
                                                                        alpha_l)
            return np.vstack([g_kappa, g_alpha]).T
        else:
            g_kappa = elementwise_grad(self.elementwise_logpdf_func, 1)(data, 
                                                                        pars[0])
            return g_kappa[:, None]
        
    def elementwise_dlogpdf2data_func(self, data, *pars):
        if self.par_dim == 2:
            kappa_l, alpha_l = pars
            g_data = elementwise_grad(self.elementwise_logpdf_func, 0)(data, 
                                                                       kappa_l, 
                                                                       alpha_l)
        else:
            g_data = elementwise_grad(self.elementwise_logpdf_func, 0)(data, 
                                                                       pars[0])
        return g_data[:, None]
    
class CBeta(Transition):
    
    def __init__(self):
        super().__init__(sup=[0, 1], par_dim=2, 
                         lb=[1e-8, 1e-8], ub=[np.inf, np.inf])
    
    def elementwise_logB(self, a_l, b_l):
        '''
        -------
        return -log(Beta(a, b))

        '''
        return -sp.betaln(a_l,b_l)
    
    def elementwise_dlogB(self, a_l, b_l):
        da = - sp.digamma(a_l) + sp.digamma(a_l+b_l)
        db = - sp.digamma(b_l) + sp.digamma(a_l+b_l)
        return da, db
        
    def elementwise_cdf_func(self, data, kappa_l, alpha_l):
        return 1 - sp.betainc(1/alpha_l, kappa_l, (1-data)**alpha_l)
    
    def elementwise_ppf_func(self, p, kappa_l, alpha_l):
        return 1 - (st.beta.ppf(1 - p, 1/alpha_l, kappa_l))**(1 / alpha_l)
        
    def elementwise_scale_func(self, data, kappa_l, alpha_l):
        scale = np.log(alpha_l) + (alpha_l - 1) * np.log(1-data)
        scale += (1 - alpha_l) * np.log(1-data) 
        v = (1 - data)**alpha_l
        scale += (kappa_l - 1) * np.log(1 - v)
        return scale
    
    def elementwise_logpdf_func(self, data, kappa_l, alpha_l):
        scale = self.elementwise_scale_func(data, kappa_l, alpha_l)
        return scale + self.elementwise_logB(1/alpha_l, kappa_l)
    
    def elementwise_dlogpdf_func(self, data, kappa_l, alpha_l):
        g_kappa = elementwise_grad(self.elementwise_scale_func, 1)(data, kappa_l, 
                                                                   alpha_l)
        g_alpha = elementwise_grad(self.elementwise_scale_func, 2)(data, kappa_l, 
                                                                    alpha_l)
        g_a, g_b = self.elementwise_dlogB(1/alpha_l, kappa_l)
        g_alpha -= g_a / (alpha_l ** 2)
        g_kappa += g_b
        return np.vstack([g_kappa, g_alpha]).T
    
    def elementwise_dlogpdf2data_func(self, data, kappa_l, alpha_l):
        return elementwise_grad(self.elementwise_scale_func, 0)(data, kappa_l, 
                                                                alpha_l)[:, None]

class CExp(Transition):
    
    def __init__(self):
        super().__init__(sup=[0, 1], par_dim=2, 
                         lb=[1e-8, 1e-8], ub=[np.inf, np.inf])
        
    def elementwise_cdf_func(self, data, kappa_l, alpha_l):
        return np.exp(kappa_l - kappa_l * data ** (-alpha_l))
    
    def elementwise_logpdf_func(self, data, kappa_l, alpha_l):
        logpdf = np.log(alpha_l) + np.log(kappa_l) + (-alpha_l-1) * np.log(data)
        logpdf += (kappa_l - kappa_l * (data ** (-alpha_l)))
        return logpdf 

    def elementwise_ppf_func(self, p, kappa_l, alpha_l):
        return (kappa_l / (kappa_l - np.log(p)))**(1 / alpha_l)

class Beta(Transition):
    
    def __init__(self):
        super().__init__(sup=[0, 1], par_dim=1, lb=[1e-8], ub=[np.inf])
        
    def elementwise_cdf_func(self, data, kappa_l):
        return data ** kappa_l
    
    def elementwise_logpdf_func(self, data, kappa_l):
        logpdf = np.log(kappa_l) + (kappa_l-1) * np.log(data)
        return logpdf 

    def elementwise_ppf_func(self, p, kappa_l):
        return p ** (1/kappa_l)

class Exp(Transition):
    
    def __init__(self):
        super().__init__(sup=[0, 1], par_dim=1, lb=[1e-8], ub=[np.inf])
        
    def elementwise_cdf_func(self, data, kappa_l):
        return np.exp(kappa_l - kappa_l / data)
    
    def elementwise_logpdf_func(self, data, kappa_l):
        logpdf = (kappa_l - kappa_l / data) + np.log(kappa_l)
        logpdf -= 2 * np.log(data)
        return logpdf
    
    def elementwise_ppf_func(self, p, kappa_l):
        return kappa_l / (kappa_l - np.log(p))