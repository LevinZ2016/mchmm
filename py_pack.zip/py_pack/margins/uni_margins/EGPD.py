# -*- coding: utf-8 -*-
"""
Created on Fri Jun 24 12:54:00 2022

@author: Levin
"""

import autograd.numpy as np

from .template import distribution


def get_EGPD(GPD, Trans):
    
    class EGPD(distribution):
        
        def __init__(self, par=None):
            self.GPD = GPD
            self.Trans = Trans
            self.trans_func = self.Trans()
            self.gpd = self.GPD()
            trans_lb, trans_ub = self.trans_func.lb, self.trans_func.ub
            gpd_lb, gpd_ub = self.gpd.lb, self.gpd.ub
            par_dim = self.gpd.par_dim + self.trans_func.par_dim
            
            super().__init__(par=par, sup=self.gpd.sup, par_dim=par_dim, 
                             lb=np.hstack([gpd_lb, trans_lb]), 
                             ub=np.hstack([gpd_ub, trans_ub]))
            
        def elementwise_cdf(self, data, *args):
            par1_l, par2_l = args[:2]
            prob = self.gpd.elementwise_cdf(data, par1_l, par2_l)
            if self.trans_func.par_dim == 2:
                kappa_l, alpha_l = args[2:]
                return self.trans_func.elementwise_cdf_func(prob, kappa_l, 
                                                            alpha_l) 
            else:
                kappa_l = args[2]
                return self.trans_func.elementwise_cdf_func(prob, kappa_l) 
            
        def elementwise_ppf(self, prob_l, *args):
            if self.trans_func.par_dim == 2:
                kappa_l, alpha_l = args[2:]
                p = self.trans_func.elementwise_ppf_func(prob_l, kappa_l, 
                                                         alpha_l) 
            else:
                kappa_l = args[2]
                p = self.trans_func.elementwise_ppf_func(prob_l, kappa_l) 
            
            par1_l, par2_l = args[:2]
            return self.gpd.elementwise_ppf(p, par1_l, par2_l)
        
        def elementwise_logpdf(self, data, *args):
            par1_l, par2_l = args[:2]
            prob = self.gpd.elementwise_cdf(data, par1_l, par2_l)
            logpdf = self.gpd.elementwise_logpdf(data, par1_l, par2_l)
            if self.trans_func.par_dim == 2:
                kappa_l, alpha_l = args[2:]
                return logpdf + self.trans_func.elementwise_logpdf_func(prob, 
                                                                        kappa_l, 
                                                                        alpha_l) 
            else:
                kappa_l = args[2]
                return logpdf + self.trans_func.elementwise_logpdf_func(prob, 
                                                                        kappa_l) 
            
        def elementwise_dlogpdf(self, data, *args):
            par1_l, par2_l = args[:2]
            prob = self.gpd.elementwise_cdf(data, par1_l, par2_l)
            g_cdf2pars = self.gpd.elementwise_dcdf(data, par1_l, par2_l)
            g_logpdf2pars = self.gpd.elementwise_dlogpdf(data, par1_l, par2_l)
            
            if self.trans_func.par_dim == 2:
                kappa_l, alpha_l = args[2:]
                g_par3 = self.trans_func.elementwise_dlogpdf_func(prob, 
                                                                  kappa_l, 
                                                                  alpha_l) 
                g_cdf = self.trans_func.elementwise_dlogpdf2data_func(prob, 
                                                                      kappa_l, 
                                                                      alpha_l)
            else:
                kappa_l = args[2]
                g_par3 = self.trans_func.elementwise_dlogpdf_func(prob, 
                                                                  kappa_l) 
                g_cdf = self.trans_func.elementwise_dlogpdf2data_func(prob, 
                                                                      kappa_l)
            g_pars = g_cdf *  g_cdf2pars + g_logpdf2pars
            return np.hstack([g_pars, g_par3])
        
        def fix_boundary(self, data):
            self.gpd.fix_boundary(data)
            self.lb[:2] = self.gpd.lb
            
        def fix_support(self):
            if self.par is not None:
                self.gpd.par = self.par[:2]
                self.sup = self.gpd.sup
        
        def init_par(self, data):
            cut = np.quantile(data, 0.1)
            gpd_data = data[data > cut]
            self.tail = self.GPD()
            self.tail.fit(gpd_data)
            
            ind = data < cut
            Fhat = (np.argsort(np.argsort(data)) + 1) / (len(data) + 0.5)
            if self.par_dim > 3:
                x, y = np.log(data[ind]), np.log(Fhat[ind])
                par3 = np.dot(x, y) / np.dot(x, x)
            else:
                x, y = 1-1/(data[ind]), np.log(Fhat[ind])
                par3 = np.dot(x, y) / np.dot(x, x)
                
            if self.par_dim == 3:
                return np.hstack([self.tail.par, par3])
            else:
                return np.hstack([self.tail.par, [par3, 0.5]])  
            
    return EGPD












