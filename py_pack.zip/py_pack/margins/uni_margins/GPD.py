# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 12:18:48 2022

@author: Levin
"""

import autograd.numpy as np
from autograd import elementwise_grad

from .template import (distribution, break_par_dist)


class GPD(break_par_dist):
    
    def __init__(self, par=None):
        super().__init__(par_dim=2, 
                         lb=[1e-8, -np.inf], 
                         ub=[np.inf, np.inf])
        self.par = par
        self.com_dist = [GPD_p, GPD_0, GPD_n]
        
    def par2dist(self):
        if self.par is None:
            dist = GPD_p()
        elif self.par[1] > 0:
            dist_par = self.par.tolist()
            dist = GPD_p(dist_par)
        elif self.par[1] == 0:
            dist_par = self.par.tolist()
            dist_par.pop(1)
            dist = GPD_0(dist_par)
        else:
            dist_par = self.par.tolist()
            a = dist_par[1] / dist_par[0]
            dist = GPD_n([dist_par[0], a])
            
        return dist
            
    def dist2par(self):
        if self.dist.par is None:
            return None
        
        par = self.dist.par.tolist()
        if self.dist.class_name == 'GPD_0':
            par.insert(1, 0)
        elif self.dist.class_name == 'GPD_n':
            par[1] = par[1] * par[0]
        
        return np.array(par)

class GPD_0(distribution):
    
    def __init__(self, par=None):
        super().__init__(par=par, sup=[0, np.inf], par_dim=1, 
                         lb=[1e-8], ub=[np.inf])
    
    def elementwise_cdf(self, data, sigma_l):
        y = data / sigma_l
        prob = 1 - np.exp(-y)
        return prob
    
    def elementwise_ppf(self, prob_l, sigma_l):
        y = 1 - prob_l
        y = - np.log(y) * sigma_l
        return y
    
    def elementwise_logpdf(self, data, sigma_l):
        y = data / sigma_l
        logpdf = -np.log(sigma_l) - y
        return logpdf
    
    def elementwise_dlogpdf(self, data, sigma_l):
        g_sigma = elementwise_grad(self.elementwise_logpdf, 1)(data, sigma_l)
        return np.vstack([g_sigma]).T
    
    def elementwise_dcdf(self, data, sigma_l):
        g_sigma = elementwise_grad(self.elementwise_cdf, 1)(data, sigma_l)
        return np.vstack([g_sigma]).T
        
    def init_par(self, data):
        sigma = np.mean(data)
        return [sigma]
    

class GPD_p(distribution):
    
    def __init__(self, par=None):
        super().__init__(par=par, sup=[0, np.inf], par_dim=2, 
                         lb=[1e-8, 1e-8], ub=[np.inf]*2)
    
    def elementwise_cdf(self, data, sigma_l, xi_l):
        y = data / sigma_l * xi_l + 1
        logy = (-1/xi_l) * np.log(y)
        prob = 1 - np.exp(logy)
        return prob
    
    def elementwise_ppf(self, prob_l, sigma_l, xi_l):
        y = (1 - prob_l)**(-xi_l)
        y = (y - 1) * sigma_l / xi_l
        return y
    
    def elementwise_logpdf(self, data, sigma_l, xi_l):
        y = data / sigma_l * xi_l + 1
        logpdf = -np.log(sigma_l) - (1/xi_l + 1) * np.log(y)
        return logpdf
    
    def elementwise_dlogpdf(self, data, sigma_l, xi_l):
        g_sigma = elementwise_grad(self.elementwise_logpdf, 1)(data, sigma_l, xi_l)
        g_xi = elementwise_grad(self.elementwise_logpdf, 2)(data, sigma_l, xi_l)
        return np.vstack([g_sigma, g_xi]).T
    
    def elementwise_dcdf(self, data, sigma_l, xi_l):
        g_sigma = elementwise_grad(self.elementwise_cdf, 1)(data, sigma_l, xi_l)
        g_xi = elementwise_grad(self.elementwise_cdf, 2)(data, sigma_l, xi_l)
        return np.vstack([g_sigma, g_xi]).T
        
    def init_par(self, data):
        xi = 2
        sigma = max(data)
        return [sigma, xi]
    

class GPD_n(distribution):
    
    def __init__(self, par=None):
        super().__init__(par=par, sup=[0, np.inf], par_dim=2, 
                         lb=[1e-8, -np.inf], ub=[np.inf, -1e-8])
    
    def elementwise_cdf(self, data, sigma_l, a_l):
        xi_l = sigma_l * a_l
        y = data / sigma_l * xi_l + 1
        logy = (-1/xi_l) * np.log(y)
        prob = 1 - np.exp(logy)
        return prob
    
    def elementwise_ppf(self, prob_l, sigma_l, a_l):
        xi_l = sigma_l * a_l
        y = (1 - prob_l)**(-xi_l)
        y = (y - 1) * sigma_l / xi_l
        return y
    
    def elementwise_logpdf(self, data, sigma_l, a_l):
        xi_l = sigma_l * a_l
        y = data / sigma_l * xi_l + 1
        logpdf = -np.log(sigma_l) - (1/xi_l + 1) * np.log(y)
        return logpdf
    
    def elementwise_dlogpdf(self, data, sigma_l, a_l):
        g_sigma = elementwise_grad(self.elementwise_logpdf, 1)(data, sigma_l, a_l)
        g_a = elementwise_grad(self.elementwise_logpdf, 2)(data, sigma_l, a_l)
        return np.vstack([g_sigma, g_a]).T
    
    def elementwise_dcdf(self, data, sigma_l, a_l):
        g_sigma = elementwise_grad(self.elementwise_cdf, 1)(data, sigma_l, a_l)
        g_a = elementwise_grad(self.elementwise_cdf, 2)(data, sigma_l, a_l)
        return np.vstack([g_sigma, g_a]).T
        
    def init_par(self, data):
        xi = 2
        sigma = max(data)
        return [sigma, xi/sigma]
    
    def fix_boundary(self, data):
        self.lb[1] = - 1 / np.max(data) + 1e-6
        
    def fix_support(self):
        if self.par is not None:
            self.sup = [0, -1/self.par[1]]