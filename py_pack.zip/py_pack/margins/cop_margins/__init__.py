# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 12:12:33 2022

@author: Levin
"""

from .cop_margin import CopulaMargin